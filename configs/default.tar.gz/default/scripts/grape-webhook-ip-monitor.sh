#!/bin/bash
# GitCode webhook 回调 IP 收集 + 断流监控 wrapper
# 实际逻辑在 /root/grape/data/webhook-ip-monitor.py(需项目 venv python 查 DB)
exec /root/grape/.venv/bin/python /root/grape/data/webhook-ip-monitor.py all
