---
name: gitcode-api
description: Use with GitCode REST API (members, invites, hosting).
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags:
      - gitcode
      - api
      - vcs
    related_skills:
      - grape-deployment
---

# GitCode REST API Integration

## When to Use
- Integrating with the gitcode.com REST API (members, collaborators, invites, webhooks, OAuth).
- Debugging repo hosting or bot-membership failures on GitCode.
- Any code that passes GitCode usernames to API endpoints.

GitCode (gitcode.com) exposes a Gitee-v5-compatible REST API at `https://api.gitcode.com/api/v5`. All facts below were verified by live reproduction (2026-08).

## Auth
- Most endpoints: `Authorization: Bearer ***
- Invite endpoints (`/user/invite*`): credentials go in the query string `?access_token=<token>`; only certain bot accounts have permission (others get 403 "no permission").
- `GET /api/v5/user` with a token returns the account's `login` — the ONLY username the API accepts.

## Username trap (top pitfall)
- Member/collaborator endpoints resolve usernames by LOGIN, not display name or nickname.
- Passing a display name → 404 `{"error_message":"User not found: <name>"}` or `用户不存在`.
- Always resolve the real login via `GET /user` with that account's own token before member operations.

## Repo members / collaborators
- List members: `GET /repos/{owner}/{repo}/collaborators` → array; fields `username`, `access_level` (30=Developer, 40=Maintainer, 50=Owner), `role_name`, `role_name_cn`, `permissions.admin`.
- `GET /repos/{owner}/{repo}/members` does NOT exist (404).
- Permission check: `GET /repos/{owner}/{repo}/collaborators/{login}/permission` → `{access_level, role_name, ...}`.
- Add (invite-based): `PUT /repos/{owner}/{repo}/collaborators/{login}` body `{"permission":"admin"}`. Enum: pull/push/admin/customized (maintainer maps to admin).
  - Idempotency: if already a member, returns 400 `用户已经是项目中的成员，或者是更高访问级别的成员` → treat as success.
- Remove: `DELETE /repos/{owner}/{repo}/collaborators/{login}`; 404 = success.

## Invite accept flow (bot joining a repo)
1. Owner token creates the invite (PUT collaborator).
2. Bot lists invites: `GET /user/invite?access_token=<bot token>` → `content[]` with `source_name` ("owner/repo") and `invitation_token`.
3. Bot accepts: `POST /user/invite/accept?access_token=<bot token>&invitation_token=<tok>` — **invitation_token 必须走 query 参数**；放 body 会 400 `Required request parameter 'invitation_token' for method parameter type String`（2026-08-17 实测）。invite 类端点凭据都走 query（见 Auth 节）。
4. Verify: `GET .../collaborators/{login}/permission` → access_level >= 40. 实测 accept 后立即 verify 即可见 40（maintainer）。

## Hosting-flow pattern (used by grape)
- Verify current user is owner or `permissions.admin`; add global bot as maintainer (idempotent); bot accepts invite (tolerate no-invite / 403 already-member case); verify bot access_level >= 40; create webhook; record managed repo.
- Hardening lesson: if the add-collaborator call fails with an unrecognized message, fall back to the permission endpoint (access_level >= 40) before failing the whole flow — the bot may already be a maintainer.

## Hooks (webhooks) — owner token only
- List repo hooks: `GET /repos/{owner}/{repo}/hooks` → array of `{id, url, password, result, result_code, push_events, tag_push_events, issues_events, note_events, merge_requests_events, active, created_at}`. `result` holds the last delivery response body (e.g. `{"status":"ok","seq":172,...}`), `result_code` the last HTTP status — handy for proving deliveries reached the server.
- **Bot token → 403 Forbidden on hooks endpoints; the repo OWNER's token works** (verified 2026-08-13). In grape, pull the owner token from `user_accounts.gitcode_api_token` (gitcode_id matches owner) — never rely on the global bot token for hook introspection.
- `POST /repos/{owner}/{repo}/hooks/{id}/tests` → 204 triggers a test delivery (verify whitelist/security-group fixes).
- A repo can have **multiple active hooks** (verified: wdmike/gallery had hook 71720 → grape-dev + hook 70366 → 121.36.33.129:8080). When debugging "events stuck on one instance but comments/PRs exist", always list hooks to see if a second instance is also receiving and executing. Cross-check the commenting account identity in webhook payloads (`user.id`) — different bot id = different instance.
- Single-hook detail: `GET /repos/{owner}/{repo}/hooks/{id}` works with bot token when the repo is managed (grape uses it for drop diagnostics).

## Read-only repo queries (verified 2026-08-13)
- `GET /repos/{owner}/{repo}/issues/{iid}` and `/issues/{iid}/comments` → issue body + comment thread (bot token OK for public/managed repos). **未托管/非成员仓库（如开发仓库 Jason7602/grape）bot token 会 403 `403 Forbidden - Unauthorized access`（2026-08-17 实测）——改用仓库 owner 的 token 即可读：grape 里从 `user_accounts.gitcode_api_token` 按 `username` 查（表列名是 `username` 非 `login`，且该 token 字段截断后 10 位即 db-backend.json 外无明文副本）。**
- `GET /repos/{owner}/{repo}/issues/{iid}/labels` → applied labels.
- `GET /repos/{owner}/{repo}/branches` → branch list; `GET /repos/{owner}/{repo}/commits?sha=<branch>` → commit history with `commit.author.name/email/date` (email reveals pushing identity, e.g. `grape_bot@noreply.gitcode.com`).
- `GET /users/{login}` → `{id, login, name, type}`; distinct bots are distinct ids (grape_bot vs grape_dev_bot vs qq_59293410 all separate accounts). Webhook payload user ids are numeric (e.g. 12224835) while API `id` is hex — match on `username`/`login`, not id format.
- MR/PR detail: `GET /repos/{o}/{r}/pull_requests/{n}`（Gitee 风格 pulls 路径）**2026-08-18 实测可用**——返回 title/state/mergeable/merged_at/merged_by/updated_at + `mergeable_state`（见下节）。早期测试 404 的是 merge_requests/pull_requests/mrs 别名路径，pulls 才是对的。
- PR 合并门禁诊断（2026-08-18 实测, songspace/shelldev #17）：「合并受阻流水线运行未通过」= `mergeable_state.state: False` + `ci_state_passed: False`（其余 conflict_passed/branch_missing_passed/non_ff_passed/discussion/approval 全 True）。仓库 MR 开关在 `merge_request_switch.only_allow_merge_if_pipeline_succeeds`（True=开「仅流水线成功才允许合并」）。
- 仓库级 PR 设置读写：**`GET/PUT /api/v5/repos/{o}/{r}/pull_request_settings`（下划线！）** → 顶层 `{merge_request_setting:{...}, only_allow_merge_if_all_discussions_are_resolved, only_allow_merge_if_pipeline_succeeds, merge_method}`。关门禁 = `PUT` body `{"only_allow_merge_if_pipeline_succeeds": false}` → 200 后 GET 回读确认。⚠️ 连字符版 `pull-request-settings` 404、`pulls/settings` 400（缺 settings 参数）——都不要用。
- `PUT /pulls/{n}/merge` → 405 Method Not Allowed（GitCode 不开放该端点；实测 PR 是由 grape 自身 coding agent 流程调 API 合并的）。
- ⚠️ **PATCH /pulls/{n} 会真的改数据**（探测时发 `{"title":"t"}` 把 PR 标题改了，需立刻 PATCH 恢复）——探测参数结构用 GET，别用带真实 body 的 PATCH 试错。
- ⚠️ **合并门禁拦不住 API 侧合并（2026-08-18 实测）**：PR #17 在 `ci_state_passed=False`（网页显示合并受阻）时仍被 grape_dev_bot 于 12:21 API 合并成功——门禁主要拦网页/常规路径，API 合并可绕过；判断「能否合并」以实际 merged_at 为准，别只看 mergeable_state。
- 私有仓库 git clone：**`https://x-access-token:<token...git` 可用**（主机侧 2026-08-18 实测）；裸 `<token>@` 会触发密码提示挂死。注意与 hosted runner 内 clone 全 404 相反（见 Actions 节）。

## GitCode Actions（CI/CD，2026-08-18 实测）
- **Actions API 在 `/api/v8/` 路径**（v5 无 actions 端点，全 404）。`https://api.gitcode.com/api/v8/repos/{owner}/{repo}/actions/...`，认证同 `Authorization: Bearer ***
- **手动触发（workflow_dispatch）**：`POST /api/v8/repos/{o}/{r}/actions/workflows/{文件名}.yml/dispatches` body `{"ref":"main"}` → `{workflow_id, workflow_run_id}`。⚠️ 刚 push 的 workflow 需等 ~15s 注册，否则 400 `THIRD_ERROR: Actions手动触发参数错误`。**push 到 main 不触发 Actions run**（实测 push 后 runs 列表无新条目）——GitCode 只认 Manual 触发，调试 CI 一律 dispatch。
- **run 列表**：`GET /api/v8/repos/{o}/{r}/actions/runs?per_page=N` → `{total_count, workflow_runs[]}`，字段 `workflow_run_id/status(COMPLETED|FAILED|QUEUED)/head_branch/head_sha/event(Manual)/file_path`。
- **job 状态**：`GET /api/v8/repos/{o}/{r}/actions/runs/{run_id}/jobs` → `jobs[].steps[]`（name/status 可见）；`GET .../jobs/{job_id}` 返回详情（含 message 但只给「点击任务查看详情」）。**步骤 stdout 拿不到**——日志 API 全 404/405，只能网页端看（私有仓库需登录）。
- **artifacts（数据回传通道，stdout 不可达时的替代）**：workflow 里 `uses: upload-artifact`（GitCode 内置，可用）上传 → `GET /api/v8/repos/{o}/{r}/actions/runs/{run_id}/artifacts` 列 → `GET /api/v8/repos/{o}/{r}/actions/artifacts/{id}/zip` 下载（**302 重定向需 `curl -L`**）。探测脚本把结果写文件 + upload-artifact = 拿数据的最稳方式（探测步骤 stdout 永远看不到）。
- **认证 context**：`${{ atomgit.token }}`（GitCode 前身 AtomGit 的 context，**不是 github.token**）→ env 注入后 ATOMGIT_TOKEN（~24 字符）存在；另有 ATOMGIT_REPOSITORY（owner/repo）、ATOMGIT_REF、ATOMGIT_SHA。⚠️ 该 token 对 **Actions 控制面 API 有效，但对 git 协议无效**。
- ⚠️ **hosted runner 限制（2026-08-18 实测，songspace/shelldev 排障）**：① 工作目录**不自动 checkout**（空目录）；② `uses: checkout`（GitCode 简写）在 hosted runner 上「下载 checkout action 失败」全红；③ runner 内 `git clone` 私有仓库——`oauth2:${ATOMGIT_TOKEN}@`、`x-access-token:${ATOM...N}@` 三种认证格式**全部 HTTP 404**（`RPC failed; HTTP 404 ... expected flush after ref listing`）——GitCode hosted runner 无法以任何 git 通道 clone 私有仓库（平台限制，非配置问题）；④ zipball API（`/api/v5/repos/{o}/{r}/zipball?sha=main`）在 runner 内返回的文件**不是压缩包**（unzip/tar 全失败）。私有仓库 CI 门禁修复不能依赖 runner 内 clone/下载——需走 GitLab 原生流水线（.gitlab-ci.yml，runner 自动 checkout）或关闭合并门禁等平台侧手段。
- **排查方法论**：run 结果只能看 job/step 状态码（COMPLETED/FAILED）+ message 一句话；把探测输出（pwd/ls/env 变量脱敏/clone 测试）写文件 → upload-artifact → API 下载，一次迭代可拿全部事实。diag 分支系列（ci/diag*）是低成本实验载体（dispatch 触发，不污染 main）。

## Reference
- `references/host-flow-debug-2026-08.md` — full reproduction transcript of the grape_dev_bot hosting failure (display-name 404, idempotent 400, member list output).
- `references/../grape-deployment/references/dual-webhook-instance-diagnosis.md` (in sibling skill) — full dual-webhook discrimination recipe.
