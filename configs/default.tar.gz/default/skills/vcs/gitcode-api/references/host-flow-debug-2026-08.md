# Grape hosting failure debug transcript (2026-08-11)

Symptom: hosting mm6667/test1 failed: `托管失败: 无法将全局 Bot（grape_dev_bot）加入仓库维护者` although the bot was already a repo maintainer (user confirmed in UI).

Root cause: `configs/global-bot-token.json` had `bot_usernames: ["grape_dev_bot"]` — a display name, not a login. GitCode API has no user "grape_dev_bot"; member endpoints only resolve LOGINs.

## Reproduced API responses (user token = repo owner mm6667)

- `GET /repos/mm6667/test1/collaborators/grape_dev_bot/permission` → 404
  `{"error_code":404,"error_code_name":"NOT_FOUND","error_message":"User not found:grape_dev_bot"}`
- `PUT /repos/mm6667/test1/collaborators/grape_dev_bot` `{"permission":"admin"}` → 404 `"user not found"`
- `GET /api/v5/users/grape_dev_bot` → 404 `{"error_code":1003,"error_code_name":"NOT_EXIST","error_message":"用户不存在"}`
- Bot token `GET /api/v5/user` → `login: qq_59293410` (the real login; note "grape_bot" also exists as a separate user)
- Member list `GET /repos/mm6667/test1/collaborators` → 2 members:
  - mm6667 (Owner, access_level=50)
  - qq_59293410 (Maintainer, access_level=40)
- With the CORRECT login: `PUT .../collaborators/qq_59293410 {"permission":"admin"}` → 400
  `用户已经是项目中的成员，或者是更高访问级别的成员` — matches add_collaborator idempotency keywords → success
- Bot invite list `GET /user/invite?access_token=*** token>` → 403 `no permission` (invite API restricted; tolerable when the bot is already a member)

## Fix applied (repos.py host flow)
1. Resolve bot login from the bot token via `GET /user` (prefer over config `bot_usernames`).
2. On add_collaborator failure, check `get_member_permission` — if `access_level >= 40`, treat as success.

Verified: critical path PASS (add_collaborator=True, access_level=40).

## Follow-up (2026-08-14): 兜底实际入库 + 新错误形态
- 此前上述第 2 条兜底**只在 reference 里描述过，代码里从未实现**（git log 确认）——`repos.py` 的 host flow 在 add_collaborator 失败时直接抛 502。用户手动邀请 bot 为维护者后托管仍失败，报"无法将全局 Bot 加入仓库维护者"。
- 新错误形态：bot 已是成员时，**owner token** PUT collaborator → 400 `用户已经是项目中的成员`（幂等关键字命中→成功）；但**bot token** PUT → 400 `组织不存在`（GitCode 拒绝 bot 邀请自己，报误导性错误，未命中幂等列表→失败）。10:04-10:07 生产日志全是 `组织不存在` 即此路径。
- 修复已入库 6e270f2d：add_collaborator 失败 → `get_member_permission` → `access_level>=40` 视为成功继续，否则抛原错误。判别"失败但已是成员"用 permission 兜底，勿把"组织不存在"塞进幂等关键字列表（可能是真错误）。
- 手动邀请"成功但托管仍失败"时的判定顺序：①`GET /repos/{o}/{r}/collaborators` 看 bot 是否在列+access_level ②用 **owner token**（user_accounts.gitcode_api_token）复现 PUT ③owner token 返回"已经是成员"= 托管应能过，直接重试即可。
