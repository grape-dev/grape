---
name: huawei-obs-upload
description: Use when uploading to Huawei Cloud OBS via obsutil CLI.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags:
      - obs
      - huawei-cloud
      - obsutil
      - upload
      - release
    related_skills:
      - grape-release-packaging
---

# Huawei Cloud OBS 上传/下载（obsutil 操作手册）

## When to Use
- 向华为云 OBS 桶上传/下载/列举发布包或工件（如 grape 发布包、备份、安装包）。
- 配置或更换 OBS AK/SK 凭据，验证凭据有效性。
- 发布后做端到端校验（下载回验哈希）。

grape 发布包的具体结构/INSTALL.md 生成/数据库导出见 `grape-release-packaging` skill；
本 skill 聚焦 obsutil 本身的操作、凭据管理与通用坑。

## obsutil 基础
- 本机已装: `/usr/local/bin/obsutil`（arm64）。装法:
  `wget https://obs-community.obs.cn-north-1.myhuaweicloud.com/obsutil/current/obsutil_linux_arm64.tar.gz`
- 端点: `-e=obs.cn-north-4.myhuaweicloud.com`（华北北京四，grape 桶所在 region）。
- 桶地址: `obs://<bucket>/<prefix>/`。**桶私有 → 匿名访问 403**，必须带凭据（obsutil config 或 -i/-k 临时参数）。
- 凭据优先级: env OBS_AK/OBS_SK > ~/.obsutilconfig > 交互输入。obsutil 会把凭据**加密**写进 ~/.obsutilconfig，勿手动改。

## 常用命令
```bash
obsutil ls obs://<bucket>/<prefix>/ -s          # 简洁列举（-s 只列对象）
obsutil cp <本地> obs://<bucket>/<prefix>/<name> -f   # 上传（-f 覆盖，幂等）
obsutil cp obs://<bucket>/<prefix>/<name> .      # 下载
obsutil rm obs://<bucket>/<prefix>/<name> -f     # 删除（破坏性，先列清单再删）
```

## 凭据管理（2026-08-17 实测流程）
用户提供新 AK/SK 时，按此顺序，**不要直接 obsutil config 覆盖**：
1. **先用临时参数直测，不碰配置文件**（obsutil 5.8.3 语法是 `-i=`/`-k=`，**不是** `--ak=`/`--sk=`——后者直接打印 help 退出）:
   ```bash
   obsutil ls obs://<bucket>/<prefix>/ -s -i=<AK> -k=<SK> -e=obs.cn-north-4.myhuaweicloud.com
   ```
   能列出对象 = 凭据有效。
2. **备份旧配置**: `cp ~/.obsutilconfig ~/.obsutilconfig.bak.<YYYYMMDD>`。
3. **更新一次**: `obsutil config -i=<AK> -k=<SK> -e=...`（obsutil 自行加密存储），再 `obsutil ls` 复验。
4. 之后脚本/命令复用 ~/.obsutilconfig 即可。

⚠️ **不要每次上传都重跑 obsutil config**: 脚本第二次读到的是**已加密**的配置串，再当明文 config 会污染凭据 → 403 InvalidAccessKeyId。规则: 仅当配置文件缺失时才 config 一次；手动换凭据走上面 4 步（备份→config→复验）。

## 发布后验证（端到端）
```bash
# 1. 桶清单确认新旧并存
obsutil ls obs://<bucket>/release/ -s
# 2. 下载回验哈希（强校验: 远端==本地才算发布成功）
obsutil cp obs://<bucket>/release/<pkg>.tar .
sha256sum <pkg>.tar   # 与本地产物 sha256sum 比对，双端一致
# 3. 本地解包校验
tar xf <pkg>.tar -C /tmp/v && cd /tmp/v/<pkg目录> && sha256sum -c SHA256SUMS
```

## 已知坑速查
1. **外层 .tar 可能是普通 tar 非 gzip**（Python `tarfile.open(path, "w")` 产物）: 列清单用 `tar tf`；
   `tar tzf` 会报 `gzip: stdin: not in gzip format`。子包 *.tar.gz 才是 gzip，`tar tzf` 对它们正确。
2. **release 前缀保留全部老包**（用户明确要求，2026-08-17）: 清理旧包只对 test 前缀做；
   上传后 `ls -s` 应看到新旧并存，release 下老包一律不删。
3. **桶私有 403**: 下载/上传必须 obsutil + 凭据；想 wget 直连的前提是前缀已放开公网读。
4. **打包脚本警告不等于失败**: 打包项缺失只打 "跳过" 警告（如 TOOL_FILES 里某些 docs 文件仓库里没有），
   以 SHA256SUMS 校验 + 包内关键文件存在为准（`tar tf` 确认 INSTALL.md/SHA256SUMS/各子包在列）。
5. **发布包不带机密**: 真实 AK/SK、gitcode token、webhook token 一律不进包，现场配置里填。

## 验证矩阵（发布后确认）
```bash
obsutil ls obs://obs-grape-release/release/ -s     # 最新包在列 + 老包保留
sha256sum -c SHA256SUMS                             # 解包后全 OK
grep -A2 "OBS 下载" INSTALL.md                       # 下载前缀与发布前缀一致
```
