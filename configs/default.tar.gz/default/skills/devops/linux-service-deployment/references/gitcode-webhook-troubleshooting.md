# GitCode webhook troubleshooting (grape project)

## Auth model (know where each secret lives)
- GitCode hook "password" is delivered as the `X-GitCode-Token` header. Server compares it against
  `managed_repos.gitcode_webhook_token` for the repo extracted from the payload
  (`project.path_with_namespace`, else `repository.full_name`).
- Token is PER-REPO, not global. `configs/global-bot-token.json`'s `gitcode_webhook_token` key is
  documentation only — the enforced value is the managed_repos column, written at 托管 time from the
  request body (the UI/flow supplies it; setup_webhook registers it as the hook password).
- Unmanaged repo → 404 "repository not managed". Token mismatch → 403. Both are logged in
  `journalctl -u grape-webhook`.
- global-bot-token.json actually feeds only: 3 oauth keys → meta table (first-run migration),
  `gitcode_api_token` → global API-token fallback, `bot_usernames` → self-comment detection.
  `webhook_url` is NOT read from the file — it lives in meta.webhook_url (auto-detected at startup
  to `http://<public-ip>:8080/...` if unset — pre-seed meta BEFORE first restart or the wrong URL sticks).

## #1 cause of "收不到事件": stale registered URL on GitCode
The hook URL registered on GitCode is a SNAPSHOT taken at 托管 time from meta.webhook_url. Changing
meta later does NOT update GitCode. If the snapshot pointed at a dead endpoint (e.g. `https://…:8080`
where 8080 is plain HTTP → TLS handshake always fails), every event dies silently.
Fix via API (Bearer = bot token):
```
GET    https://api.gitcode.com/api/v5/repos/{owner}/{repo}/hooks      # list — expect STALE relics (ngrok tunnels, old IPs)
PATCH  .../hooks/{id}   body {"url": "<new>", "password": "***"} # fix URL, align password
DELETE .../hooks/{dead_id}                                            # clean relics
```
Then UPDATE `managed_repos.gitcode_webhook_token` to the same password — GitCode password must
equal the server-expected token or you get 403.

## Diagnose order
1. No arrivals at all in `journalctl -u grape-webhook | grep Webhook:` → GitCode side: URL/secret/
   dead hook. List hooks via API and compare URL+password against meta + managed_repos.
2. Arrivals present → read the rejection: unmanaged 404 / token 403 / pipeline `no_route`.
3. `no_route` on a plain push is BY DESIGN: only issue/PR events (or push with #issue refs) route.
   `issue_opened` always → vod. event_route_config empty = default stage matrix.
4. Simulate a faithful event (proves the whole chain, spawns a real agent run in direct mode — that
   IS the intended behavior, expect side effects):
   ```
   POST /webhook/gitcode  headers: X-GitCode-Token: <secret>  X-Gitcode-Event: "Issue Hook"
   body: {"object_kind":"issue","project":{"path_with_namespace":"owner/repo"},
          "object_attributes":{"iid":23,"title":"t","action":"open","state":"opened"},
          "user":{"username":"x"}}
   ```
   Expect `{"status":"ok","seq":N,"event_type":"issue_opened"}`.

## opencode agent "Authorization Required"
opencode config (`~/.config/opencode/opencode.json`) may reference provider apiKey as `{env:VAR}`.
systemd services must carry that var — use `EnvironmentFile=/etc/grape/grape.env` (chmod 600) added
to BOTH units. Verification: `systemctl show -p Environment` does NOT list EnvironmentFile contents —
check `/proc/<pid>/environ` of the running process instead. Symptom: event dispatched, agent exits
exit=1 "Authorization Required" instantly.
