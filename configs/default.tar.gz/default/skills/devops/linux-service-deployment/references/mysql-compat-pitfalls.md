# SQLite→MySQL compatibility pitfalls

Projects that write SQLite-dialect SQL/DDL and translate it for MySQL (grape has a
`src/mysql_compat.py` translate_sql layer) hit two silent killers — both found live in production.

## 1. Self-referencing subquery in an upsert → MySQL 1093
```sql
INSERT OR REPLACE INTO t (id, ...) VALUES ((SELECT id FROM t WHERE k=?), ...)
```
SQLite: fine. MySQL: `OperationalError (1093, "You can't specify target table 't' for update in FROM clause")`.
The translate layer rewrites `INSERT OR REPLACE` → `REPLACE INTO` but the self-subquery still dies.
Fix pattern (portable, both backends — no translator changes needed):
```python
c.execute("SELECT id FROM t WHERE k=?", (k,))
row = c.fetchone()
if row:
    c.execute("UPDATE t SET ... WHERE id=?", (..., row[0]))
else:
    c.execute("INSERT INTO t (...) VALUES (...)", (...))
```
Worked fix: `session_store.set_issue_stage` (was crashing every issue_opened event).

## 2. Inline `TEXT ... UNIQUE` with column modifiers → MySQL 1170
```sql
name TEXT NOT NULL UNIQUE
```
A translator regex like `\bTEXT\s+UNIQUE\b` misses modifiers between TEXT and UNIQUE →
MySQL: `(1170, "BLOB/TEXT column 'name' used in key specification without a key length")`.
CREATE TABLE fails → the table is silently MISSING → endpoints that query it return 500.
- Table-level `UNIQUE (text_col)` IS usually handled (column rewritten to VARCHAR(191)); it's the
  inline-with-modifiers case that leaks.
- Fix: `\bTEXT\b[^,]*\bUNIQUE\b` → replace that TEXT with VARCHAR(191); guard against matching
  table-level `UNIQUE (...)` rows (`not re.search(r"\bUNIQUE\s*\(", col)`).
- Test-mode caveat: unit tests that force sqlite do NOT exercise the MySQL translator — MySQL-path
  bugs need live verification (real DB calls or the deployed services).

## Diagnosing a silently-missing table
1. Startup log carries it: `[WARNING] Create table '<name>' failed: (...)`. Grep journal for `Create table.*failed`.
2. Compare the DDL table list (`_NEW_TABLES` or equivalent) against actual `SHOW TABLES` — any missing = a translation failure.
3. Dry-run the translator before restarting: `print(translate_sql(ddl))` and eyeball the MySQL output.

## 3. Session tokens are per-process (testing gotcha)
`create_session_token`/`validate_token` in an in-process dict — a token minted by a separate python
process is rejected ("会话过期") by the running service. To verify an auth-gated handler without a
browser session: import the route module and call the endpoint function DIRECTLY in-process with a
fake user dict (`{'id': uid, 'username': name}`) — FastAPI endpoints take `user` from Depends, so
the plain function is callable. Or execute the exact queries the handler runs.
