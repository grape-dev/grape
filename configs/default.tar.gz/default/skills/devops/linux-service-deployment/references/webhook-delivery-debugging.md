# Webhook delivery debugging — "webhook 收不到事件"

Class-level playbook for diagnosing a webhook integration that receives nothing. Provider-side registration is the ground truth; server config is only half the story.

## First triage (server side)
- Count arrivals in the webhook unit log: `journalctl -u <webhook-unit> --since '24 hours ago' | grep -c 'Webhook:'`.
  - **Zero arrivals** → the provider never reaches you: wrong/stale registered URL, dead network path, or nothing registered.
  - **Arrivals with 400/403/404** → delivery works; the problem is auth or routing (see below).
- Dump `managed_repos`: is the repo managed, what token does the server expect? Enforcement model (grape): header `X-GitCode-Token` must equal `managed_repos.gitcode_webhook_token`; unmanaged repo → 404 "repository not managed", mismatch → 403. Careful dumping wide rows: SELECT columns explicitly (`webhook_id` vs `full_name` look alike).

## The authoritative step: query provider-side registration
The URL/secret GitCode actually holds is what delivery uses — never assume it matches your meta/config.
- GitCode API v5: `GET https://api.gitcode.com/api/v5/repos/{owner}/{repo}/hooks` with `Authorization: Bearer *** (project helper: `src/user/repo_manager._req`).
- Each hook: `id`, `url`, `password`, `active`, event flags. List ALL of them — multiple enabled hooks all receive delivery attempts.

## Root-cause pattern (the silent killer)
- **Stale registered URL**: a hook registered while the app's advertised `webhook_url` was stale (e.g. `https://host:8080/...` when 8080 is plain HTTP) → GitCode's TLS handshake fails → events dropped with NO server-side log at all. Registering a repo (托管) snapshots the then-current webhook_url into the provider; later meta/config changes do NOT retro-update existing hooks.
- **Legacy hooks pile up**: ngrok tunnel URLs, old public IPs — all dead but still enabled. Delete them.

## Fix sequence (GitCode example)
1. `PATCH .../hooks/{id}` body `{"url": "https://<domain>/webhook/gitcode", "password": "***"}` — in-place update, keeps the hook id (verified working).
2. `DELETE .../hooks/{dead-id}` for each legacy hook.
3. Sync server side: `managed_repos.gitcode_webhook_token` must equal the hook's password (UPDATE the row; both sides must match or events get 403). Align everything to the user-designated secret — the 托管 flow may have auto-generated a different one.
4. End-to-end verify: POST a GitCode-format payload to the PUBLIC URL with headers `X-GitCode-Token: <secret>`, `X-Gitcode-Event: push`. Expect 200 and log lines `token OK` → `calling run_pipeline`. WARNING: a valid payload for a managed repo triggers real agent execution — use a minimal/`{}` payload first (expects 400 "invalid body"/"missing repository") to prove routing+auth, then a real one only if you want the pipeline to run.
5. Header passthrough: nginx forwards custom headers as-is (no underscores in header names — underscore headers are dropped by nginx by default). `X-GitCode-Token` is safe.

## "no_route" is by design, not a bug
- A bare branch push with no issue context logs `Pipeline: no route for type=push (no_route), skip` and lands in `event_skipped`. That is the intended routing, not a delivery failure.
- Routing dispatches: issue events (issue_opened → vod; updated/comment → by issue stage), PR events, and pushes referencing issues (branch/commit `#N`). `event_route_config` (repo_key/event_type/skill/priority) adds custom routes; when it's empty, plain pushes never produce events — check it before suspecting delivery.

## The event arrived but died downstream
Delivery + auth OK is not the end — the pipeline can still lose the event AFTER `token OK`:
- **Backend-specific SQL crash**: response 200 / log shows `Pipeline:` then a pymysql traceback (observed: `OperationalError (1093, "You can't specify target table 'issue_state' for update in FROM clause")`). Root cause: SQLite-style `INSERT OR REPLACE ... VALUES ((SELECT id FROM <same table> ...))`; the compat layer rewrites INSERT OR REPLACE→REPLACE INTO but not the self-subquery. Fix pattern: SELECT-then-UPDATE/INSERT (portable). Verify: after re-running the event, the `events` table gains a row with seq>0 and the stage row exists.
- **Agent execution "Authorization Required"**: event row created (status running), then the spawned opencode exits 1 with `Authorization Required` — the CLI's provider config references an env var (`{env:HERMES_CUSTOM_API_DEEPSEEK_COM_API_KEY}`) that the systemd service environment lacks. Fix: EnvironmentFile + restart; verify via `/proc/<pid>/environ`.
- Regression-proof the fix: targeted tests on the sqlite path (grape: `tests/test_issue_state.py`, `test_upsert_idempotent` covers insert→update) PLUS a live MySQL dual-path exercise of the fixed function (insert then update the same row).
