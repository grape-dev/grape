# Let's Encrypt + nginx TLS termination (app already running on :80)

Worked: grape (FastAPI/uvicorn) on Huawei Cloud EulerOS 2.0 (aarch64), app bound 0.0.0.0:80,
domain grape-dev.topxtopx.com. Pattern applies to any single-host service.

## Steps
1. Install nginx from distro repos: `dnf install -y nginx` (HCE updates has 1.21.x).
2. Install certbot via pip — NOT in distro repos: `python3 -m pip install -i <CN mirror> certbot certbot-nginx` → /usr/local/bin/certbot. (System python 3.9 is fine for certbot.)
3. Move the app off :80 (it must free the port for nginx): change the systemd unit to bind 127.0.0.1:8000. Write unit to /tmp then `cp` to /etc/systemd/system/ — write_file refuses BOTH /etc/nginx and /etc/systemd/system paths.
4. Bootstrap phase — port-80-only nginx config (nginx CANNOT start with `ssl_certificate` pointing at a not-yet-issued cert):
   ```
   server {
     listen 80;
     server_name <domain>;
     location /.well-known/acme-challenge/ { root /var/www/certbot; }
     location / { return 301 https://$host$request_uri; }
   }
   ```
   `mkdir -p /var/www/certbot`. Restart sequence (minimize downtime): stop app → start nginx (takes :80) → start app (binds 127.0.0.1:8000). Note the app may take 10-30s to bind (DB migrations at startup) — poll `ss -tln` before declaring failure.
5. Issue: `certbot certonly --webroot -w /var/www/certbot -d <domain> --non-interactive --agree-tos --register-unsafely-without-email`
   - Webroot probe gotcha: challenge files land at `$webroot/.well-known/acme-challenge/<token>` — to probe locally, create THAT exact path, not `$webroot/probe` (else you get a misleading 404).
6. Full config: add the 443 server (proxy to 127.0.0.1:8000), `nginx -t`, reload. Key points:
   - **nginx < 1.25 has NO `http2 on;` directive** — 1.21.5 dies with `unknown directive "http2"`. Use `listen 443 ssl http2;`.
   - `proxy_set_header Host $host; X-Real-IP; X-Forwarded-For; X-Forwarded-Proto $scheme` — apps build redirect URIs from X-Forwarded-Proto (e.g. OAuth callback).
   - `client_max_body_size 100m` + long proxy timeouts for webhook/agent workloads.
7. Renewal — pip certbot installs NO systemd timer. Create:
   - /etc/systemd/system/certbot-renew.service: `Type=oneshot`, `ExecStart=/usr/local/bin/certbot renew --quiet`
   - /etc/systemd/system/certbot-renew.timer: `OnCalendar=*-*-* 00:00,12:00`, `RandomizedDelaySec=3600`, `Persistent=true`, WantedBy=timers.target
   - /etc/letsencrypt/renewal-hooks/deploy/reload-nginx.sh: `#!/bin/sh\nsystemctl reload nginx || true`, chmod +x (deploy hooks run on successful renew only)
   `systemctl enable --now certbot-renew.timer`.
8. `certbot renew --dry-run` from CN can take several minutes (ACME network is slow) — run it backgrounded with notify_on_complete, don't block the turn.

## Diagnosing "Let's Encrypt can't reach :80"
- certbot error `Timeout during connect (likely firewall problem)` = inbound :80 blocked at the CLOUD SECURITY GROUP, not the app/nginx. iptables policy ACCEPT + firewalld inactive ⇒ go check the console SG (Huawei: 安全组 入方向 TCP 80+443 源 0.0.0.0/0).
- The box's own hairpin curl to its public IP is unreliable before the SG opens — don't trust it as proof of blocking.
- External port-check APIs (check-host.net, hackertarget nmap, viewdns portscan) now sit behind API keys/CSRF walls — don't burn time; re-running certbot IS the authoritative external probe.
- SG rule propagation can lag ~1 min — retry certbot once before concluding.
- Mainland-CN gotcha: un-ICP-filed domains can be blocked on 80/443 at the platform level no matter what the SG says — ask the user if the domain is filed.
- Huawei hairpin: after SG opens, the box CAN reach its own public IP (curl https://domain/health returned 200) — useful for quick e2e checks.
