#!/usr/bin/env python
"""Compare a grape-style app's DDL table list against the live MySQL schema.

Root-cause tool for "API route 500s with (1146, Table 'xxx' doesn't exist)"
after a CREATE TABLE was swallowed at startup (compat/translate layer failed,
app logged only a [WARNING] and continued).

Usage (from the project root, e.g. /root/grape):
    .venv/bin/python <path-to-this-script>/check_ddl_vs_tables.py

Reads DB credentials from configs/db-backend.json (gitignored runtime config).
For other projects: adapt the `expected` source (here: db_setup._NEW_TABLES).
"""
import json
import os
import sys

sys.path.insert(0, os.getcwd())

import pymysql  # noqa: E402


def load_db_config():
    with open("configs/db-backend.json", encoding="utf-8") as f:
        cfg = json.load(f)
    m = cfg["mysql"]
    return m["host"], m["port"], m["user"], m["password"], m["database"]


def main():
    from src.api import db_setup  # imports the DDL list (triggers app init logs)

    host, port, user, pwd, database = load_db_config()
    conn = pymysql.connect(host=host, port=port, user=user, password=pwd, database=database)
    cur = conn.cursor()
    cur.execute("SHOW TABLES")
    actual = {r[0] for r in cur.fetchall()}
    conn.close()

    expected = {name for name, _ in db_setup._NEW_TABLES}
    missing = sorted(expected - actual)
    extra = sorted(actual - expected)

    print(f"DDL 清单中 MySQL 缺失的表: {missing or '(无)'}")
    print(f"DDL 清单外 MySQL 多出的表: {extra or '(无)'}")

    # 顺带给出缺失表的原始 DDL 翻译结果，便于定位翻译层问题
    from src.mysql_compat import translate_sql  # noqa: E402
    for name, ddl in db_setup._NEW_TABLES:
        if name in missing:
            print(f"\n--- translate_sql({name}) ---")
            print(translate_sql(ddl))
    return 0 if not missing else 1


if __name__ == "__main__":
    raise SystemExit(main())
