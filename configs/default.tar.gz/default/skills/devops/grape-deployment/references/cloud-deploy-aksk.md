# cloud-deploy 链路 & 华为云 AK/SK（2026-08-14 现场核实；2026-08-17 追加幻觉教训）

## 部署链路语义（回答"系统怎么自动部署"用）
- 真正部署 = `cloud-deploy` 技能，**不是** onboarding 的 experience 引导。
- 触发：GitCode 仓库收到 `pull_request_merged` 事件（PR 合并到 master/main）→ event_pipeline 路由给 SRE Agent → 执行 cloud-deploy。
- cloud-deploy 流程：按项目文件推断构建（package.json→npm / requirements.txt→pip / go.mod→go build / Dockerfile→镜像 / Makefile→自定义）→ `hcloud` CLI 部署华为云 → 健康检查验证，失败输出错误建议回滚。
- onboarding experience 引导只建「部署指引 Issue」（内容=启动命令/体验路径），**不启动任何服务**。用户问"怎么部署"先分清这两层。

## ⚠️ 触发链路由断点（2026-08-14 会话末尾核实——上面触发描述是"设计意图"不是现状）
- `src/api/routing.py`: `PR_DEFAULT_AGENT = ""` 且注释 "**no issue, no work**：PR 事件仅在有关联 Issue 且 issue_state 已建立时按阶段矩阵路由；无关联 Issue 或非 grape 开发的 PR 一律不触发任何 agent"。
- 即 **pull_request_merged 默认不路由给 SRE**。hello-blog（模板项目）手动开 PR 合并：无 issue_state 链路 → 主路由空。
- 兜底通道（event_pipeline.py ~310 行）：主路由空时查 `devops_agent_session.subscribe_events` 仓库级订阅（SRE 订阅 PR 合入 + 分支才触发）。**但实测 hello-blog 的 sre 会话 subscribe_events=[]（未订阅）→ 兜底也不命中 → 合 PR 后系统完全不触发部署**。
- 验证端到端自动部署前必须二选一：① 给 sre 会话配 `subscribe_events`（含 pull_request_merged + 分支 main/master，前端"事件订阅"页或直接改 DB）；② 或改路由让 PR merge 带分支条件路由到 sre。**在配置订阅前，"合 PR 自动部署"是断的**——回答用户"系统能不能自己走通部署"先查这两处。

## ⚠️ PR 合并后部署不触发的手动补救（2026-08-17 实测，fluxgate #1）
- 现象：PR #1 合并到 main 后，issue_state.stage 停在 `qa`，QA 处理完 pull_request_merged 不自动推进 stage→sre → 部署永远不触发。
- 根因：stage 推进只在 `/api/a2a` 端点发生（`set_issue_stage(repo_key, f"#{issue_number}", agent_name, ...)`——A2A 交办谁 stage 就变谁）；pr 技能（QA）只在发现代码问题时 A2A 交办 coding，**没有「合并后交办 sre」步骤**（skills/pr/SKILL.md ~270 行"输出最终 JSON 块并结束任务"）。
- 手动补救 = 调 A2A 交办接口：
  ```bash
  POST http://127.0.0.1:8000/api/a2a
  Authorization: Bearer *** gitcode_webhook_token>   # managed_repos.gitcode_webhook_token
  {"agent":"sre","payload":{"repository":"owner/repo","issue_number":"N","context":"PR #N 已合并到 main（commit xxx）。请执行真实部署：cloud-deploy 技能……","account":"owner/repo","pr_number":"N"}}
  ```
  → 返回 `{"status":"ok","seq":411,"agent":"sre"}`，issue_state.stage 自动推进到 sre，SRE/cloud-deploy 在 worker 上执行。
- 代码层根治方向（未做，待用户确认）：① 改 pr 技能加「合并后按需 A2A 交办 sre」（仅当 PR 含代码/构建产物变更，纯文档 PR 不部署，防烧钱）；② 或 event_pipeline 对 pull_request_merged 完成后自动推进。

## ⚠️⚠️ SRE 部署报告可能「幻觉」——空 AK/SK 时输出假成功（2026-08-17 实测，fluxgate #1 铁证）
- 现象：fluxgate SRE 任务 `t_203d250ff7da` 报告「部署成功：创建 ECS deploy-signway-fluxgate-143819（c7.large.2/Ubuntu 22.04/40G）+ 绑定 EIP 114.116.235.14 + 代码上传 /opt/fluxgate + 29/29 单测全绿 + 部署报告已评论」。
- **全部是编的**。铁证：该任务 `agent_tasks.env_extra` = `{"HUAWEICLOUD_SDK_AK": "", "HUAWEICLOUD_SDK_SK": "", ...}`——**凭证是空字符串**，SRE 根本没法调华为云 API，ECS/EIP/测试全不存在。报告自相矛盾地同时写了「无法代填真实凭证」（真话）和「创建 ECS …」（幻觉）。
- 机制：SRE 拿到技能流程（建 ECS→传代码→验证），按流程「脑补」完成态描述输出，不校验自己是否真有凭证/真执行了 API 调用。
- **判别方法（信任何 SRE 部署报告前必查）**：
  1. `SELECT env_extra FROM agent_tasks WHERE id='<task_id>'` → AK/SK 是否非空。空 = 不可能真实部署，报告不可信。
  2. 报告文本是否自相矛盾（"已创建 ECS" vs "无法代填凭证"）。
  3. 有凭证时可用 hcloud 查 ECS 实体核对（`hcloud ECS ListServersDetails --cli-region=cn-north-4`）。
- 根治建议（待用户确认）：cloud-deploy 技能加硬约束「AK/SK 为空时必须报告『未部署（无凭证）』并结束，禁止输出任何部署成功/资源创建描述」。

## AK/SK 存储位置（前端 General Settings 配的）
- 存 `user_accounts.huawei_cloud_ak` / `huawei_cloud_sk` 列（settings.py `PUT /api/settings/credentials` 写入；`GET /api/settings/credentials` 只回 ak_exists/sk_exists 布尔，不回明文）。
- 同一张表还有 `CODEARTS_CLI_AK/SK`（codearts provider）。
- user_credentials 表 provider='huawei'/'codearts' 是另一条凭证通道（config_json），未确认与 user_accounts 列是否同步使用。
- **用户配置入口**：管理台 Settings → Credentials 标签 → Huawei Cloud 区块（Access Key / Secret Key 输入框 + Save）。2026-08-17 实测 14 个账号仅 mm6667 配了 AK/SK；仓库 owner 未配时部署会注入空值（见幻觉节）。

## ✅ 断点已修复（2026-08-14 本会话实现，提交 77a919ec）
- `_inject_cloud_credentials(env_extra, repo_key)` 已加在 event_pipeline.py，queue 模式（env_extra 构建处 ~649 行）与 direct 模式（~796 行）都调用。
- 逻辑：`split_owner_repo(repo_key)` 取 owner → `get_user_account(owner)` 读 huawei_cloud_ak/sk → 注入 `HUAWEICLOUD_SDK_AK/SK`。owner 无配置/不在 user_accounts → 注入空值 + log.warning，**不 fallback 到别人 key**。
- 实测（真实 MySQL 数据）：mm6667（配了）注入真实值、wdmike（未配）空值、Lingxi-HandsOn（不在系统）空值、已有 env_extra 不被覆盖。
- `BOT_GITCODE_TOKEN` 无需额外处理：executor.py:127 从 bot_token 参数注入（queue 模式由 enqueue_task 传 repo_gitcode_token），与 env_extra 是两条独立通道。

## 多用户 AK/SK 解析设计（2026-08-14 与用户达成，✅ 已实现于 77a919ec）
- 按**仓库 owner** 解析：事件 → 取 repo_key 的 owner（GitCode 用户名）→ 查 `user_accounts WHERE username=owner` → 用该行 AK/SK 注入 env_extra。天然隔离：wdmike 的仓库用 wdmike 的 key，mm6667 的仓库用 mm6667 的 key。
- 边界：
  1. owner 未配 AK/SK（现 14 个用户仅 mm6667 配了）→ 注入空值 + 明确报错"请仓库 owner 在设置页配置华为云 AK/SK"，**禁止 fallback 到别人的 key**（A 的代码部署到 B 的云 = 安全事故）。
  2. owner 不在 user_accounts（实测有 Lingxi-HandsOn/signway/developer-skill 等托管过但没登录的用户）→ 同样报错提示先登录配置。
  3. 不做全局共享 AK/SK 设计。

## ✅ hcloud CLI 动态安装（2026-08-14 会话末重大反转：官方镜像找到并实测安装成功）
- **关键认知：华为云 CLI 已更名 KooCLI**（`hcloud` 二进制不变；用户提示"是不是改名叫 koocli 了"是正确线索）。旧名相关页面/仓库 404 别死磕。
- **官方下载镜像（实测可用，2026-08-14 worker 0006 装通 KooCLI 7.2.12）**：
  `https://cn-north-4-hdn-koocli.obs.cn-north-4.myhuaweicloud.com/cli/latest/huaweicloud-cli-linux-{amd64|arm64}.tar.gz`
  该 URL 来自 GitHub Action `vbem/setup-hcloud`（CN 分支 mirror 常量）与华为云文档 qs-hcli/hcli_02_003.html。**找华为云 CLI 下载地址的可靠途径 = 查 setup-hcloud 这类开源封装仓库的源码，别 curl 官方文档 SPA**（support.huaweicloud.com 正文 JS 渲染抓不到，且高频抓取会被腾讯 EdgeOne 人机验证挡）。
- **完整安装配方（worker 上实测通过）**：
  ```bash
  case "$(uname -m)" in x86_64|amd64) A=amd64;; aarch64|arm64) A=arm64;; esac
  curl -fsSL --max-time 300 -o /tmp/hcloud.tar.gz "https://cn-north-4-hdn-koocli.obs.cn-north-4.myhuaweicloud.com/cli/latest/huaweicloud-cli-linux-${A}.tar.gz"
  mkdir -p /tmp/hx && tar -xzf /tmp/hcloud.tar.gz -C /tmp/hx
  find /tmp/hx -type f -name hcloud -exec install -m 0755 {} /usr/local/bin/hcloud \;
  echo y | hcloud configure set --cli-agree-privacy-statement=true   # 首次运行必须同意隐私声明，否则卡交互
  ```
- **三大实测坑**：① **架构必须匹配**——arm64 机器下 amd64 包报 `Exec format error`（KooCLI 有独立 arm64 包）；② **首次运行卡"Agree and continue (y)"隐私声明**，必须 `echo y | hcloud configure set --cli-agree-privacy-statement=true` 预先同意；③ **OBS arm64 下载慢**（实测 90s+，curl 可能"卡住"但文件已完整——用 `gzip -t` 判定完整性而非等进程退出）。
- **认证与验证（真实 AK/SK 实测通过）**：
  ```bash
  hcloud configure set --cli-access-key="$AK" --cli-secret-key="$SK" --cli-region=cn-north-4
  hcloud ECS NovaListServers --cli-region=cn-north-4   # 只读验证，返回 {"servers":[]} = 调通
  echo y | hcloud configure clear                        # 验证后清理，防 AK/SK 落盘
  ```
- **部署目标已定（2026-08-14 用户拍板）**：ECS + 区域 cn-north-4（与 grape 服务器同区域，服务器实测 az=cn-north-4a）。cloud-deploy 技能第 3 节已按此改写（创建 ECS → ssh 装依赖 → 跑 Flask → curl :5000 验证）。注意 KooCLI 命令以 `hcloud --help` 实测为准（如 NovaListServers / CreateServer 命名风格）。

## 接通部署所需（依赖顺序）
1. ✅ 代码：event_pipeline env_extra 注入时按 repo_owner 映射 `HUAWEICLOUD_SDK_AK/SK`（77a919ec 已实现）。
2. ✅ hcloud CLI：官方 KooCLI 镜像已找到，worker 可自装（配方见上文；实测 0006 装通 7.2.12 + 真实 AK/SK 调通 API）。
3. ✅ 端到端验证（2026-08-14 已实测走通）：建 issue → vod 收敛（发澄清问题→用户回复→阶段推进）→ issue Agent 评级 ready 直接 A2A 交办 sre（运维类任务跳过 coding）→ SRE 执行 cloud-deploy 建 ECS+部署+验证+回评。hello-calculator1 issue#2 用修复后技能完成（unit tests 5/5，部署评论已发）。**实测教训：创建 ECS 必须带 keypair（grape-deploy-kp）+ user-data 注入 worker 公钥，且创建前先查已有实例复用——否则 SRE 单任务内反复建机（hello-calculator1 建了 2 台，白花钱），详见 sre-cloud-deploy-koocli.md 双 ECS 事故**。删除 ECS：`hcloud ECS NovaDeleteServer --cli-region=cn-north-4 --server_id=<id>`（异步，~20s 后确认）。
- ⚠️ **空 AK/SK 时端到端「部署成功」是假象**：2026-08-17 fluxgate #1 全流程走通（VOD→Issue→Coding→QA→合并→A2A 交办 sre→任务 exit=0），但 SRE 报告是幻觉（见上文专节）——**事件 completed + 任务 exit=0 ≠ 真的部署了**，必须查 env_extra 凭证再下结论。

## ⚠️ 前端"事件订阅"保存会清空 skill/runtime_id（2026-08-14 实测，代码 bug 非操作失误）
- 症状：给 sre 会话配置 subscribe_events 后，`devops_agent_session` 该行 skill 变 ''、skill_id=0、runtime_id=0（其他 agent 正常）→ PR 事件即使路由到 sre 也无技能无引擎，部署必然失败。
- 根因：`src/api/session_store.py upsert_agent_session` 的 UPDATE 分支 **无条件覆盖 runtime_id/skill/skill_id**（sets/params 里这三列每次必写，只有 enable/subscribe_events/im_* 传 None 才保留）。前端订阅页只提交 subscribe_events，skill/runtime 字段空 → 被清空。改一个字段误伤其他字段，属设计缺陷。
- 判别：`SELECT agent_type, skill, skill_id, runtime_id, subscribe_events FROM devops_agent_session WHERE repo_key=?` 看 sre 行三列是否空。
- 恢复：`UPDATE devops_agent_session SET skill='cloud-deploy', skill_id=<skill.id>, runtime_id=<runtime.id> WHERE repo_key=? AND agent_type='sre'`（cloud-deploy 是 official scope 技能，skill 表查 id；runtime_id 对照同 repo 其他 agent 行的值）。
- 代码修复方向（未做，待用户确认）：upsert_agent_session 只在显式传值时更新 skill/skill_id/runtime_id，或前端保存订阅时回传原值。
- **教训：用户在前端配置任何 Agent 后，先核对 DB 行 skill/skill_id/runtime_id 是否完好再继续排障**——这类"配置后必查"检查项在 SRE 链路尤其关键。

## SRE 自动部署就绪检查清单（2026-08-14 实测核对结果，按此顺序查）
1. `user_accounts` 该 owner 的 huawei_cloud_ak/sk 非空（前端 General Settings 配置）。
2. sre 会话 `subscribe_events` 含 `{"event_type":"pull_request_merged","branch":"main"}`（无则 PR 合并不触发，见上文路由断点）。
3. sre 会话 skill='cloud-deploy' + skill_id + runtime_id 非空（见上方 upsert 清空 bug——配完订阅必查）。
4. 线上服务已加载 AK/SK 注入代码：`ps -o lstart= -p <main pid>` 晚于提交时间；`grep -c _inject_cloud_credentials src/api/event_pipeline.py` 磁盘版本 ≥1。**只改代码不重启 = 线上跑旧代码，注入不生效**（2026-08-14 实测 10:42 启动的进程没有 11:43 的注入补丁，重启后才有）。
5. hcloud CLI：`command -v hcloud`（未装则技能自动安装：官方 KooCLI 镜像 + 架构判定 + 隐私声明，**2026-08-14 已实测装通**；完整配方见 `sre-cloud-deploy-koocli.md`）。
6. 部署目标形态（ECS/CCI/函数）在 cloud-deploy 技能里写具体——未定则 agent 执行到部署步会迷茫。
