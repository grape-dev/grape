# Worker 安装包升级三坑（2026-08-17 实测，/opt/grape 一键安装包形态）

## 背景
2026-08-17 worker 全离线事故（401 批量 revoke → 422 `_reregister` 元组 bug）修复后需升级 5 台 worker。
诊断链见 `worker-credentials-bulk-revoked.md`（401 批量 revoke）与 `worker-reregister-tuple-bug.md`（422 元组 bug）。
本文只记录**升级执行本身**踩到的坑。

## 坑①：root worker 实际跑 /opt/grape 安装包形态，不是 git 形态
- systemd `ExecStart=/opt/grape/.venv/bin/python -m src.runtime.agent`，WorkingDirectory=/opt/grape
- `/root/grape` 的 git clone 仍在（可 git pull/log 查版本），但**服务进程不跑它**——升级走安装包重装，不是 git 更新
- 判定：`systemctl cat runtime-agent | grep ExecStart`、`cat /etc/grape/worker.version`
- 版本自检：worker 启动时比对本地 `worker.version` vs 服务端 `install/latest`，不一致打 WARNING「请重新执行一键安装命令升级」（正常提示，重装后对齐）

## 坑②：打包缓存只认 git HEAD，未提交修复不触发重建
- 包缓存 `data/cache/worker-package/{grape-worker.tar.gz,VERSION}`，VERSION = `git-<HEAD>-w<wheels指纹>-p<python指纹>`
- `build_package()` 判断 `cur == package_version()` 命中即返回**旧包**——git HEAD 没变（修复未 commit）→ 重建不会发生，下发的还是旧代码
- **改完 worker 端代码必须**：
  ```bash
  rm -f data/cache/worker-package/grape-worker.tar.gz data/cache/worker-package/VERSION
  # 再触发重建（worker 下载时自动，或 ./.venv/bin/python -c "from src.worker_package import build_package; build_package()"）
  ```
- **验证包内容**（版本号相同不代表内容新）：
  ```bash
  tar -xzf data/cache/worker-package/grape-worker.tar.gz -O grape-worker/src/runtime/agent.py | grep 'ids, _probe'
  ```
- 打包读的是**服务端磁盘文件**（MANIFEST 目录遍历），所以未提交改动会进包，只是版本号不变——这也意味着服务端 checkout 在 merge-test/半成品分支时下发即半成品（见 SKILL.md Worker 安装包节）

## 坑③：install-worker.sh 默认 --server 是生产域名，dev 必须显式传
- `scripts/install-worker.sh` 未指定 `--server` 时默认 `https://grape.topxtopx.com`（**生产域名**）
- dev 环境漏传后果（2026-08-17 实测 0003）：装错包（git-73f9a79e）+ **污染 /etc/grape/runtime.env 的 RUNTIME_SERVER_URL** → 服务 activating 起不来
- 正确命令：
  ```bash
  curl -fsSL https://grape-dev.topxtopx.com/api/runtime/install | bash -s -- --token '<rta_...>' --server https://grape-dev.topxtopx.com
  ```
- 已污染恢复：用正确 --server 重跑一键安装即覆盖 runtime.env，无需手工清

## 升级脚本（可复用）
`/root/deploy/upgrade_workers_0817.py`（paramiko，逐台）：读 runtime.env token → curl install（带 --server）→ systemctl restart → sleep 10 → 验证 version + is-active。
5 台 IP：0002=192.168.0.115、0003=192.168.0.64、0004=192.168.0.39、0005=192.168.0.194、0006=192.168.0.213（root/kaifazhe@123）。

## 升级成功验证（证据链）
- worker journal：`RuntimeAgent registered: [54, 55]`（**单层列表**，元组形态 = 未修复）
- nginx claim：`/runtimes/60/tasks/claim` + `/runtimes/61/tasks/claim` 分开 200（`%5B60,%2061%5D` = 未修复）
- 心跳 15s 间隔稳定 200；agent_runtimes 对应行 status='online'、last_seen_at 持续更新
- 引擎名含机器编号后缀（`opencode-worker-ecs-grape-de-0003`）= sanitize_device 保头保尾截断生效

## 归属速查（改服务端仓库 ≠ worker 生效）
- `src/runtime/agent.py`（_reregister/_run_loop）= **worker 客户端代码**，服务端 src/api/ 从不 import 它；改仓库只是改打包源，**生效必须 worker 重装**
- `src/runtime/instances.py` / `src/user/db.py`（解析层）= 服务端代码，重启 grape-main 生效
- 判定服务端是否加载某模块：`grep -rn "runtime.agent" src/api/ src/user/`（无引用 = worker 端专属）
