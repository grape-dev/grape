# 控制台时间本地化：MySQL CST 无时区 → 展示错位 +8h（2026-08-17 实施，feat/event-time-localization）

## 根因（跨后端时间存储语义不一致）
| 时间来源 | 存储格式 | 语义 |
|---|---|---|
| events.created_at 等 MySQL 默认 `cast(now() as char)` | `2026-08-17 20:46:19` 无时区 | CST（服务器本地，UTC+8） |
| events.started_at/completed_at、agent_tasks 时间 | `2026-08-17T12:46:19.163342+00:00` | UTC ISO（代码 isoformat 写入） |
| SQLite 后端 created_at（`datetime('now')`） | 无时区 | UTC |

前端 `fmtLocalTime`（api.js）用 `Date.UTC(...)` 解析无时区字符串再转本地 → MySQL 的 CST 被当 UTC → **错位 +8h 且跨天**（实际 20:46 显示 04:46 次日）。纯字符串无法区分「无时区=UTC 还是 CST」，必须后端按 backend 语义归一化。

## 方案（用户拍板 A：后端序列化统一 + 前端统一转换）
1. **后端工具** `src/api/time_utils.py` `normalize_event_time(raw)`：
   - 带时区（Z / ±HH:MM）→ 解析转 UTC（幂等）
   - 无时区 → `load_db_backend_config().backend` 判定：mysql=CST(+08:00) 转 UTC；sqlite=UTC 加 +00:00
   - 坏值/空值 → 原样返回（不抛异常，不破坏数据）
   - **幂等容错** → 可无脑套到所有时间序列化点（通用机制，非一次性补丁）
2. **序列化点接入**（全部输出 created_at/started_at/completed_at/last_active_at 的地方）：
   - event_store.py get_events / get_events_grouped_by_issue
   - routes/events.py 详情 / 分页列表 / event_thread
   - routes/dashboard.py recent_events + agent_recent_events + agent_sessions.last_active_at
   - routes/agents.py recent_events + vod_conversations
   - routes/pipeline.py / routes/tasks.py / routes/runtime.py（任务列表）/ routes/knowledge.py / routes/settings.py（凭据）
   - session_store.py / session_manager.py（get_user_conversations/get_conversation/get_messages）
3. **前端**：
   - `fmtLocalTime` 增强：正则支持 `.ffffff` 毫秒 + `±HH:MM` 偏移（偏移还原绝对 UTC 时间点）；无偏移按 UTC
   - agents.js Event History：`substring(11,16)`（仅 HH:MM）→ `substring(5,16)`（MM-DD HH:MM）
   - events.js 运行日志 `_tlLine`：`created_at.slice(11,19)` 直显 UTC → `fmtLocalTime(...).substring(11,19)`
   - knowledge.js 两处 `replace('T',' ').substring(0,16)` 直显 → `fmtLocalTime`

## ⚠️ 前端改 JS 必 bump index.html `?v=` 版本号
改了 api.js/agents.js/events.js/knowledge.js → index.html 里 `api.js?v=10→11` 等逐个 bump，否则浏览器缓存旧文件、功能"没生效"（本次 4 个文件全 bump，提交单独 chore commit）。

## 验证
- `tests/test_time_utils.py`（10 用例：mysql/sqlite 语义、+08:00/-05:00 转 UTC、Z 结尾、空值/坏值兜底、幂等）
- 生产库实测：`get_events("gitcode:...")` created_at 输出 `2026-08-17T14:41:25+00:00`（CST 22:41:25 → UTC ✓）
- 前端：`TZ=Asia/Shanghai node` 实测 fmtLocalTime 三种输入全部正确转本地
- 部署后验证静态文件：`curl http://127.0.0.1:8000/static/js/api.js?v=11 | grep 新函数标记`

## 部署注意
- 后端改动需重启 grape-main + grape-webhook；静态文件即时生效（但要 bump ?v=）
- 本次重启又踩 MySQL metadata lock（ALTER chat_agent_session 卡 Waiting）→ KILL 本机 IP 的 Sleep+trx RUNNING 连接（含**新进程自己连接池**的未提交连接）后迁移跑完，见 SKILL.md metadata lock 节
- worker 无需升级（session_manager 是服务端内部模块，worker 不 import；runtime.py 序列化是服务端路由）
