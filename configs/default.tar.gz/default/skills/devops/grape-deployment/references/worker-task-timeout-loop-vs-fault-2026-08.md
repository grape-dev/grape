# worker 任务 600s 超时循环 vs worker 故障 — 判别配方（2026-08-18 实测）

## 场景

用户报「worker 0003 是不是有问题了」——症状表象：`agent_tasks` 里出现
queued 任务 + 一个 dispatched/running 任务停留超 1 分钟未完成。

## 判别链（三步，先看数据再下结论，勿凭表象猜）

1. **worker 健康信号（nginx access.log 按 worker 公网 IP grep）**：
   `grep <ip> /var/log/nginx/access.log | tail` —— 心跳/claim 每 ~3 秒 200
   = worker 活着；无 401/422/500 = 凭据/协议正常。0003=120.46.209.201。

2. **runtime 行状态（agent_runtimes）**：`status='online'` + `last_seen_at`
   新鲜（秒级）= 机器正常。

3. **任务流转时间线（journalctl grep task_id）**：看 claim → start → fail
   的完整轨迹。本次 t_ffed85a6d828：
   ```
   23:52:53 claim → start
   23:55:51 / 00:00:52 再次 claim（worker 并发槽占用/续期）
   00:02:53 Task failed: exit=1 err=task timed out after 600.0s
   00:02:55 下一个 queued 任务 t_5d4d8ab9cdae 立即被 claim → start ✅
   ```
   **600s 超时 = 任务级问题（AI 跑 10 分钟没完成），不是 worker 故障**——
   worker 在超时后 2 秒就接走了下一个任务，流转完全正常。
   之前看到的「queued 卡住」只是**瞬间状态**（前一个任务占用并发槽）。

## 关键结论

- **worker 健康三连 = 心跳 200 + runtime online + 任务 claim/start/fail 正常流转**。
  三者都满足时，任何「任务没动」都是任务级/队列级问题，别怀疑机器。
- **SSH 直连 worker 超时 ≠ worker 故障**（本次 0003 SSH connect timed out =
  安全组未放行本机→worker 22 端口，不影响 worker 功能；判健康用 nginx + DB 证据）。

## 撤回/同步请求的超时循环模式（issue 任务）

fluxgate #1 撤回请求的典型循环：
1. 用户 Issue 评论「帮我把这个skill从clawhub撤回」→ 触发 issue 任务
2. issue 任务查历史（task_messages type='text'：'The user repeated the
   withdrawal request. The SRE agent already reported that the withdrawal
   is blocked by missing ClawHub...'）→ 回复用户「凭证阻塞，请提供令牌或手动下架」
3. **回复后任务未正常终止**，挂到 600s 超时 → 事件 failed
4. 用户再次评论 → 新 issue 任务 → 重复 2-3 → 循环

判别：events 里多个 issue_comment 全 failed + errors=`["task timed out after 600.0s"]`
+ task_messages 显示任务其实只跑了 1-3 步就输出回复文本。
**根因不是任务复杂度，而是「回复后未正常 exit」+ 凭证阻塞让用户反复重试**。
修复路径 = 解决凭证归属（见 skill-publish-v42-gaps ①），循环自然消失。

## task_messages 表结构（查执行过程用）

列：`id / task_id / seq / type / tool / content / input_json / output / created_at`
- **无 role 列**（查 type：'step_start'/'step_finish'/'text'/'tool_use'）
- 按 task_id 查不到消息时，用 `runtime_session_id` 反查：
  `SELECT ... FROM task_messages WHERE task_id IN (SELECT id FROM agent_tasks
  WHERE runtime_session_id='<ses_xxx>')`
- 服务端 journalctl 只记 claim/start/fail（worker 侧步骤日志在 worker 机，
  服务端拿不到——SSH 不通时用 task_messages + journalctl grep task_id 双查）
