# skill 发布设计演进（2026-08-17，feat/skill-sync-multiplatform）— 最终决策链 v4.1 定稿

特性分支: feat/skill-sync-multiplatform（设计文档 = 分支 docs/skill-publish-design.md v4.1）
前置调研: references/clawhub-publish-mechanism.md（ClawHub CLI/API/令牌获取）
执行偏差实录: references/skill-sync-execution-gap-2026-08.md（SRE 考古 + 账号共用）

## 设计演进脉络（为什么是今天这个形态）

1. **v1.0**：初版 = 插件架构（src/plugins/loader + 平台插件目录）+ sync_service + skill_sync_bind 表，触发=聊天指令
2. **v2.0**：加「多技能配置」（配置页多选 + skill 列 JSON 数组）——**被用户否决**（"skill还是支持一个不改成多个"）
3. **v3.0**：回到单技能模型——skill-publish 独立技能（配置页切换选用），同 deploy-guard/build-debug 待遇
4. **v4.0/v4.1**：方案 A 定稿——**废弃 skill_sync_scene，全部统一走技能方式**；最终决策见下

## 用户拍板的 11 项决策（v4.1 定稿）

| # | 决策项 | 决定 |
|---|---|---|
| 1 | skill 配置模型 | **保持单选**（一个 agent 一个技能，不改多选；配置页 `.cfg-skill` select 不动） |
| 2 | skill-publish 形态 | 独立技能（切换用），进技能池，配置页可切换 |
| 3 | skill_sync_scene | **废弃（A1 彻底）**：scene + sync_service + bind 表 + upsert_bind 全删 |
| 4 | 同步请求统一链路 | 对话/Issue 入口 → SRE → skill-publish 技能执行（一套实现） |
| 5 | 对话回传 | **复用 skill 创建时的原 Issue（#N 评论「请同步」）**，结果回评 Issue；对话回复「已交办，见 Issue #N」——与部署服务现状同模式（chat 只引导，不建新回传机制） |
| 6 | 已发布 skill 遗留 | skill-publish 技能接管（下架流程支持，靠技能定位仓库目录，不依赖 bind 表） |
| 7 | 配置页切换影响 | 接受（用户按需切换，部署时切回 cloud-deploy） |
| 8 | 发布范围 | **ClawHub + GitHub + Gitee 三平台** |
| 9 | 确认策略 | **默认二次确认**（评论「确认发布【skill vX】到 {平台}？回复『确认』执行」）；用户明确「直接发布/不用确认」→ 跳过确认直接执行 |
| 10 | 幂等 | 同 slug 已存在 → **自动版本递增重新发布** |
| 11 | 令牌注入 | 仅 sre 任务、按执行用户从 user_platform_tokens 取（不是仓库 owner） |

## 改动清单（3 新增 + 4 删除 + 2 改造）

新增:
1. skills/skill-publish/SKILL.md — 三平台发布/下架流程（读 $CLAWHUB_TOKEN/$GITHUB_TOKEN/$GITEE_TOKEN → POST/DELETE → SHA256 校验 → 回评）+ 安全约束（只用注入令牌/禁止考古 /usr/local/lib/hermes-agent/403 即停/token 不落盘）
2. configs/skill-description.json seed — (skill-publish, agent_type=sre, official)，配置页下拉框出现「技能发布」
3. src/api/event_pipeline.py `_inject_platform_tokens(env_extra, user_id)` — 仅 sre 任务、按执行用户注入平台令牌（无则空串，技能报「未配置」跳过该平台不阻塞其他）

删除:
4. src/im/skill_sync_scene.py（硬编码场景废弃）
5. src/plugins/sync_service.py（发布逻辑废弃；worker MANIFEST 本就不含 plugins，技能无法查 bind 表 → bind 表失去意义）
6. src/api/db_setup.py 移除 skill_sync_bind 建表（**存量表需部署时手动 DROP**）
7. src/user/db.py 移除 upsert_bind 调用（~960 行）

改造:
8. src/im/handler_async.py 移除 scene 调用（_run_sync_scene 430 行 + match_scene 544-551 行）
9. skills/chat/SKILL.md 加指引：「同步/发布/下架 skill 请求 → 复用原 Issue 评论『请同步…』→ 流水线 SRE 执行」

## 硬约束（用户明确，违反即被骂「破坏她现有的架构了」）

- ❌ 不改 pipeline / webhook / A2A 交办逻辑（Issue 模式保持 webhook→events→pipeline→Issue Agent→A2A→SRE）
- ❌ 不改配置页单选模型 / DB 列
- ❌ 不改 worker 协议 / 安装包 / OBS 分发
- ❌ 不改对话 skill_sync_scene 的识别入口（只删场景，聊天入口仍走 process_chat_async → chat 技能）

## 关键教训（本会话被用户严厉纠正 3 次）

1. **「某技能用不到」是错误断言**：skill 表里的技能是配置页可选项 + AI 能力池（见 references/skill-selection-and-multiconfig.md 3 路径机制）——验证技能是否被用查 3 条路径（配置页下拉 / agent-skill-mapping 路由默认 / get_skill_capabilities 能力列表），不是 grep 引用计数。
2. **解法 = 加技能，不是改流程**：Issue 评论同步请求走到 SRE 无技能指引（只有 cloud-deploy）→ SRE 考古。用户明确「不能改流程，破坏架构」→ 给 SRE 加 skill-publish 技能 + 服务端注入令牌，任务流转零改动。
3. **设计讨论期间勿自主主张**（用户两次纠正「继续聊天啊。方案还不确定」「你不要自主主张」）：讨论中不更新/提交/推送文档，等用户明确「更新文档推送」；不替用户拍板、不给倾向性推荐；用户逐项确认后才写进文档；被打断先复述确认理解再继续。

## 对话 vs Issue 事件传播差异（为什么 scene 只接对话）

- 对话（飞书/网页）→ process_chat_async → scene 直接拦截（识别→确认→publish/remove，不进 events 表、不走 SRE）
- Issue 评论 → webhook → events → pipeline → Issue Agent → A2A → SRE（skill=cloud-deploy，无 sync 能力）
- 用户最终选择方案 A：两条路都统一到「SRE + skill-publish 技能」，scene 废弃
