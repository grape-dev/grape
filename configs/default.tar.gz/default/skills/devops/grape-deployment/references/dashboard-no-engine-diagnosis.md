# Dashboard「无 engine，不可用」红字 = 会话未绑定引擎（2026-08-17 实测）

## 症状
- 前端 Dashboard 的 Agent 卡片 Backend 位置显示红字「无 engine，不可用」。

## 判定链路（前端 → 后端 → 数据）
1. `src/api/static/js/pages/dashboard.js`（~line 51）：`const backend = ag.backend || ''`，空 → 渲染红字（engine-selection-design.md v2：无硬编码默认，空 = 无 engine）。
2. 后端 `src/api/routes/dashboard.py`：
   ```sql
   SELECT s.agent_type, r.name, s.status, s.last_active_at, s.enable
   FROM devops_agent_session s LEFT JOIN agent_runtimes r ON s.runtime_id=r.id
   WHERE s.repo_key=***
   ```
   `backend = agent_runtimes.name`。LEFT JOIN 查不到（runtime_id=0 或指向已删除行）→ backend 空 → 红字。
3. 验证技巧：直接 pymysql 模拟该 SQL 逐仓库查 backend，**无需登录态**（比 curl API 快）。

## 根因
`get_or_create_agent_session`（src/api/session_store.py ~line 130）：backend 参数为空 → runtime_id 直接写 0；非空则 `pick_engine → get_runtime_id_by_name → ensure_default_backend` 全失败 → 0。即**创建会话那一刻没绑上引擎**（调用方未传 backend 或当时无可解析引擎）。event_pipeline 入口在 runtime_id 为空时 `_fail_event("入队失败：无可用引擎")` 提前 return，不会建会话——所以 runtime_id=0 会话多来自 onboarding/host/场景配置路径。

## 2026-08-17 现场数据
- runtime_id=0 会话分布（创建时间 08-12~13，b8d060ff 合并部署后那批）：
  - mm6667/test1：5/5 全无
  - developer-skill/pmo-skill：coding、vod
  - signway/fluxgate：sre、vod
  - wdmike/gallery：coding、sre、vod（vod 绑 agent_runtimes.id=11，该行已不存在 → JOIN 失败同样红字）
  - wdmike/snake-game：sre、vod
  - songspace/shelldev：sre
- ⚠️ **假健康陷阱**：dashboard JOIN 只查 agent_runtimes 行存在与否，**不查 runtime_credentials.status**。凭据被 revoke 后旧行保留（offline），绑旧行的会话（如 redbook-operate 绑 id 13/17，凭据今早 10:42 被批量 revoke）仍显示 'opencode'——显示有引擎、实际凭据已吊销。
- 批量 revoke 后重新注册的 5 台 worker 新引擎行（agent_runtimes id 52-61，opencode+hermes，global，online）**无任何会话绑定**。
- 现存会话绑定集合 {1,5,11,13,15,17,20,21,23}：13/15/17/20/21/23 对应凭据已 revoke；11 行已删；1 是本机 credential_id=0 引擎（offline）；5 对应凭据 9（revoked）。

## 修复
```sql
-- 无 engine 会话绑到新引擎行。claim 故意不校验 runtime 归属，任意 active worker 可接，绑哪行都行。
UPDATE devops_agent_session SET runtime_id=52
WHERE repo_key='gitcod...est1' AND agent_type IN ('vod','issue','coding','qa','sre');
-- 也可顺手把绑已 revoke 凭据旧行（13/15/17/20/21/23）的会话迁到新行，消除假健康。
```
或 Agents 设置页逐个选引擎保存。⚠️ 动手前先问用户确认（涉及多仓库/多 owner 会话）。

## 坑
- `agent_runtimes` 表**无 runtime_id 列**（列：id/credential_id/name/display_name/provider/binary/installed/cli_path/version/healthy/pip_package/status/last_seen_at/scope/owner_id/updated_at/busy_slots/max_concurrent）；`devops_agent_session.runtime_id` 指向 `agent_runtimes.id`。查表先 SHOW COLUMNS，别凭记忆选列。
- dashboard.py 两个查询都包 try/except: pass——SQL 若在 MySQL 抛错会**静默**返回空 agents（5 类型全走 append 分支 backend=''→全红字）。判定前先确认 SQL 原样能在 MySQL 跑（本场景实测可跑，不是此原因）。
- dashboard 的 backend 语义 = 引擎名（agent_runtimes.name），不是凭据名；Engines 视图（settings.py get_agent_runtimes）则跳过 revoked 凭据的 runtime 行（47947195 修复）。
