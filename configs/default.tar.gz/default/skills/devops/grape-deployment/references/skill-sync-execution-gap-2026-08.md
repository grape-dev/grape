# Skill-Sync 实际执行路径偏离设计（2026-08-17 fluxgate #1 实测）

## 场景

开发者在 signway/fluxgate Issue #1（创建华为云 VPC 列表查询 skill）评论
「帮我把这个skill同步到clawhub」，期望系统自动发布到 ClawHub。

## 设计 vs 实际

| 环节 | 设计（v4.7 文档） | 实际执行 |
|---|---|---|
| 入口识别 | chat/issue 技能识别 skill-sync 场景 → 调 POST /api/sync | Issue Agent 把「同步 ClawHub」归类为发布/部署类操作 → A2A 交办 SRE |
| 发布主体 | src/plugins/ 插件框架（loader + sync_service） | SRE 用 **cloud-deploy 技能**自由发挥（该技能本是华为云 ECS 部署用） |
| 令牌 | 开发者自己的令牌（user_platform_tokens 按用户隔离） | SRE 翻 worker 上 /usr/local/lib/hermes-agent 考古 clawhub 工具（test_skills_hub_clawhub.py），自己 curl ClawHub API |
| 二次确认 | 发布前必须确认 | 无（直接执行） |
| 重复检测 | slug 已存在提示覆盖 | 无 |
| 审计 | 插件审计 | 无（agent 自觉报告） |

## 证据链

1. `agent_tasks` 查 seq=547：`skill='cloud-deploy'`（不是 sync 插件）、runtime=60（worker 0006）
2. journalctl 查 SRE 任务步骤：`tool_use: read /usr/local/lib/hermes-agent/tests/tools/test_skills_hub_clawhub.py`、
   `find /usr/local/lib/hermes-agent -iname "*clawhub*"`、`ls /usr/local/lib/hermes-agent/tools/ | grep -iE "skill|hub|publish|registry"`
   —— 即 worker 在 Hermes 安装目录考古发布方式
3. 全程 journalctl grep `sync_service` 无任何调用痕迹 → 插件框架未被执行
4. 结果却「成功」：v0.1.0 发布到 https://clawhub.ai/yangaiwu/skills/huaweicloud-vpc-list，
   声称 SHA256 与仓库 6 文件逐字节一致 + ClawHub 安全审计 Pass + dry-run 通过

## 发布账号隐患（多用户隔离未生效）

- `user_platform_tokens` 表里 admin / obs_mysql_user / xiaowu2119 三行**共用同一个 clh_ token**
  （clh_K3SFX5ljrXkNsAIxCidDT3XnbVNH_DuxNdW5YmWipzU）
- 发布结果账号 @yangaiwu **不在 user_accounts 表**（`SELECT ... WHERE username LIKE '%yangaiwu%'` 空）
- 即：发布用的令牌归属不明、发到谁的账号下不明——「开发者自己的账号」设计落空

## 判别方法（未来任何 skill-sync 任务）

1. `SELECT id, agent_type, skill, runtime_id FROM agent_tasks WHERE event_seq=<seq>`
   - `skill='cloud-deploy'` → agent 自由发挥路径（偏离设计）
   - `skill='sync-*'` 或走 sync_service → 插件框架路径（符合设计）
2. `journalctl -u grape-main | grep sync_service` 有调用 = 插件被执行
3. 发布账号核验：`SELECT * FROM user_platform_tokens` 看 token 是否按用户隔离（多行同 token = 隔离失效）

## 修复方向（未实施，待用户拍板）

1. Issue Agent / chat 技能需知道「skill 同步 = 调 /api/sync 系统能力」，不得 A2A 交办 SRE
2. 或把「同步 ClawHub」做成 SRE 技能里的标准流程（但令牌/账号需按用户隔离）
3. 令牌治理：user_platform_tokens 每用户独立 token，发布账号 = 该用户的 ClawHub 账号

## 触发测试坑（同会话发现）

用 bot token（grape_dev_bot）在托管仓库建 Issue 验证流程会被 webhook 跳过：
`Pipeline skip: self-comment from bot=grape_dev_bot`（防 bot 自触发循环，设计行为）。
要触发 pipeline 必须用**真实用户身份**（owner token）建 Issue。
