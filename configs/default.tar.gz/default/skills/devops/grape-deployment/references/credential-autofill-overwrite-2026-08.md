# 凭据输入框被浏览器自动填充覆盖(2026-08-18 实测,已修复)

## 症状
设置页华为云 Access Key / Secret Key "隐藏功能不稳定":时好时坏。用户反映 AK 显示/保存行为异常。

## 根因(与 #72 占位符覆盖是两码事)
- settings.js 的 AK/SK 输入框 `type="password"` 且**无 autocomplete 属性** → Chrome/Edge 把本机保存过的密码(可能
  是 GitCode 登录密码或任意站点密码)自动填充进 AK/SK 框,显示为圆点。
- 用户以为"留空了"(值已回显或占位符"已配置,留空保持不变"),直接点 Save → 前端判定"有值" → 把浏览器自动
  填充的密码写进 `user_accounts.huawei_cloud_ak/sk` → 覆盖真实 AK → 部署任务注入假 AK 调华为云 401。
- "不稳定" = 浏览器有时填有时不填(取决于密码管理器状态/是否保存过该站密码),不是代码逻辑随机。
- 判别:查库 `huawei_cloud_ak` 值是否被改成与配置时不同;Chrome 下打开页面看输入框是否出现圆点(自动填充)。

## 修复(2026-08-18 已部署 dev 93cb9396,特性分支 feat/huawei-ak-visibility)
1. **后端** `src/api/routes/settings.py` GET `/settings/credentials`:huawei_cloud 增返 `ak`/`sk` 真实值
   (本人凭据,get_current_user 鉴权后回显合理;与旧 bool 字段共存)。
2. **前端** `settings.js`:
   - AK/SK 输入框加 `autocomplete="new-password"`(根因修复,防自动填充);
   - `value` 回显真实值(插入 HTML 前必须转义:`_esc = s => String(s).replace(/&/g,'&amp;').replace(/"/g,'&quot;')`,防引号破坏属性);
   - 👁/🙈 切换按钮 `toggleHuaweiSecret()`(id: huaweiToggleAk/huaweiToggleSk;type 在 password↔text 间切换,
     按钮文字同步 👁↔🙈;默认掩码);
   - 移除"✓ 已配置"标记(值已回显后冗余,用户确认删除,settings.js?v=8→9)。
   - 保存逻辑不变:非空且非占位符才写,空=不写(`saveCredentials` + `_isCredPlaceholder`)。
3. 部署:后端 Python 改动需重启 grape-main(+webhook),前端 ?v= bump 8→9;重启又踩 metadata lock(KILL 见
   grape-deployment 主文档)。

## 同类隐患(本次未修,用户只选了华为云 1+3)
全站 6 个 password 输入框均无 autocomplete:settings.js 的 GitCode API Token(disabled 时无碍)/huaweiAk/huaweiSk/
gitcodeBotToken、chat.js 的 App Secret(cfgImSecret)、agents.js 的 Bot Secret(vodImSecret)。如需一并修,
统一加 `autocomplete="new-password"`。

## 验证
- jsdom 行为测试 `/tmp/evt-fs-test/test_credentials.js`(npm run test,19 项断言):渲染回显/autocomplete/切换
  type/占位符过滤/留空不写。
- 后端 `pytest tests/test_api_routes.py -k credential` 2 passed(GET 返回新字段 + PUT 占位符拦截)。
