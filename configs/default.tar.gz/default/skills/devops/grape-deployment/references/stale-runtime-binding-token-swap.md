# 僵尸 runtime 绑定：换 token 后旧行残留 online → 事件永久 running（2026-08-17 实测）

## 症状
- 事件状态 running 持续很久（>10min），关联 agent_tasks **status='queued'、started_at=NULL、attempts=0** —— 从未被任何 worker claim，不是"跑得慢"。
- 同仓库其它事件正常 completed（走其它 worker 的 runtime）→ 排除全局故障。

## 根因链（wdmike/hello-calculator Seq #529 实测）
1. 机器换 token 升级：0002 机器（1.92.115.229）旧凭据 92（dev-worker-0002, mm6667）→ 新凭据 93（vod-worker, wdmike），重装后以 93 重新注册 → **新 runtime 行 64/65**。
2. 旧 runtime 行 62/63（credential 92）的 `last_seen_at` 停在换 token 时刻（09:48:51 UTC），之后再无心跳；但 **`status` 仍是 'online'**（无心跳超时下线机制），credential 92 也仍是 'active'（换 token ≠ revoke，不会被 revoke 过滤拦截）。
3. `pick_engine()` 的 `_apply_filters` / `_health_ok` 对远端只判 `status=='online'` → 僵尸行 63 被视为健康引擎。
4. binding 表（devops_agent_runtime_binding）或会话表（devops_agent_session.runtime_id）把该 (repo, agent) 指到 63 → 事件派发选中 63。
5. claim 按 `runtime_id=? AND status='queued'` **定向拉取**（claim 池已废除）：机器现在 claim 的是自己的新行 64/65，**永远不会 claim 63** → 任务永久 queued、事件永久 running。

## 判别配方（只读三步）
1. `SELECT * FROM events WHERE seq=<N>` → 拿 repo_key / agent_type / issue_id。
2. `SELECT id, runtime_id, status, started_at, attempts FROM agent_tasks WHERE event_seq=<N>` → 若 queued + started_at NULL，查 `SELECT runtime_id, credential_id, name, status, last_seen_at FROM agent_runtimes WHERE id=<runtime_id>`。
3. 对比 `last_seen_at` 与当前时间：若停在数小时前但 status='online' → 僵尸行。再查 `runtime_credentials`（id 对应 credential_id）确认是换 token 被替代的旧凭据（同 device_name 有更新的凭据行、且其 runtime 行 last_seen 活跃）。nginx 心跳日志 `grep heartbeat /var/log/nginx/access.log | tail` 确认机器整体在线（排除机器故障）。

## 修复
1. `UPDATE devops_agent_runtime_binding SET runtime_id=<新行id> WHERE repo_key=*** AND agent_type=<agent>`（新行 = 同机器新凭据对应的同类型 runtime，如 hermes 63→65）。
2. 同步 `UPDATE devops_agent_session SET runtime_id=<新行id> WHERE id=<会话id>`（按 id 更稳，repo_key 带 gitcode: 前缀）。
3. **无登录态 token 时（CLI 会话实测路径）：直接 `UPDATE agent_tasks SET runtime_id=<新行id>, started_at=NULL WHERE id=<task_id>`，保持 status='queued'** —— worker 按 runtime_id 定向 claim，下一轮轮询即接走（实测 20s 内 started，58s 后 completed exit=0），**等效 requeue 且无重复任务**。比 redispatch 干净：redispatch 对 queued 走 else 分支新建任务，旧任务残留。
4. 收尾 `UPDATE agent_runtimes SET status='offline' WHERE id IN (旧行ids)` 防后续事件再被 pick_engine 选中。

## ⚠️ redispatch API 的 token 门槛（2026-08-17 实测）
- `POST /api/events/{seq}/redispatch` 走 `get_current_user`（deps.py），需要 `Authorization: Bearer *** session token>`。
- **用户 session token 是进程内存态**（src/user/db.py `_user_tokens` dict，`create_session_token` 生成，重启即失）——没有登录态环境拿不到有效 token，API 直调不可行，**直接 SQL 改 agent_tasks 是 CLI/排查场景的正解**。

## ⚠️ redispatch 对 queued 任务的真实行为（读代码确认，events.py ~L206）
- 只有任务 status ∈ ("dispatched", "running") 才走 `requeue_task`（原地置回 queued，runtime_id 不变）。
- **status='queued' 不在该集合 → 走 else 分支：复用旧 task 快照参数 + `pick_engine()` 重新路由 + 新建任务（新 task_id，清空 runtime_session_id）**。所以绑死 runtime 的 queued 任务 redispatch 后会自动换到健康引擎——这正是想要的恢复路径，不用手改 agent_tasks。
- 30s 内重复调用幂等拒绝（meta `redispatch:{seq}`）；事件状态回写 running。

## 表结构备忘（本会话踩过的列名坑）
- `events` 主键是 `seq`，**没有 `id` 列**（列：seq, repo_key, event_type, source, issue_id, title, summary, actor, payload, agent_type, runtime, skill, status, exit_code, duration, agent_logs, result, created_at, started_at, completed_at）。
- `agent_runtimes` **没有 `instance_name` / `created_at`**（列：id, credential_id, name, display_name, provider, `binary`, installed, cli_path, version, healthy, pip_package, status, last_seen_at, scope, owner_id, updated_at, busy_slots, max_concurrent）。
- `agent_tasks` 有 runtime_id / affinity_runtime_id / pool_agent_type / issue_session_id / env_extra / errors 等，主键 id 形如 `t_<hex>`。

## 变体：旧行已被置 offline → 事件**秒败 engine_unavailable**（非永久 queued，2026-08-17 晚实测 songspace/shelldev #8/#9/#10）
- 与上文不同：62/63 已被心跳失败自愈置 offline（17:39 前后），但**绑定/会话仍指向 62/63**（binding 是 20:31-20:48 批量重建时用会话 runtime_id 回填的，当时 62/63 尚 online 或未核对健康）→ `pick_engine` 健康过滤后无候选 → 事件立即 failed `无可用引擎（engine_unavailable），请配置仓库/全局/本机引擎`，**不产生 agent_tasks 行**（入队前失败）。
- **判别**：events.result 含 engine_unavailable + agent_tasks 无该 seq 行 + binding 指向的 runtime status='offline'（或 credential revoked）。
- **修复同前**：binding+session 改指同类型新行（62 opencode→64、63 hermes→65，同机 credential 93）；已 failed 事件**无任务行无法 redispatch（会 404「该事件无关联任务」）**，正解 = 用存库 payload 重放 `run_pipeline`（见下）。
- **无任务事件重跑配方（CLI 可执行）**：`python - <<EOF` 里 `from src.api.event_pipeline import run_pipeline`；`run_pipeline(json.dumps(payload).encode(), {"X-GitCode-Event":"Issue Hook"}, account="owner/repo", repo_key_override="gitcode:owner/repo")`——与 webhook 处理同路径（绕过 HTTP 鉴权层），产生新 seq，issue_state 幂等重设 stage，pick_engine 走修复后绑定正常入队。无 produce_random_id 去重（同事件可重复处理，578/579 实证）。
- **连带发现**：引擎绑定重建/回填会**照抄会话里指向死行的 runtime_id**——批量重建绑定前先核对源 session 行的 runtime 是否健康，否则把死行写进绑定。
- 现成脚本：`/root/grape/scripts/fix_zombie_binding_62_63.py`（改绑定+会话 62/63→64/65）+ `scripts/replay_failed_engine_events.py`（重放失败事件）。

## 机制缺陷与根治方向
- 换 token 重装后旧 runtime 行应被下线（置 offline / 删行），现状是残留 online 且凭据 active → 任何后续事件都可能再被绑到死行。根治方向：同 device 新凭据注册时，把该 device 旧凭据的 runtime 行统一置 offline（或在 _health_ok 加 last_seen_at 新鲜度判定，如 >5min 视为不健康）。
- 附带观察：opencode 行 busy_slots 曾显示 10/11/8/6 远超 max_concurrent=4 —— 并发槽疑似未释放，属另一隐患，排查任务堆积时留意。
