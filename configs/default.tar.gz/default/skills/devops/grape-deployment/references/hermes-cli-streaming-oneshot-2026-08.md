# Hermes CLI 调用形态与流式输出（2026-08-17 源码核实）

背景：grape 前端调 hermes 只能拿到最终回复，期望实时看到思考过程。本文记录
已核实的 hermes 调用形态事实 + 三个候选方案（**均为方案，未实施**）。

## 关键源码事实（/usr/local/lib/hermes-agent）

| 调用形态 | 行为 | 源码位置 |
|---|---|---|
| `hermes -z <prompt>`（oneshot） | 整个运行期间 stdout+stderr 重定向 /dev/null，全部跑完才把最终回复一次性写回真 stdout；**从设计上不可能流式，也从不输出思考过程** | hermes_cli/oneshot.py（redirect 在 ~L233-243，print 在 ~L289-293；模块 docstring：\"Just the agent's final text to stdout\"） |
| `hermes chat -q <prompt>`（不带 -Q） | 走完整 chat 路径，`stream_delta_callback=self._stream_delta`（当 `display.streaming: true`）→ 逐 token 流式；思考过程实时显示需 `display.show_reasoning: true` 且 streaming 开（`_current_reasoning_callback` 返回 `_stream_reasoning_delta`） | cli.py `chat()` + hermes_cli/cli_agent_setup_mixin.py ~L535；cli.py ~L6564-6567 |
| `hermes chat -q ... -Q/--quiet` | 显式 `stream_delta_callback = None` + `tool_progress_mode='off'`，只打印最终回复（机器可读），无流式、无思考 | cli.py ~L18797-18803（quiet 单查分支注释：\"Suppress streaming display callbacks so stdout stays machine-readable\"） |
| `hermes chat -q` 非 quiet 但 stdout 是管道（Popen stdout=PIPE） | 流式回调在跑，但输出走 prompt_toolkit `print_formatted_text(flush=False)` → Python 非 TTY 块缓冲 → **输出攒到进程结束才吐出**，观感 = \"只在完成后整个发过来\" | venv prompt_toolkit shortcuts/utils.py（flush 默认 False）；TTY 下行缓冲所以终端里实时 |
| 推理强度 | `--reasoning none\|minimal\|low\|medium\|high\|xhigh\|max\|ultra`，覆盖 agent.reasoning_effort；只影响模型是否产出 reasoning token，不影响是否显示 | hermes chat --help |

配置键勿混淆：
- `display.streaming`（bool）= CLI 终端 token 流式开关（用户本机 config 为 true）。
- `display.show_reasoning`（bool）= 思考过程显示开关（**用户本机 /root/.hermes/config.yaml 为 false** → 就算换 chat -q 也看不到思考）。
- 顶层 `streaming.enabled` = **网关消息流式**（Telegram/Discord 渐进编辑，config_defaults.py ~L2714），与 CLI 无关。
- `hermes proxy` 是纯透传（\"response is streamed back unmodified, preserving SSE\"，hermes_cli/proxy/server.py）——上游 SSE 里带 reasoning_content 就实时转发，但 proxy 走 OAuth 凭据（Nous Portal 等），自定义 provider（如 deepseek-v4-flash）未必能过 proxy。

## grape 现状（为什么前端只能拿到最终回复）

- `src/runtime/hermes.py` HermesRuntime.build_args = `["-z", prompt, "--yolo", "--cli"(若支持)]`，输出协议 = 每行 stdout 转 text 事件（docstring 明说\"逐步过程事件不产出，属预期取舍\"）。
- `admin/backend/ai_hermes_query.py` 同样 `hermes -z <query> --yolo [--continue <前端会话id>]`，逐行读 stdout emit token 事件。
- 结论：`-z` 模式下前端拿到的\"整个过程\" = 思考+工具调用全部跑完后一次性打印的最终回复，永远不可能实时；思考过程文本在 -z 下根本不会输出。

## 候选方案（2026-08-17 提出，用户未拍板，均未实施）

A. **给 oneshot.py 加 `--stream` 开关**（改 hermes 本体，grape 不动）
   - 不重定向 stdout；给 agent 挂 stream_delta_callback + reasoning_callback；每个 delta 写真 stdout 并 flush；思考内容带固定前缀（如 `[thinking] ...`）与正文区分。
   - grape parse_output 只需把 `[thinking]` 行路由到前端思考区。
   - 只影响本机 /usr/local/lib/hermes-agent；远程 worker 要同样能力需同步补丁。
   - 最干净：协议可控、grape 改动最小。

B. **换调用：`hermes chat -q "<p>" --cli`（不带 -Q）+ PYTHONUNBUFFERED=1**
   - 不碰 hermes 代码，token 能实时从管道出来（PYTHONUNBUFFERED 抵消 flush=False 的块缓冲）。
   - 代价：输出带 ANSI 样式（思考框/颜色/工具进度行/\"Query:\" 标签/退出摘要），grape 要剥 ANSI + 过滤噪音；`display.show_reasoning` 必须改回 true。

C. **前端直连 `hermes proxy`（OpenAI 兼容 SSE）**
   - proxy 透传保 SSE，上游带 reasoning_content 即实时；但需常驻服务 + OAuth 凭据，自定义 provider 兼容性未验证。

## 排查/验证速查

- 确认前端调用形态：`grep -n "hermes" src/runtime/hermes.py admin/backend/ai_hermes_query.py`。
- 确认本机配置：`grep -n "show_reasoning\|streaming" /root/.hermes/config.yaml`。
- 改配置：`hermes config set display.show_reasoning true`（勿手改 config.yaml）。
- 管道实时性验证：`PYTHONUNBUFFERED=1 hermes chat -q "hi" --cli 2>&1 | while read l; do echo "$(date +%s.%N) $l"; done` 看时间戳是否递增。
