# 时间展示本地化：跨后端时间存储语义不一致（2026-08-17 实测，特性分支 feat/event-time-localization）

## 症状
- 开发者控制台 Event History（agents.js）/ Dashboard Recent Activity / Event 详情 Time 显示时间比实际 **+8h 且跨天**（如实际 20:46 显示 04:46 次日）。
- 用户报「Event History 展示的时间没有本地化」。

## 根因：三种时间语义并存，前端统一按 UTC 解析
1. **MySQL 后端（生产）**：`events.created_at` / `chat_messages.created_at` 等靠表默认值 `DEFAULT (cast(now() as char charset utf8mb4))` = **服务器本地时间 CST**（无时区标记，`'2026-08-17 20:46:19'`）。
2. **SQLite 后端（测试）**：同列默认 `datetime('now')` = **UTC**。
3. **代码显式写的时间**（events.started_at/completed_at、agent_tasks 时间列）= `datetime.now(timezone.utc).isoformat()` = **UTC ISO 带 +00:00**。
4. 前端 `fmtLocalTime`（src/api/static/js/api.js L4-12）把**一切输入当 UTC**（Date.UTC 解析 → 本地 getHours 显示）→ MySQL 的 CST created_at 被 +8h 错位；started_at/completed_at（UTC ISO）反而正确。

## 判别铁证（同一事件两字段对比）
- seq 574：created_at=`'2026-08-17 20:46:19'`（CST），completed_at=`'2026-08-17T12:46:19.163342+00:00'`（UTC）——20:46 CST == 12:46 UTC，证明 created_at 存的是 CST（append_event 不显式写 created_at，靠表默认值）。

## 受影响展示点（开发者控制台）
| 页面 | 位置 | 现状 |
|---|---|---|
| agents.js | Event History（renderAgent ~L158-160）| fmtLocalTime 只取 substring(11,16) 显示 HH:MM，且错位 +8h |
| dashboard.js | Recent Activity（~L120-124）| 同错位 |
| events.js | Event 详情 Time（L55）| fmtLocalTime 错位 |
| events.js | 运行日志 _tlLine（L236）| `created_at.slice(11,19)` 直显，完全无转换（UTC 原样）|
| knowledge.js | 知识卡片（L102/168）| `replace('T',' ').substring(0,16)` 直显，无转换 |
| tasks.js / chat.js | 任务/会话列表 | 已走 fmtLocalTime（同样错位）|

## fmtLocalTime 细节（api.js L4-12）
- 正则只匹配到秒；ISO 毫秒+偏移（`'...+00:00'`）被截断忽略偏移——对 UTC 偏移恰好正确（Date.UTC 语义一致），但若遇 +08:00 等非零偏移会解析错。
- 无时区字符串（MySQL CST）**无法从字符串本身区分是 UTC 还是 CST**——纯前端方案无法同时兼容 MySQL 生产与 SQLite 测试。

## 方案（2026-08-17 用户已选 A，已实施并推送 feat/event-time-localization 57a43c36）
- **后端**：新增 `src/api/time_utils.py` `normalize_event_time(raw)`——幂等容错，按 backend 语义归一化：
  - 带时区（Z 结尾 / ±HH:MM 偏移）→ `datetime.fromisoformat` 解析后 `astimezone(utc).isoformat()`（原样语义）
  - 无时区 `'YYYY-MM-DD HH:MM:SS[.ffffff]'` → `_db_backend()=="mysql"` 视为 CST(+08:00) 转 UTC；sqlite 视为 UTC 加 +00:00
  - 解析失败/空值 → 原样返回（不抛异常、不破坏数据）
  - backend 判定 lazy import `src.mysql_compat.load_db_backend_config()`（测试环境 conftest 强制 sqlite）
- **序列化点接入（12 处）**：event_store(get_events 列表/聚类)、routes/events(详情/分页列表/对话 thread)、routes/dashboard(recent+agent_recent)、routes/agents(recent_events/vod 会话)、routes/pipeline、routes/tasks、routes/runtime(任务列表)、routes/knowledge(两处)、routes/settings(凭据)、api/session_store(会话列表两处)、session_manager(get_user_conversations/get_conversation/get_conversation_by_im/get_messages)
- **前端**：`fmtLocalTime` 增强——正则支持 ISO 毫秒 `(?:\.\d+)?` + 时区偏移 `([+-]\d{2}:\d{2})?`；带偏移时把「本地假想时刻」还原成绝对 UTC 时间点（`ms += sign*(oh*3600+om*60)*1000`，+08:00 减 8h）；Event History 显示 `substring(5,16)`（MM-DD HH:MM，原仅 HH:MM）；运行日志 _tlLine 与 knowledge.js 直显点改走 fmtLocalTime
- **测试**：tests/test_time_utils.py 10 用例（mysql/sqlite 语义、偏移转换、Z 结尾、坏值兜底、幂等）

## 验证（2026-08-17 实施完成实测）
- test_time_utils 10 passed；组合（time_utils+runtime+api_routes+tasks+engine_select，deselect bot_takeover ×2）159 passed
- 生产库实测：MySQL CST '2026-08-17 22:08:24' → `get_events` 输出 `'2026-08-17T14:08:24+00:00'` ✓
- node（TZ=Asia/Shanghai）实测 fmtLocalTime：UTC ISO/Z/+08:00 三种输入全部转 22:08:24 ✓
- 部署后验证：`curl http://127.0.0.1:8000/static/js/api.js?v=<新号> | grep <新函数标记>` 确认静态文件已换新；worker 无需升级（session_manager/runtime 序列化是服务端内部模块，worker 不 import）
- ⚠️ 多文件组合排除 test_session_manager.py（已知模块污染坑，见 SKILL.md Tests & verification 节）

## 相关
- 特性分支 `feat/event-time-localization`（基于 origin/dev，已推送 57a43c36）；实施前方案讨论见本文件上文。
- 用户工作流：方案先审阅（摆选项不拍板），确认后落 docs/ 再实施。
