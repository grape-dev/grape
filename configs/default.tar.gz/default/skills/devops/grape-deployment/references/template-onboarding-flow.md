# 模板项目托管 → 引导（onboarding）→ 部署 全链路（2026-08-14 梳理）

回答两类高频问题：「托管模板后系统会自动建 2 个 issue 吗」/「系统是怎么部署的」。

## 1. 模板一键创建（templates.py create_from_template）做了什么

1. 建 GitCode 空仓库（用户个人名下；同名已存在则复用）
2. push 模板代码（source=local 复制目录 / source=git clone）
3. **自动托管**：复用 `/api/repos/host` 全链路（add_collaborator → accept_invite → 校验 permission ≥40 → webhook）
4. 应用开发场景（apply_scene）
5. 持久化 dev_scene + **trigger_onboarding**（仅此路径触发；手动 `/repos/host` 不触发）

## 2. Onboarding 自动建 2 个引导 issue（设计行为，非异常）

`src/api/onboarding.py`：`ONBOARDING_TARGETS = ("experience", "explore")`，各执行一次 repo-onboarding 技能，各建 1 个 Issue：

| target | 事件类型 | 预分配 issue | 标题 |
|---|---|---|---|
| experience | onboarding_exp | #1 | 「引导·快速部署体验」 |
| explore | onboarding_explore | #2 | 「引导·探索方向」 |

- 触发条件：场景（dev_scene）配了 onboarding 技能（当前 5 场景全配 repo-onboarding）；无技能则跳过
- 幂等：meta `onboarded:{repo_key}=1` 仅首次；**失败后也不会自动重跑**（见下方恢复流程）
- 实际 issue 号由 agent 写 `$ONBOARDING_RESULT` 文件回传，系统用 `update_event_issue_id` 校准；issue 置 vod 阶段（stage=vod, owner=vod，先收敛需求）
- 落库：2 个主事件 + 每 issue 1 个 onboarding_issue 子事件

## 3. 「快速部署体验」≠ 系统真的部署

repo-onboarding 技能 experience 分支**只创建部署指引 Issue**（标题「【体验】快速部署并体验本项目的核心功能」，内容 = 部署步骤摘要/启动命令/环境要求/体验路径，assignee=owner），**不实际部署**。

真正的部署是另一条链路：**cloud-deploy 技能**（SRE Agent 监听 `pull_request_merged` 事件且分支为 master/main）→ 按项目文件识别构建方式（package.json→npm / requirements.txt→pip / Dockerfile→镜像 / go.mod→go build）→ 构建 → `hcloud` CLI 部署华为云并验证。也就是说：**托管模板后系统只给部署指引，把代码合到 main 才会触发真实部署**。

## 4. 引导失败恢复流程（2026-08-14 实测）

症状：新建模板项目后 onboarding_exp/onboarding_explore 双双 failed、exit=1、GitCode 仓库无任何 issue。

1. 查根因：日志 `[task t_xxx] [seq=N] error: Authorization Required` = worker 缺 DEEPSEEK key → `scripts/check_workers_key.py` 批量检查 → `scripts/fix_worker_key.py` 修复（2026-08-11 5 台全缺；2026-08-14 worker 0006 复发缺 key，疑重装后丢失）
2. **必须清幂等标记**才能重跑：`DELETE FROM meta WHERE \`key\`='onboarded:gitcode:<owner>/<repo>'`（首触发即写入，失败后重走模板创建也不会再触发）
3. 手动触发：调 `trigger_onboarding(repo_key, owner)`（或重走模板创建流程）

## 5. 运维手法

多步远端 paramiko 操作**写脚本文件跑**（/root/deploy/*.py 或 skill scripts/），勿用 `python -c` 内联——引号/`$` 转义在 -c 里必炸（2026-08-14 两次实测）。SFTP 读写远端文件比 exec_command 拼 shell 稳。
