# GitCode webhook 事件断流诊断（2026-08-12 实测）

## 症状
用户新建 issue / PR / 评论,平台无任何反应:events 表无新行、无 agent 执行。

## 判定口诀（按顺序查）
1. **nginx access.log 有没有 git-gitcode-hook 请求**:
   `grep "git-gitcode-hook" /var/log/nginx/access.log | tail`
   - 有 200 → 事件到了,问题在服务端处理链路(查 events 表、webhook 日志、execution_mode)
   - **完全没有** → 事件没到服务器,跳 2
2. **GitCode 侧 hook 详情看 result / result_code**（决定性证据）:
   ```
   GET https://api.gitcode.com/api/v5/repos/{owner}/{repo}/hooks/{hook_id}
   Authorization: Bearer <confi...json 的 gitcode_api_token>
   ```
   - `result_code=503` + result 是 Squid 错误页
     (`ERROR: The requested URL could not be retrieved`) → **GitCode 回调被接收端网络层丢弃**
     → 华为云安全组/地址组没放行 GitCode 平台回调 IP（2026-08-12 实测根因）
   - `result_code=200` → 成功推送（result 形如 `{"status":"ok","seq":0,...}`,**不是错误**,别误报）
   - `result_code=0` + result 为空 → 配置正常,没事件或已送达
   - `active=false` / `issues_events=false` → hook 被禁用/事件类型没勾
   - hook 查询 API 返回 403 → bot token 对该仓库无 hook 查询权限（正常,跳过即可,不是断流信号）
3. **平台回调来源 IP**（用于白名单放行）:
   `grep "webhook/gitcode" /var/log/nginx/access.log | awk '{print $1}' | sort | uniq -c`
   - 2026-08-12 实测唯一出口 = **121.36.87.186**(华为云北京 ECS, AS55990,
     hostname `ecs-121-36-87-186.compute.hwclouds-dns.com` 静态 ECS)
   - 放行:华为云控制台 → VPC → IP地址组 → 加 `121.36.87.186/32` → 安全组 443 入方向引用该组
4. **手动验证链路（放行后立即确认）**:
   `POST https://api.gitcode.com/api/v5/repos/{owner}/{repo}/hooks/{hook_id}/tests`
   （Bearer bot token）→ 204 触发测试推送 → 等几秒后 nginx access.log 出现
   `git-gitcode-hook` 200、hook 详情 result_code 刷新为 200。

## 关键事实
- **GitCode 官方文档不公布 webhook 回调 IP 段**（查过
  https://docs.gitcode.com/docs/help/home/org_project/webhook/web-hook,只讲配置,无 IP 白名单）,
  所以白名单模式无法一次性覆盖平台全部出口——单 IP 放行**不能保证所有用户/仓库事件都到**
  （平台可能多出口/扩容）。务实组合:放行已知 IP + 断流监控兜底。
- 断流监控（2026-08-12 已落地, 用户定稿方案）: 用户偏好**分阶段受控变更**——先安全组放开 0.0.0.0 一段时间收集真实回调 IP, 确定范围后收紧 + 持续监测。已部署: `/root/grape/data/webhook-ip-monitor.py` 扫描 nginx access.log + .gz 中 UA=git-gitcode-hook 来源 IP, 累计去重写 `data/webhook-ips.json`, 放开期清单 `data/webhook-ips-all.txt`(供加安全组), 日志 `data/webhook-monitor.log`; monitor 模式: 最近 10 分钟无 webhook 请求且 events 无新行 → 轮询各托管仓库 hook result_code, 503 = 新出口 IP 被挡。wrapper: `~/.hermes/scripts/grape-webhook-ip-monitor.sh`。脚本幂等(按 last_seen 增量, 重复跑不重复计数)。
- ⚠️ **调度方式: 用系统 crond, 不要用 Hermes cron（2026-08-12 实测）**：Hermes cron job（no_agent+script, deliver=local）创建后在该 CLI 会话**不 tick**——last_run_at 一直 null、等 70s 无触发。已删除 Hermes job 改为系统 crontab：`*/5 * * * * /root/.hermes/scripts/grape-webhook-ip-monitor.sh >> /root/grape/data/webhook-cron.log 2>&1`（crond 服务 active, 21:20:02 实测自动触发成功）。凡需要**可靠周期执行**的监控脚本一律系统 crontab 落地; Hermes cron 仅用于需要 agent 推理/投递到消息平台的场景。
- webhook 鉴权在应用层有 X-GitCode-Token 兜底（未托管 404 / token 不匹配 403,见
  src/api/routes/webhook.py）,所以多放行几个回调 IP 无数据风险,最多收无效请求。
- 与 worker 断流区分:worker 心跳断 = 安全组没放行 worker 公网 IP（5 台 build worker 全断
  时看 nginx 日志心跳停在同一分钟,见 event-stuck-running-diagnosis.md）;
  webhook 断 = 没放行 GitCode 平台 IP。两个是不同来源,安全组白名单要分别覆盖。
