# revoke 删除语义 + 存量迁移 + metadata lock 复发（2026-08-17 晚）

相关完整事故链见 `engine-binding-revoke-collision-2026-08.md`（根因 D/E）；本文件记录增量教训。

## 1. 行为语义变更必须同步迁移存量数据（用户"还是报错"的直接原因）
- 场景：revoke 语义从「置 status='revoked'」改为「删除行」（用户指示"只要吊销就删掉对应的 worker 记录"）。
  改完代码 + 重启后，用户重建同名凭据 coding-worker **依旧报 1062「凭据名称已存在」**——因为库里 18 个**存量 revoked 行**（旧语义留下）还占着全局唯一名。
- 教训：改行为语义 ≠ 只改代码。**存量数据不迁移，用户看到的行为就没变**。语义变更清单里必须包含存量迁移步骤。
- 存量清理流程（本次实测）：
  1. 备份：`CREATE TABLE backup_runtime_credentials_revoked_20260817 AS SELECT * FROM runtime_credentials WHERE status='revoked'`；agent_runtimes 同理 JOIN 备份；
  2. 按新语义级联删：先删 `devops_agent_runtime_binding` 指向其 runtime_id 的行 → `devops_agent_session.runtime_id` 置 0 → 删 agent_runtimes（凭据名下）→ 删 runtime_credentials 行；
  3. 验证：名字可复用（pymysql INSERT 同名测试行成功即释放，随后 DELETE 回滚）；binding/session 悬空引用 = 0。
- 本次清理 18 凭据 + 23 引擎行；备份表保留 24h+ 供回滚。

## 2. revoke=删除 的实现要点（settings.py revoke_runtime_credential）
- 删 runtime_credentials 行（token 即刻失效：_auth_credential 查不到 → 401）+ 级联删 agent_runtimes 行 + 清 binding + session.runtime_id 置 0。
- 影响面核对（关键：为什么所有 revoked 过滤逻辑无需改）：get_runtime_id_by_name / resolve_instance_id / query_engines / Engines 视图的 `rc.status='active'` 过滤全部靠 LEFT JOIN runtime_credentials——删行后 rc 行不存在 → status NULL，但这些 agent_runtimes 行也一并删了，无残留行可命中 → 逻辑自洽。
- 恢复语义变化：旧「UPDATE status='active' 复活」恢复法**只对变更前的历史 revoked 行有效**；删除后 token 丢失不可恢复，只能重建凭据 + 重装 worker（见 worker-credentials-bulk-revoked.md）。
- 测试同步：test_revoke_marks_runtime_offline → test_revoke_deletes_credential_and_runtimes；test_revoked_old_credential_new_row 断言旧行被删只剩新行。

## 3. metadata lock 是复发常态，不是偶发（同一天三次重启三次被堵）
- 三次：14:38 worker 0002 连接 + 本机遗留事务；15:00 三个 14:40/14:47/14:50 开始的无主事务；均卡 `ALTER TABLE events` 于 Waiting for table metadata lock。
- 来源：服务连接池长事务 + worker 机器连接泄漏 + **pymysql 排查脚本自身**（autocommit=False 下 SELECT 就开事务，脚本不 close 就留 RUNNING Sleep 连接——本次 14:34 模拟脚本就是帮凶之一）。
- 流程固化：重启后 health 不通 → 查 `information_schema.innodb_trx`（trx_state=RUNNING 的 Sleep 连接）→ `KILL <trx_mysql_thread_id>` → 服务自动继续。**勿反复 systemctl restart**（每次重启又撞残留锁）。pymysql 脚本结尾一律 commit+close 或开 autocommit(True)。

## 4. 视图层"兜底/空态分支"最容易绕过过滤（orphan 分支教训，详见根因 D）
- settings.py Engines 视图的 orphan 兜底分支曾遍历 cached 全量（42 行）而非过滤后的 visible_runtimes → 吊销全部 worker 后 40 行 revoked/远端行以「本机 Runtime」设备伪装展示。
- 规则：空态分支也要复用主过滤结果，别重新遍历原始全量。
