# Chrome CDP 9222 worker 环境配置（浏览器自动化/小红书发布）

## 何时用
- grape SRE/agent 任务需要浏览器自动化（如小红书发布）时，Chrome 必须开在**执行任务的 worker 机器**上。
- 判别执行机的链路：`agent_tasks.runtime_id` → `agent_runtimes.id` → `credential_id` → `runtime_credentials.name/device_name`。
  （实测：redbook-operate SRE 任务 runtime_id=17 = credential 8 `vod-worker1` = worker-ecs-grape-dev-build-0002, 192.168.0.115）

## 核心事实
- 发布脚本（publish_note.py / set_cookies_and_publish.py / try_login.py）**硬编码连 `http://127.0.0.1:9222/json`**
  → Chrome 必须跑在执行机上；用户在**自己电脑**登录的小红书与 worker 无关（曾致 SRE 失败被误判为环境问题）。
- worker 无系统 Chrome，用 playwright chromium：`/root/.cache/ms-playwright/chromium-1234/chrome-linux/chrome`（aarch64 可用）。

## systemd 服务（持久 profile；2026-08-14 已装 worker-0002）
`/etc/systemd/system/chrome-cdp.service`：
```
[Unit]
Description=Chrome CDP remote debugging (persistent profile)
After=network.target
[Service]
Type=simple
ExecStart=/root/.cache/ms-playwright/chromium-1234/chrome-linux/chrome --headless=new --no-sandbox --disable-gpu --remote-debugging-port=9222 --remote-allow-origins=* --user-data-dir=/root/chrome-profile --window-size=1440,900 about:blank
Restart=always
RestartSec=5
[Install]
WantedBy=multi-user.target
```
`systemctl daemon-reload && systemctl enable --now chrome-cdp.service`
- **关键：`--user-data-dir` 必须用持久目录（/root/chrome-profile），勿用 /tmp**——SRE 曾用 /tmp/chrome-cdp-profile 临时 profile，登录态随进程消失。
- 验证：`ss -tlnp | grep 9222` + `curl -s http://127.0.0.1:9222/json/version`（CDP 握手）+ systemctl restart 后 4s 内 active（自愈）。

## Cookie 注入登录（免 VNC，最快；无需真机扫码）
1. 用户在**自己电脑**浏览器登录 https://creator.xiaohongshu.com
2. F12 → Application → Cookies → 逐条复制 name/value/domain/path（注意 domain 有的是 `.xiaohongshu.com`，个别是 `creator.xiaohongshu.com`）
3. 填进执行机 `/root/xhs-publish/set_cookies_and_publish.py` 顶部 COOKIES 数组（模板已含全部键名，替换 value 即可）
4. 流程：先 `Page.navigate` 到 https://www.xiaohongshu.com（设 domain）→ `Network.setCookie` 逐条注入 → 导航发布页验证不跳 login
5. 验证手法（CDP 读回，无头无截图也能确认）：
   - `document.location.href` 不再含 login/401
   - 侧边栏出现账号名（如「无敌麦克 退出登录」）= 登录成功
   - 页面出现"上传图文/发布笔记"等创作台元素 = 环境就绪

## 小红书发布页特性（2026-08-14 实测）
- 新版创作服务平台发布页**无「存草稿」按钮**（只有「发布笔记」.btn-wrapper + 「定时发布」开关）。
- 草稿**自动保存到浏览器本地**：侧边栏出现「草稿箱(N)」计数，关闭/刷新发布页即自动落草稿（内容含标题/正文/图片）。
- ⚠️ **本地草稿只在该浏览器 profile 可见**——用户在自己电脑登录看不到（不是云端草稿）。"用户自己确认草稿"只能通过执行机上的 Chrome（即 agent 代操作）。
- "先确认再发"的两条路：A) 保留 worker 本地草稿，agent 打开草稿核对后发布；B) 直接发布为「仅自己可见」（私密，用户 App 可见、可随时改公开）。
- 点击发布按钮后页面会刷新回上传页并自动存草稿；可见性选项只在发布确认弹窗里，页面上无直接开关。

## 产物/脚本位置（执行机上）
- SRE 生成的配图：`/root/image/hot_1~4.jpg`
- 发布脚本：`/root/xhs-publish/`（18 个：set_cookies_and_publish.py 主用、publish_note.py、try_login.py、send_sms*.py 等）
- 排障时先看 `/tmp/opencode/` 下 SRE 留下的临时脚本（attempt_publish.py 等，含标题/正文/失败原因痕迹）
