# Worker 换 token 升级 & 旧凭据设备"失联"判别（2026-08-17 晚实测）

场景：用户提供 5 台 worker 的全新 rta_ token 映射 + 机器清单，要求逐台执行
`curl -fsSL https://grape-dev.topxtopx.com/api/runtime/install | bash -s -- --token <TOKEN> --server https://grape-dev.topxtopx.com`。

## 标准流程（本次验证可用）

1. **备份**：`cd /root/deploy && ./venv/bin/python guard_worker_reinstall.py backup`
   （paramiko 直连，无需 sshpass；备份到 /root/deploy/worker-env-backup/{0002..0006}_runtime.env）
2. **升级**：用**用户提供的 token** 逐台执行 install 命令——不要从机器读旧 RUNTIME_TOKEN 复用
   （upgrade_workers_0817.py 是从机器读 token 的旧版；用户给的新 token 可能对应另一凭据，
   本次 0002 旧 token=凭据 92、新 token=凭据 93，含义不同）。脚本：`/root/deploy/upgrade_workers_newtoken.py`
   （TOKENS 字典按机器名映射，串行执行，每台 timeout 420s，自动 restart + 打印版本/token/server）。
3. **补 key/验证**：`guard_worker_reinstall.py restore`（本次 install 已固化保留 API key，restore 报
   DEEPSEEK_API_KEY/OPENAI_API_KEY 别名缺失属正常）→ `verify_workers_after_upgrade.py` 四查
   （env DEEPSEEK 行数 / 进程 environ DEEPSEEK 数 / systemctl is-active / worker.version）。
4. **心跳终验**：服务端 nginx access.log 按公网出口 IP grep heartbeat 全 200。

## 旧凭据设备"失联"的判别链（用户问"为什么失联了"时按此回答）

现象：升级后管理台 Workers 页某设备名（如 dev-worker-0002）显示 offline，但机器明明在线。

1. **token_hash 归属**：`_auth_credential`（src/api/routes/runtime.py）用
   `hashlib.sha256(token.encode()).hexdigest()` 查 runtime_credentials.token_hash。本地算新旧 token
   的 sha256 前 16 位对比表即可确认 token 属于哪个凭据。
2. **nginx 只记公网出口 IP**：worker 内网 IP（192.168.0.x）在 nginx 日志 grep 不到；用
   runtime_credentials.last_ip 反查公网↔机器映射。本次实测映射：
   - 0002 (vod) → 1.92.115.229
   - 0003 (issue) → 120.46.209.201
   - 0004 (coding) → 120.46.214.60
   - 0005 (qa) → 121.36.28.141
   - 0006 (sre) → 113.44.183.56
3. **last_seen_at 铁证**：agent_runtimes 里旧凭据的 runtime 行 last_seen_at 停在重装时刻、
   新凭据行持续刷新 = 被替换接管，非故障。
4. **结论话术**：同一台机器换新马甲（新凭据）在干活，旧马甲没人穿了所以页面显示失联；
   机器、服务、心跳全正常。是否保留旧凭据名在线需用户决策（注销 or 用其专属 token 重装）。

## install API key 固化（2bb8515c 起，行为变化）

install-worker.sh 重装**不再覆盖丢** HERMES_CUSTOM_API_DEEPSEEK_COM_API_KEY（5 台实测重装后
env 1 行 + 进程 environ 1 行均在）。guard_worker_reinstall.py 的 CRITICAL_KEYS 里
DEEPSEEK_API_KEY/OPENAI_API_KEY 是别名，备份里本就没有 → restore 报"备份里也没有缺失的"=正常，
**以 `grep -c HERMES_CUSTOM /etc/grape/runtime.env` + `/proc/<pid>/environ` 为准**。
guard_worker_reinstall 从"补 key 工具"退化为"升级后验证流程"，仍值得跑。

## 僵尸设备（既存，与升级无关）

- 120.46.2.221：第 6 台已废弃 worker 机器（凭据+引擎 19/20 已删但机器未关），每 5s 心跳 401。
- 101.46.0.215：register 401 循环（失效凭据）。
判别：该 IP 在 nginx 全 401 且 runtime_credentials 无对应 active 行。处理需用户确认（关机/清进程）。

## 部署基线：本地 dev 领先 origin/dev

`git fetch origin dev` 后若 `git log --oneline origin/dev..dev` 有纯 docs 提交（本地独有）：
`git merge --ff-only origin/dev` 显示 Already up to date（origin/dev 是 HEAD 祖先），
**部署基线 = 本地 HEAD**（= origin/dev 全量 + 无害 docs 提交）。`git show --stat` 确认无运行代码
影响即可直接部署（跑新增测试 → 重启双服务 → health + 新路由 401 验证），无需 reset --hard
（会丢本地提交）。docs 提交去留（推送/挪到特性分支）事后问用户。
