# 并行会话共享工作区：分支抢占/部署回退/隔离操作（2026-08-17 实测）

## 症状
- 自己 checkout 的分支/提交"神秘"变回别的分支；reflog 出现非本会话发起的 checkout
- 部署验证通过后，用户仍报旧行为（如时间未本地化）——服务被并行会话重启加载了旧分支代码
- 工作区出现非本会话的未提交改动（如 docs/xxx.md 被编辑）

## 根因
- 多个 hermes 会话可同时操作同一 /root/grape 工作区与 systemd 服务
- systemd 服务（grape-main/webhook）：Python 模块在进程启动时 import（内存固化）；**静态文件由 uvicorn StaticFiles 每次请求实时读磁盘** → 切分支立即改变静态文件服务内容，Python 代码要等重启
- 并行会话重启服务时若工作区在旧分支 → 部署整体回退（本次事故：22:41 部署 dev 验证通过 → 22:45:12 并行会话重启，工作区已被切回 feat/skill-sync-multiplatform 旧代码 → 用户报"22:47 事件显示 06:47"）

## 判别（三查）
1. `git reflog -15`：非自己发起的 `checkout: moving from A to B` 条目 = 并行会话操作
2. `git branch --show-current` + `git status --short`：分支/未提交改动可能随时变
3. 部署回退判定：
   - `systemctl show grape-main -p ExecMainStartTimestamp`（比对预期部署时刻，本次 22:45:12 ≠ 22:41）
   - `grep -c <新代码标记> /proc/$(ss -tlnp | grep ':8000' | grep -oP 'pid=\K[0-9]+')/cwd/src/...`（如 `grep -c normalize_event_time .../event_store.py`，0=旧代码）
   - curl 静态文件新版本号 grep 新标记（静态文件实时读磁盘）

## 隔离操作（worktree 模式）
- 主工作区被并行会话占用时：`git worktree add /tmp/grape-<名> <分支>` 在独立目录实现+验证+提交+推送，**不碰主工作区 checkout**
- gitignored 文件 worktree 里没有，需自行补：
  - `mkdir -p data`（conftest 日志/测试库）
  - `cp 主工作区 configs/db-backend.json worktree/configs/`（生产验证用，用后删除）
  - `cp -r 主工作区 .hermes worktree/.hermes`（hermes verify 需要 environment.json manifest）
- 用主仓库 venv 跑 worktree 测试：`/root/grape/.venv/bin/python -m pytest`（worktree 无 .venv）
- worktree 里改完 push 后 `git worktree remove /tmp/grape-<名>`

## 保护并行会话的未提交改动
- 先 `git log --oneline -1 -- <文件>` 确认是否已被并行会话自行提交（本次它先提交了，stash 报 "No local changes to save"）
- 确有未提交改动：`cp <文件> /root/deploy/parallel-session-backup/` + `git stash push -m "..." <文件>`，部署后告知用户 stash/备份位置
- **禁止** `git checkout -- <文件>` / reset 丢弃（用户红线：破坏性操作先确认）

## 事故链复盘（2026-08-17）
- 22:41 部署 dev（时间本地化）→ get_events 输出 UTC ISO 验证通过
- 22:45:12 并行会话重启服务（工作区已在 skill-sync 旧分支）→ API 返回无时区 CST → 前端当 UTC → 用户报 06:47
- 判别：ExecMainStartTimestamp=22:45:12；/proc/<pid>/cwd/src/api/event_store.py grep normalize_event_time=0
- 修复：checkout dev → 重启 →（再遇 metadata lock，KILL 旧进程残留 trx 7075580/7075630）→ 验证服务代码含标记 + API 输出 UTC ISO
