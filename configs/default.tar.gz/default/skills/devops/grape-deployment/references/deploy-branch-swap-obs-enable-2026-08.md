# 部署目标分支被并行会话切走 + OBS 启用配方（2026-08-17）

## 1. 症状
- 部署后 SRE 任务报「ClawHub Not logged in / 401 Unauthorized」或任务 env_extra 无 CLAWHUB_TOKEN
- 用户明明配置了令牌（user_platform_tokens 表有 clh_ 记录），但任务拿不到

## 2. 根因：部署的服务跑的不是目标分支
- 部署时 `git rev-list --left-right --count HEAD...origin/feat` 显示 0/0 一致，重启后服务也 health ok
- 但**并行 Hermes 会话/外部操作在同一工作区 checkout 到别的分支并重启了服务**（本次 22:50:44 `moving from feat/skill-sync-multiplatform to dev`，服务 22:51 起来）
- 服务端实际跑 dev 代码（无 `_inject_platform_tokens`）→ 平台令牌不注入 → SRE Not logged in

## 3. 判别链（服务端实际跑的代码版本）
1. `systemctl show -p ActiveEnterTimestamp --value grape-main` — 服务实际启动时刻（对比部署时刻，多次重启=有别的操作）
2. `journalctl -u grape-main --since <部署时刻>` grep `Started|Stopped|Killing` — 看几次重启
3. `git reflog -3` — 最近 checkout 记录（`moving from X to Y` 即被切走）
4. `git branch --show-current` — 当前工作区分支（可能已不是部署时分支）
5. `grep -rn "CLAWHUB" src/api/event_pipeline.py` — 目标分支才有的注入代码是否存在

## 4. 修复
- `git checkout <目标分支>` + `systemctl restart grape-main grape-webhook`
- 并行会话可能再次切走 → 部署后**验证服务端功能**（如真实任务 env_extra 有 CLAWHUB_TOKEN）而非只看分支名

## 5. 教训
- 部署完成 ≠ 服务稳定跑目标分支——并行会话共享工作区会切分支重启（与 git-worktree-parallel-session.md 同源）
- 服务端功能异常（SRE 报缺令牌/凭证）先查「服务实际跑的分支」，再查代码/配置/DB

---

# OBS 启用配方（2026-08-17 实测）

## 配置
`/etc/grape/grape.env` 追加（systemd EnvironmentFile，两个服务都读）：
```
OBS_ENABLED=true
OBS_ENDPOINT=https://obs.cn-north-4.myhuaweicloud.com
OBS_BUCKET=<bucket-name>
OBS_ACCESS_KEY=***
OBS_SECRET_KEY=***
OBS_PREFIX=grape
```
config.py 读 env：OBS_ENABLED/OBS_ENDPOINT/OBS_BUCKET/OBS_ACCESS_KEY/OBS_SECRET_KEY（get_storage() 要求四件套齐全才启用 ObsStorage）。

## 验证
- **方法名是 `save_bytes/read_bytes/delete_object/exists/temporary_url`——没有 `put_bytes`**（ObsStorage 无 put_bytes，用错报 AttributeError）
- 连通性自检：`save_bytes('grape/_probe.txt', b'probe-ok')` → `read_bytes` → `delete_object` 全通 = 凭据有效
- 重启后 journalctl 应见 `StorageBackend: obs (bucket=..., prefix=...)`（不是 `local (OBS not enabled)`）
- 进程环境确认：`tr '\0' '\n' < /proc/<PID>/environ | grep ^OBS_`

---

# 分析 agent 任务行为：先看任务日志，不要凭猜测（2026-08-17 教训）

- 判断「agent 是否该交办/为何没交办」必须看 journalctl 任务日志：`journalctl -u grape-main --since <时段> | grep <task_id>` 里的 `tool_use` 和 `text:` 行
- **不要凭 env_extra 内容或技能 grep 结果猜测行为**（env_extra 无令牌 ≠ agent 该交办；技能无指引 ≠ agent 不会正确识别）
- 本次 676 实测：Issue Agent 收到重复撤回请求 → 查历史知道 SRE 594 已报凭证阻塞 → 正确回帖说明「等待用户提供凭证，无需重复交办 A2A」（text 行原文）——看似「没交办」实为正确行为，凭 env_extra 猜测会误判成 bug（本次误判被用户骂「瞎分析」）

---

# skill-publish v4.2 实施状态（8d14d728，2026-08-17）

## 已实施（其他机器推送）
- **删除**：`src/im/skill_sync_scene.py`、`src/plugins/sync_service.py`、`skill_sync_bind` 建表（db_setup）、`upsert_bind` 调用（user/db.py）
- **新增**：`skills/skill-publish/SKILL.md`（三平台发布/下架流程）、`skill-description.json` seed（skill-publish, sre, official）、`_inject_platform_tokens`（event_pipeline.py，**仅 sre 任务**按执行用户注入 CLAWHUB/GITHUB/GITCODE_TOKEN）、settings.js GitHub/GitCode 区块、chat 技能同步指引

## 已知缺口
- **issue-advance / issue 技能没有「撤回/发布 skill → 交办 SRE」指引**——676 实测 Issue Agent 能自行识别「等待用户凭证」并正确回帖，但正规链路（Issue 入口发同步/撤回请求 → 交办 SRE 用 skill-publish 执行）仍建议给这两个技能补交办指引
- `_inject_platform_tokens` 仅 sre 任务注入——issue/chat 任务 env 无平台令牌（设计如此，Issue Agent 不直接调 ClawHub）

## 令牌存储（方案 B）
- `user_platform_tokens` 表：`clawhub_token` 列 → 通用 `token` 列，`platform` 值扩展 clawhub/github/gitcode（加平台=加行不改表）
- GitCode 令牌复用 `user_accounts.gitcode_api_token`（OAuth 自动填充，无需手动配）
