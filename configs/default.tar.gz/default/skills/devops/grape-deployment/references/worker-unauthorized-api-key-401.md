# Worker "Unauthorized: API key is required" (3s 401) 根因定位与修复

## 症状
worker 机交付任务时日志 `❌ Unauthorized: API key is required`（约 3 秒内即失败）。
此前文档笼统记为"runtime.env 缺 DEEPSEEK key"——**不完整**。真实根因往往不是 DeepSeek
key，而是 opencode 引擎需要的**另一个** env 变量，详见下。

## 真正的根因（2026-08-18 build-0005 实测）
1. worker 的 opencode config `~/.config/opencode/opencode.json` 的 `hermes-deepseek`
   provider 定义：
   ```json
   "options": { "baseURL": "https://opengw.clouddeveloper.club/v1",
                "apiKey": "{env:H...KEY}" }
   ```
   → opencode 跑任务时**必须**有这个 env 变量，否则 401。
   注意：主服务端跑 hermes 用 `HERMES_CUSTOM_API_DEEPSEEK_COM_API_KEY`（DeepSeek 直连 key），
   与 worker 的 OGW 变量**不是同一个**。worker 的 runtime.env 可能两条都有/都没有对。
2. `runtime-agent.service` 是 systemd 服务，环境只来自 `EnvironmentFile=/etc/grape/runtime.env`。
   **交互 shell 的 ~/.hermes/.env、~/.bashrc `export` 不会被服务进程读到** —— 检查服务
   真实环境必须看 `/proc/<pid>/environ`，别只看文件。
3. runtime.env 会积累**同名重复行**（旧 key + 新 key 都在）。systemd EnvironmentFile 同名
   **后者覆盖前者（last wins）**。若旧 key 在前、新 key 在后 → 进程实际拿到旧 key，
   恰是失效那个 → 401。实测：DeepSeek 老 key sk-dae0b… 已废弃（401），新 key sk-06f2b… 有效。

## 诊断步骤（在 worker 机上）
```bash
# 1. 服务进程真实环境里有哪些 key（唯一可信来源）
PID=$(pgrep -f 'src.runtime.agent' | head -1)
tr '\0' '\n' < /proc/$PID/environ | grep '^HERMES_CUSTOM' | sed -E 's/(sk-[a-z0-9]{6})[a-z0-9]*/\1.../'

# 2. runtime.env 是否有同名重复 / 是否缺 OGW key
grep -nE 'HERMES_CUSTOM' /etc/grape/runtime.env
grep -oE '\{env:[A-Z_]+\}' /root/.config/opencode/opencode.json   # provider 到底要哪个 env

# 3. 哪些 key 真实有效（逐个打 API，不猜）
#    OpenGW 网关:   https://opengw.clouddeveloper.club/v1/models   (Header: Auth Bearer)
#    DeepSeek 直连: https://api.deepseek.com/models                (Header: Auth Bearer)
#    200 = 有效; 401 "*invalid api key*" = 失效 key
```

## 修复
把**有效**的 OGW key 写进 runtime.env（可取 worker 自身 `~/.hermes/.env` 里已实测 200 那条；
worker 的 OGW key 可能 ≠ 主服务端的—— 两台可各持一个有效 key），并**去重**同名 key 只留
有效一条。改完必须 `systemctl restart runtime-agent.service`（环境在启动时读入一次）。
重启会 SIGTERM 杀掉 in-flight opencode 任务 → events 自动重派重跑，属预期。

## 验证
- 重启后新 PID 的 `/proc/<pid>/environ` 里两条 key 都在且值正确
- 新 `opencode run` 子进程环境带对 OGV key（pgrep 后查子进程 environ）
- `journalctl -u runtime-agent.service -n 200` 不再出现 401/unauthorized
- 之前失败的那条 events seq 会重派，跑通即修复确认

## 通用教训
- 引擎报 "API key is required" 时**不假设是缺 key**：先看引擎 config 引用的是**哪个** env 变量，
  再看服务进程 environ 里它是否存在、值是否有效。
- systemd 服务进程环境 = EnvironmentFile 唯一真源；`.env`/`.bashrc` 用户态配置是并列第二来源，勿混。
- 同名 key 重复行是隐患制造机，改环境前先 `grep -n` 是否有重复。

## worker 机远程访问
- hosts 里没有 build-0002..0006，直接用 deploy.py 里的**内网 IP** + paramiko：root/kaifazhe@123，
  `192.168.0.115/64/39/194/213`（2..6 号）。公网 IP 22 端口超时（被墙），走内网同网段。
- 取文件用 SFTP，执行远程 python 用 base64 传 key 避免引号/转义污染。