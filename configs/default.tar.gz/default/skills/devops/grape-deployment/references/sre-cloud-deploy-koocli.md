# SRE 自动部署链路（cloud-deploy / KooCLI）— 2026-08-14 端到端实测

## 部署触发链路（事实，勿凭直觉）
- 部署**不因"建 issue"直接触发**。完整链路：issue_opened → vod（D8 收敛）→ issue（评级 ready）→ A2A 交办 sre（a2a_event）→ SRE 执行 cloud-deploy。
- 另一入口：PR merge 到 main（SRE 订阅 pull_request_merged）。
- 路由：event_pipeline.py `_resolve_issue_stage_agent` 按 issue_state 阶段矩阵；无关联 issue 的 PR merge **不路由**（PR_DEFAULT_AGENT=""），需 `devops_agent_session.subscribe_events` 订阅兜底（agents.py 配置）。部署类 issue 由 Issue Agent 判定"运维类任务"直接 A2A 交办 sre（跳过 coding）。

## 前置条件清单（全绿才可部署）
1. `user_accounts.huawei_cloud_ak/sk` 有值（前端 General Settings 配置，按用户隔离）
2. sre 会话 skill='cloud-deploy'、skill_id、runtime_id 非空（⚠️ 前端保存订阅会清空，见下）
3. sre 会话 subscribe_events 含 pull_request_merged（A2A 交办路径不需要）
4. AK/SK 注入：`event_pipeline._inject_cloud_credentials` 按 repo owner 查 user_accounts，注入 `HUAWEICLOUD_SDK_AK/SK`；owner 未配置→注入空+警告日志（多用户隔离，不 fallback 别人 key）
5. worker 有 hcloud（或技能自动安装成功）

## ⚠️ upsert_agent_session 覆盖坑（2026-08-14 实测，未修代码）
- `session_store.upsert_agent_session` 的 UPDATE **无条件写** runtime_id/skill/skill_id（传 0/'' 也写入）；只有 enable/subscribe_events/im_* 传 None 才保留。
- 前端只改「事件订阅」保存 → 表单不带 skill/runtime → sre 会话 skill 被清空、runtime 变 0 → 部署必然失败。
- 症状：sre 会话 `skill='' runtime_id=0`，其他 agent 正常。
- 数据修复：`UPDATE devops_agent_session SET skill='cloud-deploy', skill_id=(SELECT id FROM skill WHERE skill_name='cloud-deploy'), runtime_id=<rid> WHERE repo_key=? AND agent_type='sre'`
- 代码修复方向：upsert 对 skill/runtime 也做"仅显式传值才更新"（与 enable 同语义）。

## KooCLI（hcloud）安装与认证 — 实测通过
- 华为云 CLI 现名 **KooCLI**（命令仍是 `hcloud`）。官方文档 `support.huaweicloud.com/qs-hcli/`；旧 `cli/` 页是 SPA + EdgeOne 人机验证（curl 抓到 404 外壳/验证页），别浪费时间抓。
- 官方镜像（CN）：`https://cn-north-4-hdn-koocli.obs.cn-north-4.myhuaweicloud.com/cli/latest/huaweicloud-cli-linux-{amd64|arm64}.tar.gz`
- **架构必须匹配**：arm64 机器下 amd64 包 → `Exec format error`（用 `uname -m` 判定：aarch64→arm64）。
- 安装：curl 下载 → tar 解压 → `find -name hcloud -exec install -m 0755 {} /usr/local/bin/hcloud \;` → `chmod a+rx`。
- 首次运行必须 `echo y | hcloud configure set --cli-agree-privacy-statement=true`，否则卡隐私声明确认。
- 认证：`hcloud configure set --cli-access-key=$AK --cli-secret-key=$SK --cli-region=cn-north-4`。
- 只读验证：`hcloud ECS NovaListServers --cli-region=cn-north-4`（返回 `{"servers":[...]}` 即 AK/SK 通）。
- 清理：`echo y | hcloud configure clear`（防 AK/SK 落盘）。
- 下载慢：arm64 曾 90s+ 且 curl 完成但进程不退出（文件实际完整）→ `--max-time 300` + `gzip -t` 校验，别只看进程。

## ECS 部署踩坑（2026-08-14 实测）
- 公网可访问需两件套：安全组放行端口（SRE 建的 SG 开 22/80/5000）+ ECS 绑定浮动 IP（floating；NovaListServersDetails 里 `OS-EXT-IPS:type` 区分 fixed/floating）。
- ❌ **expect 密码 SSH 交互不可靠**：SRE 任务卡 `task timed out after 600.0s`（多命令 expect 交互慢/等提示超时），代码 scp 上传成功但 venv/依赖步骤没跑完。
- ✅ **更稳**：`ssh-copy-id` 推 worker 公钥（id_ed25519）免密，之后单条 `ssh 'cat > /tmp/deploy.sh && bash /tmp/deploy.sh'` 执行（脚本 base64 传输避免引号地狱）。
- Ubuntu 22.04 精简镜像：`python3 -m venv` 缺 ensurepip → 需先 `apt install python3.10-venv python3-venv`（**技能缺此步是 SRE 超时根因**）。
- pip 从 files.pythonhosted.org 超时 → 重试即可。
- 启动：`nohup venv/bin/gunicorn -w 2 -b 0.0.0.0:5000 app:app &`；验证 `curl http://<公网IP>:5000/` 与 `/post/1` 均 200。

## ⚠️ 双 ECS 事故：幂等缺失 + keypair 必须（2026-08-14 hello-calculator1 issue#2 实测）
- 症状：**一次 SRE 任务建了两台 ECS**（`deploy-hello-calculator1-153809` 连不上被弃 + `hello-calculator-deploy` 成功），用户多付一份机器费。agent_tasks 里 sre 任务只有 1 条 completed——是**单任务内部反复试错重建**，不是任务重复。
- 轨迹还原：先想复用旧 ECS（重置密码失败）→ 15:38 新建第一台（**没带 keypair → 建完 SSH 连不上**）→ 15:43 又新建第二台（带 keypair 成功部署）。
- **两个硬性约束（已写进仓库 skills/cloud-deploy/SKILL.md）**：
  1. **创建 ECS 必须带 keypair**（`--keypair grape-deploy-kp`，不存在先 NovaCreateKeypair 用 worker 公钥创建）+ **user-data 注入公钥**——否则建完连不上，Agent 会无限试错重建。
  2. **创建前先查已有实例**（按 `deploy-<repo>` 名称过滤 ListServersDetails 取浮动 IP 复用），幂等——否则每跑一次多一台机器。
- 删除 ECS 用 **`hcloud ECS NovaDeleteServer --cli-region=cn-north-4 --server_id=<id>`**（KooCLI 里没有 DeleteServer；删除异步，等 ~20s 后 ListServersDetails 确认消失）。

## 现场状态（2026-08-14）
- hello-blog（mm6667）已部署到 http://121.36.18.207:5000（ECS cn-north-4b，id e82b6807...）。SRE 任务曾超时失败，部署由人工补 python3-venv 后完成——**cloud-deploy 技能需补 python3-venv + 免密 SSH 步骤才能全自动**（技能在仓库 skills/cloud-deploy/SKILL.md，改后需走 PR 合入）。
- **后续（同日）**：技能已补 python3-venv / 免密 SSH / 单会话部署 / pip 重试 / 幂等检查 / keypair 必带，**已提交并推送 dev（b3cad23f，2026-08-14）**。hello-calculator1 issue#2 用修复后技能端到端成功（unit tests 5/5，部署完成评论已发）。三台 ECS（hello-blog + 双 calculator）已全部删除（`hcloud ECS NovaDeleteServer --server_id=<id>`），账号下无按量 ECS。
