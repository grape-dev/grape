# GitCode MR 合并门禁「流水线运行未通过」诊断（2026-08-18 实测, songspace/shelldev Issue #19 / PR #17）

## 触发场景
用户在 GitCode 网页报「合并受阻：流水线运行未通过」，PR 一直合不进去。

## 诊断链（按序）

1. **定位 PR + 读 mergeable_state**
   `GET https://gitcode.com/api/v5/repos/{owner}/{repo}/pulls/{n}?access_token=<bot token>`
   - `mergeable_state.state: False` + `ci_state_passed: False` = 流水线门禁卡住。
     其余字段（conflict_passed / branch_missing_passed / non_ff_passed / mr_state_passed /
     merged_by_user_passed / work_in_progress_passed / resolve_discussion_passed /
     approval_*_passed）全 True 时，ci_state_passed 就是唯一卡点——别去查别的。
   - `merge_request_switch.only_allow_merge_if_pipeline_succeeds: True` = 仓库开了
     「仅流水线成功才允许合并」（can_force_merge=False = 也不能强制合）。
   - `check_tasks_num` 有值时说明平台侧挂了检查任务（本次=1）。

2. **找流水线配置**
   仓库根 `.gitcode/workflows/*.yml` = GitCode 原生流水线（GitHub Actions 兼容语法：
   `runs-on: [ubuntu-latest, x64, small]`、`${{ github.token }}`、`on: push/pull_request`）。
   仓库根的 `.gitlab-ci.yml` 是历史遗留（GitLab 语法），勿与前者混淆；两者都可能存在。

3. **对比各分支的流水线配置是否已含修复**
   本地 clone：`git clone https://x-access-token:<token...git`
   （用 x-access-token 前缀，裸 token 会触发密码提示）。
   `git show <sha>:.gitcode/workflows/ci.yml` 分别看 PR head / main / head 的父提交，
   判断「修复已进 PR 但门禁仍红」= run 没重跑或修得不够，而非配置缺失。
   ⚠️ GitCode API 的 `contents/...?ref=` 对 bot token 会 403，本地 clone 才是正路。

4. **识别谁在修、修到哪**
   `git log --format="%h %an %ad %s" --date=format:"%m-%d %H:%M" -15`
   看 CI 提交时间线：本次用户本人（songspace）当天上午 10:51-11:12 连推 8 个提交
   （checkout action 下载失败 34 次 run 全红 → 改 run 方式克隆 → zipball 下载/解压 debug）。
   **看到密集的 ci: debug 提交 = 用户自己正在调，别重复修，先问他最新 run 日志。**

5. **grape 侧确认**
   events 表 event_type 列表无 pipeline/check 类 = GitCode 不把流水线状态推给 grape
   webhook，平台侧独立跑，grape 无从感知。

## 流水线 run 日志的获取边界（三路全堵，只能用户网页贴）
- GitCode 流水线页面是重型 SPA（cdn-static.gitcode.com assets ~1.8MB），
  browser_exec 连开 5 次全部 timeout（页面渲染不完成），curl 只拿到 3.5KB 空壳 HTML。
- 内部 API `/api/v2/projects/pipeline-check/{repo_id}/merge_requests/{iid}/pipelines`：
  脚本直连 418 I'm a Teapot / 403 Forbidden（WAF 拦，需浏览器 cookie 会话）；
  repo_id 从 `GET /api/v5/repos/{owner}/{repo}` 的 `id` 字段取（shelldev=10562597）。
- v5 公开端点 `actions/runs`、`workflows`、`pipelines`、`pulls/{n}/pipeline` 全 404
  （GitCode 不暴露 GitHub Actions 式 API）。

→ 结论：run 失败步骤只能让用户网页打开流水线页贴日志，再决定修 ci.yml 还是修测试。

## ⚠️ 先查 merged_at——PR 可能已被 grape 自己的 agent 合并
读 `GET /pulls/{n}` 时**别只看 mergeable_state.state**：`merged_at` 有值 + `state: merged` = PR 已合。
本次 PR #17 在门禁仍红（ci_state_passed=False）时已于 12:21 被 **grape_dev_bot**（seq=872 coding
agent 流程）API 合并成功——**GitCode 合并门禁拦不住 API 侧合并**（主要拦网页/常规路径）。
判别「用户报合并受阻」是否已过时：先看 merged_at / merged_by，再查 main 是否已含 PR 文件
（`GET /repos/{o}/{r}/contents/<文件>` 200=已合入）。日志侧证据：devops-bot.log 里
`text: PR #17 shows as **merged**` = agent 自己也发现了。

## ⚠️ API 探测坑（本次实测踩中）
- `POST /pulls/{n}/merge` → 405 Method Not Allowed（GitCode v5 无此端点）。
- **`PATCH /pulls/{n}` 是真实修改接口**——探测时发 `{"title":"t"}` 竟真的把 PR 标题
  改成 "t"（200 落库）！探测「只读语义」的接口前先想清楚方法语义，误改后立即
  再 PATCH 还原原标题（`{"title":"feat: Issue #19 ..."}`），并回验 `d.title`。

## 解决选项（给用户拍板，勿自作主张）
1. 用户贴最新 run 失败步骤 → 修 ci.yml / 修 tests/test_*.sh。
2. 本地验证测试本身：clone 仓库跑 `bash tests/test_*.sh`，区分「测试真挂」vs
   「GitCode runner 环境问题」（read-only，可先做）。
3. 关门禁（用户拍板后的**已验证可行路径**，2026-08-18 实测 200）：
   - 端点 = **`PUT /api/v5/repos/{owner}/{repo}/pull_request_settings`（下划线！）**
     连字符版 `pull-request-settings` 404、`pulls/settings` 400（缺 settings 参数）——都不要用。
   - 读当前结构（GET 同路径）：顶层 `{merge_request_setting:{...}, only_allow_merge_if_all_discussions_are_resolved,
     only_allow_merge_if_pipeline_succeeds, merge_method}`。
   - 关：`PUT` body `{"only_allow_merge_if_pipeline_succeeds": false}` → 200；**GET 回读确认 False**。
   - 验证效果：`GET /pulls/{n}` 的 `mergeable_state.state` 变 True、`ci_state_passed` 变 True
     （本次实测：关门禁前 state=False，关闭后立即全绿）。
   - ⚠️ 修改仓库合并策略属破坏性操作，必须先经用户明确拍板；终端安全拦截（含 PATCH/PUT 的
     探测命令被 BLOCKED）是正确行为——探测参数结构用 GET，执行修改前把命令拆成「只读探测」和
     「用户确认后的写入」两步。
