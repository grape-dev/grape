# Chat Agent 路由 runtime：绑定被忽略（"注册了个人 chat-worker 为什么不跑它"）

> 2026-08-12 实测。用户注册个人 chat-worker（runtime_credentials scope='user'）后，chat agent 页聊天仍跑在全局 worker。
> 与 `runtime-binding-execution-mode.md`（direct 模式吞掉绑定）是同一主题的另一个变体：**queue 模式下路由代码按引擎名重查、忽略已保存的绑定**。

## 架构速览（chat 相关表/接口）

- **chat 配置**存 `chat_agent_session`（user_id + repo_key=*** 全局行，id=`sess-cfg-{user_id}`）。`get_chat_config(user_id)`（src/session_manager.py）返回 `backend` = 绑定 runtime 的 `agent_runtimes.name`（如 'hermes'）；无行时默认 `{"backend":"opencode"}`。
- **配置页下拉** `GET /api/chat/config` 的 `_backends` 只列 `agent_runtimes ar JOIN runtime_credentials rc WHERE rc.scope='user'`；选项 value = 派生名 `instance_name(engine, device_name, credential_id)` = `{engine}-{device_suffix}`（如 `hermes-chat-worker`，src/runtime/instances.py）。
- **保存配置** `PUT /api/chat/config` → `set_chat_config`：`resolve_instance_id(派生名)` → agent_runtimes.id；`scope_of_runtime(id)=='user'` 才直接存 runtime_id，否则按名回退。scope_of_runtime 看 credential 的 scope（不是 agent_runtimes.scope）。
- ⚠️ **register 接口（POST /api/runtime/register）INSERT agent_runtimes 时 scope 硬编码 'global'**（即使 credential 是 user scope）→ 个人 worker 的引擎行混进全局池，参与所有同引擎任务的全局路由竞争（get_runtime_id_by_name 按 agent_runtimes.scope='global' 查得到它）。

## 根因（代码路径，修复前）

chat.py 非 direct 分支（`/send`→`_enqueue_chat`、`/send/stream`）原实现：

```python
runtime_id = get_runtime_id_by_name(backend_name) or ensure_default_runtime(backend_name) or 0
```

`get_runtime_id_by_name(name, scope="global", owner_id="")`（src/user/db.py）：

```sql
SELECT id FROM agent_runtimes
WHERE lower(name)=? AND scope='global' AND owner_id=''
ORDER BY CASE WHEN status='online' THEN 0 ELSE 1 END, last_seen_at DESC
LIMIT 1
```

→ 多 worker 同引擎时选**心跳最新一台**，与用户保存的 chat_agent_session.runtime_id 无关。实测 4 条 chat 任务全跑在全局 opencode（runtime 17/9），注册的 chat-worker 从未被选中；即便配置页选中它，send 时 backend_name='hermes' 按名重查，个人 worker 心跳最旧 → 依旧被跳过。

## 修复（2026-08-12，单文件 src/api/routes/chat.py）

新增：

```python
def _resolve_chat_runtime_id(user_id: int, backend_name: str) -> int:
    # 1) 优先用户保存的绑定
    #    SELECT runtime_id FROM chat_agent_session
    #    WHERE user_id=? AND (repo_key=*** OR repo_key IS NULL) AND runtime_id>0 LIMIT 1
    # 2) 无绑定 → get_runtime_id_by_name(backend_name) or ensure_default_runtime(backend_name) or 0
```

替换 send/stream 与 _enqueue_chat 两处 runtime_id 解析。绑定写入与页面保存同路径：`set_chat_config(user_id, backend='hermes-chat-worker')`（resolve_instance_id 匹配派生名 → runtime_id=19）。

## 验证方法（端到端，可复用）

1. `./.venv/bin/python` 里 `_enqueue_chat(user={'id':1,'username':'mm6667'}, conv_id, msg, '', 'chat', 0, '')` → 返回 task_id（create_conversation 先建 conv）。注意：这会真实入队并消耗 worker LLM 额度。
2. 轮询 `SELECT id, runtime_id, status, started_at, completed_at FROM agent_tasks WHERE id=...` — runtime_id 应为绑定 id。
3. `journalctl -u grape-main --since '...'` 看 claim 链路：`<worker_ip> POST /api/runtime/runtimes/19/tasks/claim 200` → `/tasks/{id}/start 200` → `/tasks/{id}/complete 200`。claim 按 runtime_id 精确匹配（service.claim 原子抢单 + 串行槽），runtime_id 对了执行者就对。
4. 服务端 app log 在 `data/devops-bot.log`（"Task enqueued: ... runtime=19"）；uvicorn access log 在 journalctl。

## 坑

- **任务 claim 后 30ms 即 fail、exit=-1、errors/stderr 全空** = worker 侧引擎执行失败（如 hermes CLI 版本/配置缺失），与路由无关 —— 需到 worker 机器看 runtime-agent 日志。本次 chat-worker 上报 hermes v0.19.0（5 台 build 机是 v0.20.0），注册 cli_path=/usr/local/bin/hermes。
- **agent_tasks 僵尸**：queued/dispatched 卡一天 = 串行槽被 dispatched 任务卡死（同 agent_session 有 dispatched 未终 → 后续 queued 永不 claim）。清理：`UPDATE agent_tasks SET status='failed', result_text='stale task cancelled', completed_at=NOW() WHERE status IN ('queued','dispatched')`（agent_tasks 有 completed_at 列；events 表同理标 failed）。
- **pkill 自匹配**：`pkill -f 'opencode run'` 若所在命令行/heredoc 本身含 'opencode run' 字样，会把执行它的 shell 一起杀掉（exit -15，后续 systemctl restart 等命令全部不执行，服务还是旧代码）。用 `pkill -f '[o]pencode run'`（字符类破匹配）或拆到单独命令。
