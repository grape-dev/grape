# 死引擎残留 online 导致任务永久 queued（2026-08-18 实测，songspace/shelldev Issue #15）

## 症状
- 某 Issue pipeline 停在某 stage 不推进（用户问「为什么没触发下一个 agent」——实际是**根本没走到那个 stage**）
- 事件 status=running，对应 agent_tasks status=queued，runtime_id 指向某引擎
- 该引擎 status='online' 但 last_seen_at 已停滞数小时/数天

## 根因
- worker 机器断电/断网/实例被停 → 心跳停止，但无优雅下线流程 → `agent_runtimes.status` 恒为 'online'
- pick_engine/绑定按 status='online' 选引擎 → 每笔新任务都绑到死引擎 → queued 无人 claim → 事件永久 running → stage 永不推进
- 危害是**持续性的**：清理前每个新事件都可能中招（实测新 Issue #17 seq 758 也绑到同一死引擎的姊妹行）

## 判别链（实测顺序）
1. `issue_state` 查 stage（卡在 coding = 未到 sre，先修正「没触发 SRE」的表述为「没走到 SRE 阶段」）
2. `events` 按 repo_key 查该 issue 完整事件链，找到 running 的那条（issue_opened → a2a coding → qa → coding…）
3. `agent_tasks` 按 event_seq 查 runtime_id；`agent_runtimes` 查该行 last_seen_at 停滞
4. nginx access.log 按 worker 出口 IP grep heartbeat/claim——最后一条 200 的时间 = 死亡时刻
5. ping worker IP（注意：**ping 不通 ≠ 机器离线**——安全组可禁 ICMP；判别以心跳为准）
6. **关键判别：同 IP 可能用另一条凭据正常心跳**——`runtime_credentials` 按 last_ip 反查。实测：0002 机器 cred 93(vod-worker, owner=wdmike) 旧实例死 9.5h，但 cred 94(002_worker01, owner=obs_mysql_user) 同 IP 心跳正常 → 机器活着、只是旧 worker 实例被停/替换

## 清理（revoke=删除语义，用户 2026-08-17 拍板）
settings.py `revoke_runtime_credential`（src/api/routes/settings.py ~495 行）语义：
- DELETE `runtime_credentials` 行（token 即刻失效 401）
- DELETE `agent_runtimes WHERE credential_id=?`
- DELETE `devops_agent_runtime_binding` 指向行（配置页不悬空）
- UPDATE `devops_agent_session SET runtime_id=0`（dashboard 红字「无 engine」）

CLI 场景 redispatch API 不可用（需内存态 session token），直接 SQL 等价：
```sql
DELETE FROM devops_agent_runtime_binding WHERE runtime_id IN (64,65);
UPDATE devops_agent_session SET runtime_id=0 WHERE runtime_id IN (64,65);
DELETE FROM agent_runtimes WHERE credential_id=93;
DELETE FROM runtime_credentials WHERE id=93;
```
（全部放进一个事务，pymysql autocommit=False + commit/rollback）

## 卡死任务改绑（等效 requeue，无需 redispatch）
```sql
UPDATE agent_tasks SET runtime_id=<在线引擎id> WHERE id='<task_id>';
-- 保持 queued 即可：worker 按 runtime_id 定向 claim，下一轮接走（实测 20 秒内接走并 started）
```
选引擎：`SELECT runtime_id, COUNT(*) FROM agent_tasks WHERE agent_type='<type>' AND status='completed' GROUP BY runtime_id` 取历史常用 + last_seen 新鲜的行（实测 coding→56 即 0004 coding-worker1、vod→54 即 0003 issue-worker）。

## 预防
- 清理后全表扫 `status='online'` 但 last_seen 停滞多日的引擎（本机还有 cred 41 aishell-git 8-13 停、cred 46 verify-v3 8-14 停的同类残留），列给用户决定是否一并清，勿擅自删
- `busy_slots` 可能远大于 max_concurrent（实测 178/4）——累计计数未清零，不影响定向 claim，勿当故障

## 工具坑（本会话实测）
- 本机无 mysql CLI → 用 venv pymysql 脚本（`autocommit=True` 防制造僵尸事务连接）
- **events 表列名是 `issue_id`（非 issue_num），且无 `updated_at` 列**（主键 seq）
- execute_code 里 Python 内嵌 f-string 时 `{r['id']}` 会被外层 f-string 抢先插值（NameError）→ pymysql 排查脚本一律 write_file 落盘再跑
- `systemctl is-active grape` 会报 inactive——正确 unit 名是 `grape-main` / `grape-webhook`（grape 不是 unit）
