# Chat 任务黑洞：本机直连行（runtime_id=1）在 queue_remote 下永不被 claim（2026-08-17 实测）

## 症状
- Chat Agent 页面用户回复消息（如 "1"/"2"）后**无任何回复**，POST /api/chat/send/stream 返回 200，任务已入队但永远 queued。
- 用户以为「选了 2 没回应」——实际是任务进了死队列，不是消息丢失。

## 证据链（排查三步）
1. **chat_messages 表**确认用户消息已入库（`SELECT id, role, LEFT(content,200), created_at FROM chat_messages WHERE conversation_id=?`）。
2. **journalctl -u grape-main** 在消息时刻找：
   - `Chat send/stream: backend=opencode, skill=chat, has_token=*** user_msg=2`
   - `Task enqueued: t_xxxx session=<sid> runtime=1(opencode-cred0) skill=chat`
   - `Chat stream enqueued: task=t_xxxx user=5 conv=<conv_id>`
   → `runtime=1(opencode-cred0)` 是黑洞标记（正常应是 runtime=52/54/56/60 等 worker 行）。
3. **agent_tasks** 确认卡死：`SELECT id, runtime_id, status, created_at FROM agent_tasks WHERE status='queued' ORDER BY created_at DESC` — runtime_id=1 且 started_at NULL。
4. **chat_agent_session** 确认配置被绑死：`SELECT * FROM chat_agent_session WHERE id='sess-cfg-{uid}'` → `runtime_id='1'`、`runtime='opencode'`。

## 根因（两层）
1. **直接原因**：agent_runtimes id=1 = 本机直连占位行（`credential_id=0`、`status='offline'`、last_seen_at NULL、scope=global、cli_path=/usr/local/bin/opencode）。它只是「服务器本机装着 opencode CLI」的标记，**没有任何 worker claim 它**（worker 只 claim 自己凭据行 52-65）。execution_mode=queue_remote（meta）强制模式下 `runtime_execution_kind(1)` 直接返回 `queue_remote`（强制模式不看 credential_id）→ send_stream 走入队分支 → 任务进死队列 → SSE 等不到终态。
2. **配置为何变成 runtime 1**：`set_chat_config`（src/session_manager.py）只传 im_app_id/im_app_secret（**飞书 onboarding 触发**：`POST /api/feishu/onboard/start` → feishu_onboard.py 调 set_chat_config）时，runtime_id 走 `_resolve_chat_runtime_id(data.get("backend"))` 重解析——裸引擎名 'opencode' 命中 `get_local_direct_runtime_id('opencode')`（session_manager.py ~727-731：**裸名优先本机直连 credential_id=0 行**）→ runtime_id=1 写回 sess-cfg-{uid}。当天所有新用户/新 onboarding 的 chat 配置（user 2/3/5/15）全落 runtime 1。
3. **代码缺陷**：send_stream 入队分支（src/api/routes/chat.py ~328-343）**缺** `_enqueue_chat`（~520-522）已有的保护：
   ```python
   if (runtime_credential_id(runtime_id) or 0) == 0:
       return {"reply": "⚠️ 未配置远端引擎，任务会话需先在 Agent 配置中绑定远端引擎", ...}
   ```
   所以本机直连行在 queue_remote 下是「静默黑洞」：不报错、不入 direct、无人接活。

## 修复
1. **立即（数据层）**：把用户 chat 配置绑到在线 worker 行
   ```sql
   -- 先确认在线 opencode worker：SELECT id, name, status, last_seen_at FROM agent_runtimes WHERE name='opencode' AND status='online'
   UPDATE chat_agent_session SET runtime_id=56 WHERE id='sess-cfg-5';   -- 按在线行改
   ```
   （前端 Chat 配置页重新选引擎保存等效。）
2. **清死任务**（5 条 runtime=1 queued，不清理会一直占着）：
   ```sql
   UPDATE agent_tasks SET status='failed', errors='runtime 1 本机直连行无人 claim，运维清理', completed_at=NOW() WHERE runtime_id=1 AND status='queued';
   ```
3. **代码根治（2026-08-17 晚已实施并部署，待用户确认提交）**，两处：
   - **send_stream 入队分支补保护**（src/api/routes/chat.py，kind != EXEC_MODE_DIRECT 分支开头）：`(runtime_credential_id(rid) or 0) == 0` → 返回「⚠️ 未配置远端引擎，任务会话需先在 Agent 配置中绑定远端引擎」SSE done 事件（对齐 _enqueue_chat 提示；rid=0 也被拦：runtime_credential_id(0)=None → (None or 0)==0）。
   - **_resolve_chat_runtime_id 跳过本机直连解析**（src/session_manager.py）：裸引擎名分支加 `get_execution_mode() != EXEC_MODE_REMOTE` 才查 `get_local_direct_runtime_id`——queue_remote 强制模式下本机直连行（credential_id=0）无 claim 方，直接 `get_runtime_id_by_name` 按名找远端 worker（online 优先）。
   - 回归测试：tests/test_chat_backend_resolution.py E07（queue_remote 下裸名 → 远端 worker 901 而非本机 902）+ tests/test_web_chat_tooluse.py test_send_stream_queue_remote_local_direct_rejected（配置行绑本机行 + queue_remote → 明确提示、enqueue 不被调用）。验证 13 文件 146 passed（含 chat_handler/chat_task_scene/chat_cwd/session_manager/feishu_chat_unified/runtime/engine_select）。**坑：SSE 断言不能 `in r.text` 直接匹配中文——json.dumps(ensure_ascii) 转义成 \uXXXX，须解析 data: 行取 text 字段**。
   - 部署：重启 grape-main + grape-webhook 即生效（worker 无需升级，协议未变）。存量 runtime_id=1 配置行仍需数据层改绑（代码保护只拦新入队，不修存量行）。
   - **⚠️ 改绑后必须回验（2026-08-17 21:35 实测教训）**：文档曾记录 sess-cfg-2/3/4/15 已改绑 58，但生产库实际**仍是 1**（21:35 songspace 聊天被拦「未配置远端引擎」）——改绑可能未执行或被执行后又写回。修复脚本 `/root/grape/scripts/fix_chat_config_local_direct.py`：用 `_resolve_chat_runtime_id('opencode')` 同源解析目标（queue_remote 下必为远端行）+ 回验目标 credential active + 全量改绑坏行（含指向已删 runtime 的 sess-cfg-1/14 rid=23/13）+ 清 runtime=1 死队列任务。改绑后 `SELECT id, runtime_id FROM chat_agent_session WHERE id LIKE 'sess-cfg-%'` 确认无 1/0/悬空 rid。send_stream 直接取 `cfg.runtime_id`（chat.py ~328），不重解析——配置行持健康远端行即通。

## 判别与既有坑的关系
- 与「事件 running + 幽灵 runtime」（references/event-stuck-running-diagnosis.md）同族：都是任务入队到无人 claim 的 runtime。区别：本坑 runtime 行**存在且是 credential_id=0 的本机直连行**，不是被删/被吊销的行。
- 与「换 token 后旧行残留 online」（references/stale-runtime-binding-token-swap.md）区别：那坑是死行 status='online' 骗过 pick_engine；本坑是本机行 status='offline'，纯靠强制 queue_remote + 配置解析落上去。
- 8-12 修的「chat 路由忽略用户绑定 runtime」（references/chat-runtime-routing.md）是本坑的上一代变体——那次修复引入了 `_resolve_chat_runtime_id`，而它把裸引擎名解析到本机直连行，在 queue_remote 下成了新黑洞入口。

## 附带观察（未深查）
- hello-todo 引导 Issue 内容错位：agent 把 Issue #2 说成「引导·探索方向」+ 4 个探索方向，但 gitcode 上 #2 实际标题是【体验】快速部署——疑似 onboarding 模板 issue 标题/类型对错位，待用户确认是否处理。
