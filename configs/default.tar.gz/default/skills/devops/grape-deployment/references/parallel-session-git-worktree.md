# 并行会话共用一个 git 工作区：安全操作法（2026-08-17 实测）

## 症状与事故
- 主工作区 /root/grape 被另一个 Hermes 会话占用（它在 feat/skill-sync-multiplatform 分支编辑 docs/skill-publish-design.md 未提交）
- 事故链：
  1. `git checkout dev 2>&1 | tail -1 && git pull ... && git checkout -b feat/xxx && git push ...` —— **管道 tail 掩盖 checkout 失败**（`cmd | tail` 的 exit code = tail 的 0，`&&` 链继续）→ 分支实际创建在**错误基线**（skill-sync 的 957e6ef4）上
  2. 并行会话随后把工作区切回 skill-sync（reflog 可见 `checkout: moving from feat/xxx to feat/skill-sync-multiplatform`）→ 我的 commit 落在 skill-sync 分支上（污染）
  3. 远程 feat/xxx 分支指向旧 HEAD（1a784208），本地新提交却挂在别的分支 → push 显示 "Everything up-to-date" 实际没推上去
  4. 再 checkout 特性分支时 `Aborting`（并行会话的未提交改动挡住）

## 判别三件套
1. **reflog 溯源**：`git reflog -10` 看 HEAD@{N}——`checkout: moving from X to Y` / `commit:` 行能定位是谁（哪个会话）在何时切分支/提交（本会话靠它发现并行会话的 1a784208 v3.0 docs 提交和分支切换）
2. **git branch --contains <commit>**：确认提交落在哪个分支（误提交定位）
3. **git status --short + 文件 mtime**：判断未提交改动是"并行会话正在编辑"还是"已提交"（stash 报 "No local changes to save" = 对方已自行提交，工作区安全）

## 安全操作法
1. **worktree 隔离**（并行会话占用时唯一安全路径）：
   ```
   git worktree add /tmp/grape-etl feat/xxx        # 独立 checkout，不碰主工作区
   cd /tmp/grape-etl && git cherry-pick <commit>   # 搬移误提交
   git push origin feat/xxx
   git worktree remove /tmp/grape-etl
   ```
   ⚠️ worktree 是 gitignored 文件的空目录：需要 `cp` 主工作区的 configs/db-backend.json 等才能跑连 MySQL 的代码；`.hermes/environment.json`（hermes verify manifest）也要 cp；`mkdir -p data`（日志/测试库路径）
2. **git 命令不接管道**（或管道后检查 `${PIPESTATUS[0]}`）：`git checkout X` 直接跑，失败会中断 && 链；确需 tail 用 `git checkout X 2>&1 | tail -1 || echo FAIL`
3. **不 stash/不 checkout -- 并行会话的未提交改动**：先 `cp` 备份到 /root/deploy/parallel-session-backup/ 再决定；对方已提交则工作区干净可直接切
4. **提交前确认当前分支**：`git branch --show-current` + `git log --oneline -2`（parent 是否符合预期）——本次误提交就是没查这两样

## 部署时并行会话的处理
- 用户要求部署时若并行会话有未提交改动：先备份文件 → 确认它是否已提交（git log -- <file>）→ 已提交则直接切分支部署
- 本地 dev 领先 origin/dev（含并行会话提交的 docs）时，按 SKILL.md「本地 dev 领先」节处理：纯 docs 无害，部署基线=本地 HEAD，推送与否问用户
