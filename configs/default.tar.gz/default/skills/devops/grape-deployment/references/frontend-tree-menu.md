# Grape frontend: tree sidebar menu + jsdom verification (2026-08-11)

Frontend = plain HTML/JS/CSS, no framework, no build step. All in `src/api/static/`.
Editing static files takes effect immediately (uvicorn StaticFiles) — **no service restart**;
only bump `?v=N` refs in index.html to bust browser cache. Webhook serves no static assets.

## Sidebar structure (index.html `.sb-nav`)

Original: flat `.grp` group headers + sibling `<a onclick="app.nav('view')">` items.
Tree menu (2026-08-11, commit f95355a): each `.grp` is a clickable header, its items
wrapped in a sibling `.grp-items` container:

```html
<div class="grp open" onclick="app.toggleGroup('grp-ws')"><span class="ct">▸</span>Workspace</div>
<div class="grp-items open" id="grp-ws">
  <a id="nav-dash" class="act" onclick="app.nav('dash')"><span class="ic">■</span>Dashboard</a>
  ...
</div>
```

- Container id = the string passed to `app.toggleGroup(id)`; `.grp` must be the
  `previousElementSibling` of its `.grp-items` (nav() auto-expand depends on this pairing).
- 13 menu items total: Workspace 2 + DevOps Agents 5 + DevOps Skills 1 + Account 2 + Settings 3.
- Caret `<span class="ct">▸</span>`; CSS rotates it 90° when group is open.

## JS (app.js)

`toggleGroup` — the only function needed for click-to-expand:

```js
function toggleGroup(id) {
  const box = $(id);
  if (!box) return;
  const isOpen = box.classList.toggle('open');
  const grp = box.previousElementSibling;
  if (grp && grp.classList.contains('grp')) grp.classList.toggle('open', isOpen);
}
```

Auto-expand inside `nav(view, param)` — after the active-item marking block:

```js
let _actEl = navEl; // navEl = $('nav-' + view), may be null for param views
document.querySelectorAll('.sb-nav a').forEach(a => {
  const o = a.getAttribute('onclick') || '';
  if (param && o.includes("'" + param + "'")) { a.classList.add('act'); _actEl = a; }
  else if (!param && o === "nav('" + view + "')") { a.classList.add('act'); _actEl = a; }
});
if (_actEl) {
  const _box = _actEl.closest('.grp-items');
  if (_box && !_box.classList.contains('open')) {
    _box.classList.add('open');
    const _g = _box.previousElementSibling;
    if (_g && _g.classList.contains('grp')) _g.classList.add('open');
  }
}
```

Active-marking is onclick-string-based, NOT id-based: `nav('settings','credentials')`
has no `#nav-settings` element; matching relies on `o.includes("'credentials'")`.
Export `toggleGroup` in the module's return object or `onclick="app.toggleGroup(...)"` dies.

## CSS (appended at end of app.css)

```css
.sb-nav .grp{display:flex;align-items:center;gap:6px;cursor:pointer;user-select:none;transition:color .12s;padding:12px 8px 4px}
.sb-nav .grp:hover{color:#fff}
.sb-nav .grp .ct{font-size:9px;opacity:.8;transition:transform .15s;display:inline-block}
.sb-nav .grp.open .ct{transform:rotate(90deg)}
.sb-nav .grp-items{display:none}
.sb-nav .grp-items.open{display:block}
```

## jsdom verification recipe (deterministic, no login, no browser daemon)

When the browser daemon is unavailable/times out, jsdom validates menu behavior end-to-end.
Install is fast via the npmmirror registry (seconds on this box):

```bash
mkdir -p /tmp/menutest && cd /tmp/menutest
npm install jsdom --no-audit --no-fund --registry=https://registry.npmmirror.com
```

Test script essentials (test.js):

```js
const fs = require('fs');
const { JSDOM } = require('jsdom');
const html = fs.readFileSync('/root/grape/src/api/static/index.html', 'utf8');
const dom = new JSDOM(html, { runScripts: 'dangerously', url: 'http://localhost/' });
const { document } = dom.window;
// app.js is an IIFE (`const app = ...`) — const does NOT attach to window;
// eval it with an explicit export line, then drive it directly:
dom.window.eval(fs.readFileSync('/root/grape/src/api/static/js/app.js', 'utf8') + '\n;window.__app = app;');
const app = dom.window.__app;
```

Assertions that caught real bugs:
- grp/grp-items adjacency + onclick id matches the container id (5 pairs)
- menu item count === 13
- initial state: only `grp-ws` open
- `app.toggleGroup('grp-agents')` → open; second call → closed
- `app.nav('coding')` → `grp-agents` auto-expands, `nav-coding` gets `.act`
  (wrap nav() in try/catch — it fetches APIs that 401/404 without a token; act/expand
  logic runs before the fetch, that's what you're asserting)
- `app.nav('settings','credentials')` → `grp-settings` expands, `nav-settings-credentials` active
- `nav()` returns early when `currentRepo` is missing (except repos/settings/tasks views) —
  seed `localStorage.currentRepo` first or the auto-expand code never runs

Pitfalls:
- `new_tab()` in the browser daemon can hang/timeout on this box; jsdom is the fast,
  deterministic fallback — keep the DOM assertions there, use the browser only for
  visual/pixel checks.
- jsdom does not run `<script src>` loading by itself — eval the page JS manually (above).
- After any edit, verify live serving too: `curl -s http://127.0.0.1:8000/static/index.html |
  grep -c grp-items` and bump `?v=` refs in index.html (see SKILL.md).
