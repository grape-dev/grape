# 引擎绑定/显示双数据源 + revoke 后旧行残留解析事故（2026-08-17 实测）

## 背景时间线（一次 revoke 引发的三连坑）
1. 10:42 管理台批量 revoke 10 个凭据（见 worker-credentials-bulk-revoked.md）→ 旧 agent_runtimes 行**保留但凭据 revoked**
2. 10:45 部署新前端 dashboard.js：删掉 `ag.backend || meta.default_backend || 'opencode'` 兜底 → 未绑定会话从此显示红字「无 engine，不可用」（此前被兜底掩盖）
3. 11:26 服务端 backfill_existing_bindings 自动回填 binding 表（meta `bindings_backfilled`=1 幂等）——回填的是 **revoked 旧行**
4. 11:29 用户配置 engine → resolve 命中旧行 → binding/session 写入死引擎 → dashboard 显示引擎名但任务 401

## 根因 A：instance_name 撞车（sanitize_device 截断）
- `sanitize_device` 截断 24 字符：`worker-ecs-grape-dev-build-0002..0006` 全变 `worker-ecs-grape-dev-bui`（23 字符），新旧行同 device → 实例名撞车（`opencode-...-bui` 撞 7 行、`hermes-...-bui` 撞 8 行）
- `resolve_instance_id` 逐行匹配**无排序无过滤**，MySQL 按主键序第一个命中 = 旧行（id 小）→ 用户配的新引擎实际落到 revoked 旧行
- 实测：resolve('hermes-...-bui')→18、resolve('opencode-...-bui')→17（均 revoked）
- 修复：`sanitize_device` 改「保头保尾」——截断时保留末尾数字段（`worker-ecs-grape-de-0002` vs `-0006`，唯一）

## 根因 B：引擎解析路径全不过滤 revoked 凭据
revoke 后旧 agent_runtimes 行是死行，但以下函数仍会命中它们：
- `resolve_instance_id`（instances.py）——按派生名匹配
- `get_runtime_id_by_name` / `ensure_default_runtime`（user/db.py）——按类型名+online 排序
- `query_engines`（engine_select.py）——resolve_default_engine / onboarding 默认引擎候选

修复统一加 `(ar.credential_id=*** OR rc.status='active')`（本机直连 credential_id=0 永远合法；LEFT JOIN 后本机行 rc.status 为 NULL→''）：
- resolve_instance_id：SQL 加 `ORDER BY CASE WHEN ar.credential_id=*** OR rc.status='active' THEN 0 ELSE 1 END, ar.id`，循环内只认 active/本机
- get_runtime_id_by_name / ensure_default_runtime：WHERE 加条件 + LEFT JOIN runtime_credentials
- query_engines：`AND rc.status='active'`

## 根因 C：dashboard 与 config 页读两个数据源
- **dashboard 显示 engine = devops_agent_session.runtime_id**（LEFT JOIN agent_runtimes 取名）
- **config 页（Configure 面板）显示 engine = devops_agent_runtime_binding**（引擎集合，engine-selection v2 新机制）
- session.runtime_id 有 3 条「自动绑定」路径不写 binding 表 → config 未配置但 dashboard 显示有引擎：
  1. **scenes.py apply_scene**（dashboard「应用」按钮）：旧代码无条件 `ensure_default_runtime("opencode")` 写 session，binding 不动 → 点一次应用所有 agent 凭空绑 opencode
  2. event_pipeline 事件处理 get_or_create_agent_session(backend) 兜底
  3. 历史存量会话（11:26 回填前全平台处于「config 空 + dashboard 有引擎」状态）
- 修复 scenes.py：保留会话现有 runtime_id；无绑定 → `resolve_default_engine + set_binding`（与 ensure_default_agent_sessions 同源，两个数据源一致）
- 修复 dashboard.py：JOIN 带 `COALESCE(rc.status,'')`，revoked → backend 置空走前端红字（如实反映不可用）

## 存量迁移 SQL（备份后执行）
```sql
-- 备份（先跑）
CREATE TABLE backup_devops_agent_runtime_binding_<date> AS SELECT * FROM devops_agent_runtime_binding;
CREATE TABLE backup_devops_agent_session_<date> AS SELECT * FROM devops_agent_session;
-- binding 迁移（repo_key 不带 gitcode: 前缀；排除 chat 与本机直连 id 1）
UPDATE devops_agent_runtime_binding b JOIN agent_runtimes ar ON ar.id=b.runtime_id
  SET b.runtime_id=52 WHERE b.agent_type<>'chat' AND ar.name='opencode' AND b.runtime_id NOT IN (0,1);
UPDATE devops_agent_runtime_binding b JOIN agent_runtimes ar ON ar.id=b.runtime_id
  SET b.runtime_id=53 WHERE b.agent_type<>'chat' AND ar.name='hermes';
UPDATE devops_agent_runtime_binding SET runtime_id=52 WHERE agent_type<>'chat' AND runtime_id=11; -- 行已不存在的
-- session 迁移（repo_key 带前缀；映射同上；52=opencode 新行, 53=hermes 新行）
```
⚠️ chat 会话（agent_type='chat'）绑 user scope 个人引擎，语义不同**不要**一并迁移——revoke 后 chat 引擎失效需用户重配个人引擎（本次 6 个 chat 会话仍绑 revoked 凭据 17/20/13/15）。

## 修复后验证
- `resolve_instance_id('opencode-worker-ecs-grape-de-0002')` → 52（active 新行），不再 17/18
- `query_engines(repo, 'global')` 只返回 active 新行（52-61）
- `resolve_default_engine` → 52（scenes 修复路径）
- pytest：tests/test_engine_select.py + tests/test_scene_apply_enable.py（23 passed）
- 服务重启后（见下）dashboard 实测：redbook-operate 全 active 显示、test1 无绑定红字

## 根因 D：Engines 页 orphan 兜底分支遍历 cached 全量（2026-08-17 下午，吊销全部 worker 后页面几十个"离线本机 runtime"）
- 症状：管理台吊销**所有** worker 凭据后，Runtime 页出现几十个"离线本机 Runtime"设备卡 + "在线 · 未上线"本机卡
- 根因：settings.py `get_agent_runtimes` 的 orphan 兜底分支（`if orphan_ids and not devices:`）遍历 `cached`（`get_agent_runtimes(scope=None)` **全量** 42 行），而**不是**过滤后的 `visible_runtimes`。revoke 全部凭据 → devices（`WHERE status='active'`）为空 → 必触发兜底 → 40 行 revoked/远端行全部以 `credential_id=0`「本机 Runtime」设备伪装展示（数据库实测：42 行里真本机只有 2 行）
- "在线 · 未上线"：兜底分支硬编码 `last_seen_at=None` + 本机行（installed+healthy）health 派生 online → 前端 Workers 卡 `_healthBadge(health, relTime(None))` → "在线 · 未上线"（本机直连不走心跳，last_seen_at 恒 NULL，"未上线"语义误导）
- 修复：① orphan 分支改遍历 `visible_runtimes` 且只收 `(credential_id or 0)==0` 的行（scope 用 rt 自身值）；② 前端 renderWorkers 设备卡 suffix 改 `d.credential_id ? relTime(d.last_seen_at) : '本机直连'`；③ index.html bump runtimes.js `?v=6→7`
- 回归测试：`tests/test_runtime_protocol.py::TestMultiInstanceDeviceView::test_revoke_all_credentials_no_fake_local_devices`（revoke 需登录态，用 override 后的 TestClient 发 revoke）
- 教训：视图层"兜底/空态分支"最容易绕过过滤逻辑——空态分支也要复用主过滤结果，别重新遍历原始全量

## 根因 E：revoke 语义改为「吊销=删除」（2026-08-17 下午，用户指示）
- 背景：用户吊销 coding-worker 后重建同名失败「凭据名称已存在」——revoked 行不释放全局唯一名
- 用户拍板：「只要吊销就删掉对应的 worker 记录」
- 实现（settings.py revoke_runtime_credential）：DELETE runtime_credentials 行 + 级联 DELETE agent_runtimes（该凭据注册的引擎行）+ 清理 devops_agent_runtime_binding 指向被删行的记录 + devops_agent_session.runtime_id 置 0（dashboard 红字「无 engine」）
- 影响面核对：get_runtime_id_by_name / resolve_instance_id / query_engines / Engines 视图的 `rc.status='active'` 过滤全部靠 LEFT JOIN——删行后 rc 行不存在 → status NULL → 但这些 agent_runtimes 行也一并删了，无残留行可命中，逻辑自洽无需改
- 恢复语义变化：旧「UPDATE status='active' 复活」只对变更前的历史 revoked 行有效（见 worker-credentials-bulk-revoked.md）；删除后 token 丢失不可恢复，只能重建凭据+重装 worker
- 测试更新：test_revoke_marks_runtime_offline → test_revoke_deletes_credential_and_runtimes；test_revoked_old_credential_new_row 断言旧行被删只剩新行
- 教训：用户说「吊销」到底指「失效」还是「删除」要先问清/按用户明确指示；此处用户 2026-08-17 明确「只要吊销就删掉」

## 部署相关坑（同 session）
- **改代码 ≠ 生效**：前端静态文件实时生效，后端 Python 需重启。本次 10:45 改 dashboard.py 但服务 08-14 起没重启 → 进程跑旧代码、磁盘新代码，前后端字段名都可能对不上。改后端必重启双服务并 curl /health 验证。
- **前端 instance_name 变化 → 配置页回显丢**：binding 表存 runtime_id（id）安全，但 agents GET 的 backends 回显用 instance_name 字符串，改名后旧值不匹配需用户重新勾选一次（一次性，可接受）。
- **pkill -f 自杀坑**：`pkill -f 'pytest tests/test_xxx.py'` 会匹配到**自己这条 shell 命令行**（命令行里含该字符串）→ 把自己 SIGTERM（exit -15）。用 `pkill -f 'test_xxx.[p]y'` 字符类技巧，或 `ps aux | grep '[p]ytest' | awk '{print $2}' | xargs -r kill`。
- **重启后端口起不来 = metadata lock**（复测确认）：本次锁来自 worker 0002（192.168.0.115, grape 用户）连接泄漏的未提交事务（innodb_trx trx_state=RUNNING、Sleep 连接），新进程 `ALTER TABLE events` 卡 Waiting for table metadata lock。`KILL <trx_mysql_thread_id>` 后迁移继续、端口起来，worker 自动重连无需重启。
