# codegraph 离线安装与发布打包（2026-08-18 实测）

## 包名坑（2026-08-18 实测）
- npm registry 的 `codegraph`（1.0.0）= **空壳占位包**：package.json 无 bin 字段、files 只列 dist 但 dist 目录不存在。
  `npm install -g codegraph` 装完 `codegraph: command not found`，无任何可执行产物。
  redbook-operate 的 degraded note "codegraph unavailable (broken install, no dist/)" 就是此坑的历史记录。
- 真包 = **`@colbymchenry/codegraph`** 1.5.0（github.com/colbymchenry/codegraph；README npm 徽章即 scope 包名）。

## 包结构
- 主包 ~228KB（安装器/SDK，npm-shim.js 入口）。
- 平台二进制 = optionalDependencies 独立包 `@colbymchenry/codegraph-linux-arm64` / `-linux-x64`（各 ~60MB tgz，
  含 `node/` 自带运行时 + `bin/codegraph` 启动器 + `lib/` Rust 内核 + wasm 语法，解压 ~279MB）。
- **平台包解压后 `bin/codegraph` 完全独立运行**（unix 分支直接 exec bin/codegraph，无需系统 node/npm）——
  离线分发只需平台包，主包可不要。

## 离线安装
```
tar xzf <平台tgz> -C <dest> --strip-components=1   # 去掉 package/ 前缀
ln -sf <dest>/bin/codegraph /usr/local/bin/codegraph
codegraph --version                                 # 1.5.0
```
幂等：已装同版本跳过。仓库脚本 `scripts/install-codegraph.sh`（参数 --src/--prefix/--arch；
auto 按 uname -m 选 linux-arm64/linux-x64；tgz 匹配模式 `colbymchenry-codegraph-${PLAT}-*.tgz`）。

## 发布包集成（grape-system）
- 离线资源目录 `/root/deploy/codegraph-offline/`（arm64+x64 两个 60MB tgz + 主包，**不进 git**）；
  release_pack.py `CODEGRAPH_DIR`（env 可覆盖，缺失则 toolkit 不带 codegraph 不阻塞打包）。
- toolkit 子包带自包含 `codegraph/` 目录（双架构 tgz + install-codegraph.sh）；INSTALL.md §6.6 服务端安装步骤
  （解压 toolkit → `bash .../codegraph/install-codegraph.sh --src .../codegraph`）；§9 验证矩阵加 `codegraph --version`。
- **worker 运行时包（grape-worker.tar.gz）不带 codegraph**（2026-08-18 用户拍板：codegraph 分析只在服务端执行；
  曾误加 worker_package.py 已回退——不要再次往 worker 包加）。
- 打包验证：`tar tzf grape-toolkit-*.tar.gz | grep codegraph` 应见 3 tgz + install-codegraph.sh；
  离线安装模拟 `bash install-codegraph.sh --src <codegraph目录> --prefix /tmp/x` 后独立运行 `--version`。

## 触发 build_project_info 的 token 前提
- `get_gitcode_token` 链：devops_agent_session.repo_gitcode_token → managed_repos.bot_gitcode_token → 全局 bot token。
  仓库级 bot_gitcode_token 为空时落全局 bot（如 gcw_3FZApeLT）可能无权读仓库 →
  `CH.00905404 can not read project` / 403 → ensure_repo_base fetch 失败 → "analysis worktree failed"。
- 修：`UPDATE managed_repos SET bot_gitcode_token='***' WHERE repo_key='gitcod...epo>'`
  （git clone 经 `-c http.extraheader=Authorization: Basic base64...n>)` 注入，见 repogit._run_git；
  用户 token 形如 `yXgZq-...`，非 GitHub 风格）。
- `_ensure_analysis_worktree` 已含 codebase 缺失时 ensure_repo_base 主动建立（docs 定案的一行级修复，已实施）。
- 生成成功的判别：`build_project_info` 返回 `{'ok': True, 'degraded': False}`；看板显示不再出现
  "codegraph unavailable, generated from README + GitCode API"。
