# MySQL 保留字 1064 排查实录（agent_runtimes.binary，2026-08-11）

## 症状
- 远端 worker 的 opencode 永远不出现在 Engines 页；worker 日志：
  `RuntimeClient POST /api/runtime/register retries exhausted`（systemd 重启计数递增）。
- 用 worker token 直 curl `POST https://grape-dev.topxtopx.com/api/runtime/register` → HTTP 500：
  `(1064, "You have an error in your SQL syntax; ... near 'binary, version, healthy, installed, status, last_seen_at, cli_path, scope, owne...'")`
- 本仓库/本地开发用 SQLite 不报错；dev 服务器是 MySQL → 语法错误 → worker 永远注册不进去。

## 根因
- `agent_runtimes` 表有列 `binary`（MySQL 8.0 保留字），register 的 INSERT 未加反引号。
- `src/mysql_compat.py::translate_sql` 的自动反引号覆盖有盲区：
  - CREATE/ALTER 语句中的 `binary` → 自动反引号（`re.sub` 仅匹配 CREATE/ALTER 开头的 SQL）。
  - SQL 中出现 `meta` 单词时 `key` → 自动反引号（`_backtick_key`，保护 PRIMARY/UNIQUE/FOREIGN/INDEX KEY）。
  - **DML（INSERT/UPDATE）的列名列表完全不在覆盖范围内** → 源码里必须手动反引号。

## 修复（3 处，反引号 SQLite/MySQL 双端通用）
1. `src/api/routes/runtime.py` register 的 INSERT 列名 `binary` → `` `binary` ``。
2. `src/api/db_setup.py` agent_runtimes 建表 DDL `binary TEXT DEFAULT ''` → `` `binary` TEXT DEFAULT '' ``。
3. `src/api/db_setup.py::_ensure_column` ALTER 语句对列名统一加反引号：
   `f"ALTER TABLE {tbl} ADD COLUMN `{col}` {ddl}"`（修复老库迁移路径）。

## 验证方法（可直接复用）
1. **直连 pymysql 实测 SQL 语法**（绕过应用层翻译，最快定位 1064）：
   ```python
   cur.execute("EXPLAIN INSERT INTO agent_runtimes (..., binary, ...) VALUES (...)")  # FAIL 1064
   cur.execute("EXPLAIN INSERT INTO agent_runtimes (..., `binary`, ...) VALUES (...)") # OK
   ```
   `EXPLAIN` 不产生副作用；若真要执行 INSERT 验证，包在 `START TRANSACTION` ... `ROLLBACK` 里不留脏数据。
2. **检查 translate_sql 覆盖**：`print(translate_sql(raw_sql))` 看翻译后输出是否已加反引号——
   确认哪些 SQL 会被自动处理、哪些需要源码改。
3. **SQLite 冒烟**：反引号在 SQLite 里合法，`CREATE TABLE ... (`binary` TEXT ...)` + INSERT 均可执行。
4. **同类隐患逐条实测**（别凭"像是保留字"就改）：
   - `meta.key` → translate_sql 已自动处理（含 meta 的 SQL 会反引号 key），无需改。
   - `user_repos.role` / `chat_messages.role` → `role` 不是 MySQL 8.0 保留字，直连 EXPLAIN 通过，无需改。
     （早前 user_repos 的 1064 是 `INSERT OR REPLACE` 方言问题——translate_sql 会转 `REPLACE INTO`。）
5. **改动后全量测试对照**：7 failed 中逐个归类——已知基线（需 bot token、ui_scenario 连远程）、
   flaky（executor 信号时序）、顺序依赖（`test_scene_apply_enable`/`test_tasks` 单独跑通过）；
   用 `git stash` + 只跑可疑用例 + `git stash pop` 证明"改动前就失败"。

## 部署与恢复
- register 挂 grape-main（main.py include_router runtime）；重启前查 in-flight opencode 进程
  （`ps aux | grep 'opencode run'`），重启后清理 running 僵尸事件（见 best-practices 安全重启节）。
- 服务端修复后 worker 端不用动：runtime-agent 每 ~1 分钟自动重试注册，agent_runtimes 表
  出现新行且 last_seen_at 刷新 = 恢复成功。
- 验证注册接口不再 500：坏 token 应返回 401（"runtime credential revoked or not found"）而非 500。

## 同类坑 #2：UPDATE...RETURNING id（2026-08-11 晚，claim 全挂）
- 症状：所有 worker 每秒 `claim failed: (1064, "... near 'RETURNING id' at line 16")`，
  agent_tasks 有 queued 任务也无人认领（direct 模式下 agent 不走队列所以本次没卡任务，
  但 queue 模式必死）。
- 根因：`src/runtime/service.py::claim` 用 SQLite 3.35+ 的 `UPDATE ... RETURNING id`；
  MySQL 8.0 无 RETURNING → 1064。且 UPDATE 目标表出现在子查询（`WHERE id=(SELECT ... FROM agent_tasks ...)`）
  触发 MySQL 1093——translate_sql 只包了 DELETE...NOT IN 场景，UPDATE 子查询要源码规避。
- 修复：拆两步——先 `SELECT id ... WHERE runtime_id=? AND status='queued' AND NOT EXISTS(...) ORDER BY created_at LIMIT 1`，
  再 `UPDATE agent_tasks SET status='dispatched', started_at=? WHERE id=? AND status='queued'`；
  并发时 UPDATE 影响行数 0 = 被其他 worker 抢走，原子性不变。两条 SQL 在 MySQL 直连实测通过。
- 验证：修复后 `journalctl -u grape-main | grep -c 'claim failed'` 应为 0（修复前每秒 1 条）。

## 同类坑 #3：会话缺 skill → 事件卡 running（2026-08-11 晚，vod 无回复）
- 症状：事件 status='running' 但 started_at 空 / agent_logs 空 / 无 opencode 进程，
  UI 显示"一直在运行"。webhook 日志停在 `Pipeline: event created, seq=N` 后直接 `pipeline done`，
  没有 `started agent execution` 也没有 `enqueued task`。
- 根因：`devops_agent_session` 该 repo+agent 的 skill=''（UI 新建会话只配 runtime 不配 skill）
  → run_pipeline 分派条件 `backend and skill_name and seq > 0` 中 skill_name 为假 →
  两个分派分支都不走，事件 append 成 running 后无任何执行。
- 修复：event_pipeline.py 默认 skill 回退条件 `if not backend` 扩为 `if not backend or not skill_name`
  （从 configs/agent-skill-mapping.json default scene 回退：vod→vod, issue→issue,
  coding→implementation, qa→pr, sre→cloud-deploy）。
- 已卡事件恢复（direct 模式）：① 补会话 `UPDATE devops_agent_session SET skill='vod', skill_id=<id>
  WHERE repo_key='gitcode:owner/repo' AND agent_type='vod'`（skill 表查 id，vod=61）；
  ② 重建 evt（repository/issue_id/type/payload 从 events.payload 取）直接调
  `_execute_agent(repo_key, seq, agent_type, "opencode", skill, evt)` 重放。
- 对比排查法：同仓库另一正常事件（如 seq=50 skillshub skill='vod'）与卡死事件（skill=''）
  对照，一眼看出 skill 缺失。

## 同类坑 #4：ALTER TABLE ADD COLUMN 的 TEXT DEFAULT 字面量 → MySQL 1101（2026-08-13，main→dev 合并部署）
- 症状：`db_setup.py::_ensure_column` 补列后列仍缺失——日志
  `[WARNING] Add agent_tasks issue isolation columns failed: (1101, "BLOB, TEXT, GEOMETRY or JSON column 'knowledge_files' can't have a default value")`，
  except 吞掉异常 → 列静默缺失 → enqueue_task INSERT knowledge_files 时 1054 Unknown column。
- 根因：SQLite 允许 `TEXT DEFAULT '{}'`；MySQL 8.0.13 前 TEXT 列不允许 DEFAULT 字面量。
  `translate_sql` 的 `TEXT DEFAULT 'x' → DEFAULT ('x')` 表达式转换只在 `_translate_create_table`
  （CREATE TABLE 路径，253 行）里做；`ALTER TABLE ... ADD COLUMN` 走不到 → 1101。
  本次两个受害者：`agent_tasks.knowledge_files`（main 的 Event 对话引入）、`devops_agent_session.subscribe_events`（SRE 订阅）。
- 修复（79958b21，已推送 dev）：
  1. `src/mysql_compat.py::translate_sql` ALTER 分支加同款转换：
     `(\bADD\s+COLUMN\s+[`\"\w]+\s+TEXT(?:\s+NOT\s+NULL)?\s+DEFAULT\s+)'((?:[^'\\]|\\.)*)'` → `DEFAULT ('<lit>')`。
  2. 存量库手动补列（或重启服务让修复后的 db_setup 自动补）：`ALTER TABLE ... ADD COLUMN ... TEXT DEFAULT ('{}')`。
- 验证：`print(translate_sql("ALTER TABLE agent_tasks ADD COLUMN \`knowledge_files\` TEXT DEFAULT '{}'"))`
  应输出 `DEFAULT ('{}')`；重启后 journalctl 出现 `Added ... columns to agent_tasks` INFO 且无 1101 WARNING。
- 排查链路：重启后查 MySQL 列缺失 → journalctl grep "column failed"（1101 被 except 吞，必须看日志）→
  比对 translate_sql 的 CREATE/ALTER 覆盖差异。TEXT 列其实不需要 DB 默认值（代码都显式 INSERT 或 NULL 安全），
  但 translate_sql 通用修复防再踩，比删 DEFAULT 更稳。

## 同类坑 #5：按 sqlite 异常消息文本判断 → MySQL 下失效（2026-08-17，生成凭据误报 500）
- 症状：管理台「生成凭据」报 `生成失败: 生成失败: (1062, "Duplicate entry 'coding-worker' for key 'runtime_credentials.name'")`
  （前端 catch 拼 "生成失败: " + 后端 500 detail.message，而后端 500 message 本身又是 "生成失败: {e}" → 双重前缀即 500 特征）。
- 根因：`settings.py` create/rename runtime-credential 的异常分支
  `if "UNIQUE" in msg and "runtime_credentials.name" in msg` 只匹配 **sqlite3** 消息格式
  （`UNIQUE constraint failed: runtime_credentials.name`）；**pymysql** 的 IntegrityError str 是
  `(1062, "Duplicate entry 'xxx' for key 'runtime_credentials.name'")`——**不含 "UNIQUE" 字样** →
  恒 False → 误落 500「生成失败」分支，重名该报的 400 友好提示「凭据名称已存在」永远到不了前端。
- 修复：判断扩为 `("UNIQUE" in msg or "1062" in msg or "Duplicate" in msg) and "runtime_credentials.name" in msg`，
  两处（create ~L433 / rename ~L467）。全局 grep `"UNIQUE" in` 确认无其他异常消息盲区
  （mysql_compat.py 的 `"UNIQUE" in sql.upper()` 是检查 SQL 文本本身，不是异常消息，正常）。
- 通用教训：**凡按 `str(e)` 文本判断异常的代码都要双端验证**——pymysql 错误消息是
  `(errno, "msg")` 元组 str 化，sqlite3 是纯文本，同样的判断逻辑两端行为可能不同。
  优先按 errno（`getattr(e, 'args', ())[0] == 1062`）或同时匹配多种特征。
- 附带：凭据名全局唯一（`runtime_credentials.name` 唯一键），**revoked 凭据的名字也不释放**——
  用户想复用已注销设备的名字（如 coding-worker）依然 1062，属设计如此，提示换名即可。
- 回归测试：`tests/test_runtime_protocol.py::TestRuntimeAdminViews::test_dup_credential_name_returns_400`
  （sqlite 下验证重名→400；MySQL 消息分支靠实库复现 + 匹配逻辑等价性验证，见下）
- 实库复现/验证手法（只读安全）：pymysql 直连 `INSERT` 同名 → 捕获 IntegrityError 打印
  `str(e)` 各特征命中情况，再对修复后条件断言。⚠️ 该 INSERT 必须 `conn.rollback()` 收尾
  （见下面 pymysql 事务坑）。

## 附带坑：pymysql 只读脚本 SELECT 也会开事务（2026-08-17，metadata lock 帮凶）
- 用 pymysql 写排查/模拟脚本时默认 `autocommit=False`——**SELECT 也会开启事务**，
  脚本结束前不 commit/rollback/close 会在 MySQL 侧留下 `trx_state=RUNNING` 的 Sleep 连接，
  持有 metadata lock，能卡住后续 `ALTER TABLE` 迁移（本次 14:34 的脚本遗留连接 7021880
  就是 KILL 的两个僵尸事务之一，与 worker 0002 的连接一起卡死 grape-main 重启）。
- 规矩：pymysql 脚本一律结尾 `conn.commit()`（或 rollback）+ `conn.close()`；
  长时间运行的只读排查连接也开 `conn.autocommit(True)` 最稳。

## Git 协作坑
- 本地改了相同修复后 push 被拒（远程已有他人提交）→ `git fetch && git rebase origin/lvjuntao`：
  rebase 会自动 drop 内容重复的本地提交（"patch contents already upstream"），不要 force-push 覆盖。
- 推送前扫描硬编码凭据：`grep -rn 'rta_[A-Za-z0-9]' src/ configs/ docs/ tests/`；
  注意 .pyc 文件会命中——用 `--include='*.py' --include='*.json' --include='*.md'` 限定源码文件。
  设计文档里的 token 串（ASCII UI mock）不是真实凭据，以 DB 中 runtime_credentials.token_hash 为准。
