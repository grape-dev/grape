# 前端静态文件功能开发完整工作流(2026-08-18 实测:Event History 对话窗口全屏)

## 场景
给管理台前端加功能(改 src/api/static/ 下的 html/js)。本会话实例:Event History 详情页"与 xx Agent 对话"窗口加全屏/还原按钮。

## 完整流程
1. **查工作区**:`git branch --show-current` + `git status --short`——可能 detached HEAD / 有并行会话未提交改动(index.html、knowledge.js 等),别人的改动一律不碰。
2. **worktree 隔离建分支**:`git worktree add /tmp/grape-<名> -b feat/<名> origin/dev`(dev 被 /tmp/grape-etl 占用时无法 checkout,worktree 是标准解)。
3. **改文件 + bump 缓存号**:改完 js/css 内容后 index.html 对应 `?v=N` 必须 bump(本会话 events.js 17→18),否则浏览器缓存旧文件。
4. **验证**:`node --check` + jsdom 行为测试(见下)。
5. **commit + push feat 分支**(用户确认后;用户工作流:特性分支推 origin 再讨论)。
6. **合入 dev(主工作区 detached HEAD 时)**:
   - `git stash push -m "..." -- <并行会话的未提交文件>`(cherry-pick 要求干净工作树)
   - `git cherry-pick <feat commit>`
   - `git stash pop`(改动在不同行/文件时干净恢复)
   - `git push origin HEAD:dev`(dev 被 worktree 占用,本地 dev ref 不动;先 `git rev-list --left-right --count origin/dev...HEAD` 确认 0/N = ff 安全)
7. **部署**:静态文件由 uvicorn StaticFiles **实时读磁盘,无需重启服务**(重启反而有 metadata lock 风险)。验证:`curl -s "http://127.0.0.1:8000/static/js/<file>?v=N" | grep <新函数名>` + health。用户浏览器需强刷(Ctrl+Shift+R)。

## jsdom 行为测试配方
```bash
mkdir -p /tmp/<test> && cd /tmp/<test> && npm init -y && npm install jsdom --registry=https://registry.npmmirror.com
```
要点:
- `window.eval(code)` 里 **function 声明不挂到 window**(间接 eval 作用域)——测试脚本需追加导出语句:`window.eval(code + '\nwindow.<fn> = <fn>;')`,否则 `window.<fn>` 调用报 not a function。
- 全局依赖(_AGENT_TYPES、app、renderMarkdown 等)需在 eval 前挂到 window 和 global 两边。
- 断言覆盖:初始状态 → 动作 → DOM 结构/样式断言 → 还原 → 幂等(连续切换无残留)→ ESC 兜底。本会话 21 项断言全过。

## 对话窗口结构备忘(events.js)
- `renderEventDetail`:右栏 320px grid,`convPanel`(标题 h3 + `convMessages` 消息区 + `convInputRow` 输入行,含 `convInput`)。
- 全屏实现 = DOM 移动:`toggleConvFullscreen()` 把 convMessages + convInputRow appendChild 进 `position:fixed;inset:0;z-index:999` 容器(带自己标题栏+还原按钮),原 panel `display:none`;还原时移回、panel 恢复 flex。DOM 移动保留 id/内联事件,SSE 发送逻辑(sendConversation/loadConversation 按 id 定位)不受影响。ESC keydown 监听兜底。

## 本地 dev ref 同步(dev 被 worktree 占用时)
- refs 全局共享,但移动 refs/heads/dev 只能在持有它的 worktree 里做:
  - 主仓库 `git fetch origin dev`(更新 origin/dev)
  - 持有 worktree 里 `git merge --ff-only origin/dev`(工作区干净时;同时更新共享 dev ref + 该 worktree 磁盘)
  - 主仓库 `git push origin dev` 确认 `Everything up-to-date`
- 先 `ps -p <pid> -o cmd` 确认 worktree 闲置(无进程在跑)再动。

## 凭据页变体(2026-08-18:华为云 AK/SK autocomplete + 显示/隐藏明文)
- 同类工作流(worktree → jsdom → 合 dev → 部署),但**涉及后端 settings.py**(GET /api/settings/credentials 返回真实 ak/sk)→ 部署需重启双服务(非纯静态),重启必踩 metadata lock,用 SKILL.md 六度补充的强杀+杀锁流程。
- jsdom 断言 18 项:默认 type=password、autocomplete="new-password" 属性、AK/SK 值回显、👁 点击切换 type=text + 按钮变 🙈、再点还原、保存体过滤(占位符/空不写入)。mock 需同时挂 window 与 global(API/app/_isCredPlaceholder)。
- 详情见 SKILL.md Frontend 节 autocomplete 条目(dev 1436ec08)。
