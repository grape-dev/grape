# ClawHub 发布机制（2026-08-17 官方文档调研）

来源: https://docs.openclaw.ai/zh-CN/clawhub (+ /clawhub/http-api)
用途: skill 多平台同步需求（feat/skill-sync-multiplatform）的 ClawHub 接入依据。
需求总文档: 仓库 docs/skill-sync-multiplatform-requirements.md（特性分支，待实施）。

## ClawHub 是什么
- OpenClaw Skills 和插件的公共注册表（类比 npm 之于 JS）。网站 https://clawhub.ai
- 跟踪语义化版本 / latest 标签 / changelog / 下载量 / 星标 / 安全扫描摘要
- skill = 包含 `SKILL.md` 及支持文件的**版本化文本包**

## 发布路径 A：ClawHub CLI（官方主路径，推荐）
```bash
npm i -g clawhub          # 或 pnpm add -g clawhub
clawhub login             # GitHub 账户浏览器授权
clawhub skill publish ./my-skill --slug my-skill --name "My Skill" --version 1.0.0
```
发布选项: `--slug`(URL 名) `--name`(显示名) `--version`(语义化) `--changelog` `--tags`(逗号分隔, 默认 latest)
其他: `clawhub whoami / search / install / update / list`
插件发布: `clawhub package publish <source>`（source 支持本地文件夹 / owner/repo / owner/repo@ref / GitHub URL；
`--dry-run` 预演不上传，`--json` 适合 CI）

## 发布路径 B：HTTP API（自动化集成用）
- 基础 URL https://clawhub.ai/api/v1；OpenAPI: `/api/v1/openapi.json`
- **核心端点 `POST /api/v1/skills`（发布新版本）**：首选 multipart/form-data（payload JSON + files[] blob）；
  也接受 JSON 正文（files 基于 storageId）；需 **Bearer 令牌**。
  可选 payload 字段: `ownerHandle`（服务端解析发布者并要求执行者有该发布者访问权）、`migrateOwner`
- `POST /api/v1/packages` = 代码插件/捆绑插件（multipart 直传上限 18MB，ClawPack tarball 走上传 URL 流程上限 120MB；
  需 openclaw.plugin.json / package.json + openclaw.compat.pluginApi + openclaw.build.openclawVersion 元数据）
- 其他: `GET /api/v1/search`（公共，无需认证）`DELETE /api/v1/skills/{slug}` / `.../undelete`（软删除/恢复）

## 认证与门槛（关键约束）
- **Bearer 令牌（clh_ 前缀）**：clawhub login 获取，存 CLI 配置（CLAWHUB_CONFIG_PATH 可覆盖存储位置）
- **发布者必须使用「注册达门槛」的 GitHub 账户**（防滥用）——不能用新号/小号
- 默认开放上传，但自动安全扫描；被暂缓/阻止的版本从公共目录消失，发布者仍可在 /dashboard 看到
- 环境变量: CLAWHUB_SITE（覆盖登录站点 URL）、CLAWHUB_REGISTRY（覆盖注册表 API URL）、
  CLAWHUB_DISABLE_TELEMETRY=1（关安装遥测）

## 令牌获取（用户侧，2026-08-17 实测网页路径——无需装 CLI）
- **网页直接拿令牌**：浏览器访问 `https://clawhub.ai/cli/auth` → GitHub 登录授权 → 拿 `clh_` 令牌
  （`/cli/auth`、`/cli/device`、`/dashboard` 三页均 HTTP 200 可访问）
- 设备码模式：`clawhub login --device` 打印代码 → 访问 `https://clawhub.ai/cli/device` 授权
- 无头模式：`clawhub login --token clh_...` 直接注入令牌（CI/服务器可用）
- `clawhub token` 命令打印已存令牌（管道给 CI 密钥设置用）
- CLI 令牌存储位置：macOS `~/Library/Application Support/clawhub/config.json`、
  Linux `$XDG_CONFIG_HOME/clawhub/config.json` 或 `~/.config/clawhub/config.json`

## 速率限制（自动化注意）
| 类型 | 匿名(IP) | 带令牌(用户) |
|---|---|---|
| 读取 | 3000/分 | 12000/分 |
| 写入 | 300/分 | 3000/分 |
| 下载 | 1200/分 | 6000/分 |
429 响应带 Retry-After，需退避重试；错误响应为 text/plain（400/401/403/404/429）。

## grape 集成建议（初判，待用户确认）
- CLI 方式更稳（官方封装 multipart/重试/扫描状态）；API 方式更嵌入但需自管令牌生命周期与 multipart
- grape 侧最小接入：ClawHub 令牌（用户 `clawhub login` 后填平台设置页，存安全位置）+ skill 创建完成事件后调 publish
- skill 元数据（slug/name/version/tags）建议从 SKILL.md frontmatter 自动提取，不让用户手配
- 发布门槛的 GitHub 账户 = 用户自己提供（需满足注册时长门槛）

## 开放问题（已确认 vs 待定，2026-08-17 用户拍板）
1. ✅ **发布账号 = 开发者自己的 ClawHub 账号**（每用户独立 clh_ 令牌，发布到开发者名下；令牌存
   `user_platform_tokens` 表（user_id/platform/clawhub_token），非 user_accounts 加列——settings.py
   `_get_clawhub_token` 读取 + db_setup 建表 + 设置页 Credentials 新增 ClawHub 区块）
2. ✅ **触发 = 聊天指令**（Issue 评论 / 飞书 / 管理台网页三入口，均走现有 chat/issue 技能链路）
3. ✅ **同步对象 = 创建 skill 的 Issue 关联 skill**（按对话上下文定位，不指名）
4. ✅ **一次支持说多个平台**；只返回有插件（支持）的平台；未配令牌返回「如何配置」指引
5. ✅ **发布前二次确认**；重复同步提示「已存在」询问是否覆盖更新
6. 待定：slug/name/version 从 SKILL.md frontmatter 提取的映射规则
7. 待定：GitHub/Gitee 插件实现（当前无凭据，按插件框架加目录即可）
