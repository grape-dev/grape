# skill-publish v4.2 实施缺口 + OBS 启用部署（2026-08-17 晚实测）

## 1. 撤回失败根因链（SRE 报 "Not logged in" 的真凶）

用户已配置 ClawHub 令牌（19:20 插库 clh_K3SFX5ljr...，admin/obs_mysql_user/xiaowu2119 三行共用），
但 SRE 撤回任务报 `Not logged in` / `401 Unauthorized`。逐层排查：

1. **服务端跑的代码不对**（最外层）：`_inject_platform_tokens` 只在特性分支（v4.2 实施），
   dev 分支无此函数 → env_extra 无 CLAWHUB_TOKEN。本次 22:50 服务被并行会话切到 dev 重启。
2. **令牌注入键 vs 令牌归属错配**（即使部署对也会失败）：
   `_inject_platform_tokens`（event_pipeline.py）按 **repo_key 的 owner**（`split_owner_repo` → `user_id=owner`）
   查 user_platform_tokens。fluxgate 仓库 owner = **signway**，但令牌配在
   admin/obs_mysql_user/xiaowu2119 名下 → `WHERE user_id='signway'` 无行 → 注入空串
   （日志 `platform tokens: owner 'signway' has no clawhub token, injected empty`）。
3. **v4.1 设计 vs v4.2 实现偏差**：v4.1 拍板「按执行用户注入」，v4.2 实现为「按仓库 owner」——
   设计文档与代码不一致，且 owner≠配置人时必然取不到。
4. **issue-advance/issue 技能没有「同步/撤回 → 交办 SRE」指引**（v4.2 只给 chat 技能加了）：
   Issue 入口的撤回请求由 Issue Agent 自己回帖处理。676 实测行为**正确**：
   Issue Agent 查历史知道 594 SRE 已报「凭证阻塞」，明确写「无需重复交办 A2A」，
   回帖给用户两个选项（提供 token / 手动下架）——**这不是 bug，是正常降级**。
   诊断时先看任务实际执行记录（journalctl grep task_id 的 text:/tool_use），别凭 env_extra 猜。

修复方向（未实施，待用户拍板）：
- 给 signway 插令牌行（`INSERT INTO user_platform_tokens (user_id, platform, token) VALUES ('signway','clawhub','clh_...')`）
  或
- 改 `_inject_platform_tokens` 按执行用户/配置人取（对齐 v4.1 设计）

## 2. 部署/重启后必须回验「服务进程实际跑的代码」

**坑**：systemctl restart 后，并行 Hermes 会话共享 /root/grape 工作区可能已把分支切走并再次重启服务——
你部署的特性分支被覆盖，服务实际跑 dev（无新功能），且**重启时刻看起来像你自己部署的**。

**回验三件套**（部署后必做，缺一不可）：
```
systemctl show -p ActiveEnterTimestamp --value grape-main   # 是不是你部署时刻
git reflog -3                                               # 期间有没有 checkout 切分支
git log --oneline -1                                        # 当前 HEAD 是否目标分支
ls -l /proc/$(systemctl show -p MainPID --value grape-main)/cwd
```
判别：ActiveEnterTimestamp 晚于你的重启时刻 + reflog 有 `checkout: moving from X to dev` = 被并行会话覆盖。
根治：git worktree 隔离（见 git-worktree-parallel-session.md）；临时：切回目标分支重启后立即回验。

## 3. A1 废弃后的死代码清理清单（删实现 → 顺带清配套）

v4.2「A1 彻底废弃 skill_sync_scene」删了 scene/sync_service/bind 建表/upsert_bind，
但**漏删两处配套死代码**（grep 无引用即死）：
- `src/plugins/` 整个目录（__init__/events/loader/security 306 行空壳框架）——v4.7 插件框架配套
  sync_service 已删，框架空转。已删（commit ec4718b6）。
- `src/im/handler_async.py:428` `_run_scene_async` 死函数（14 行）——scene 的同步→异步适配器，
  全文件无调用。待删。

**清理方法论**：删核心实现后，`grep -rn "<主题关键词>" src/ --include="*.py"` 逐条核对
每个命中是活代码（有调用链）还是死代码（仅定义/注释）——死代码一次性清掉，避免空壳误导。
数据库侧：`SHOW TABLES LIKE '<旧表>'` 确认存量表（v4.2 只删建表语句不自动删表，但本次
skill_sync_bind 已不存在，无需 DROP）。

## 4. OBS 启用部署配方（实测通过）

1. `/etc/grape/grape.env` 追加（systemd EnvironmentFile，双服务共享）：
```
OBS_ENABLED=true
OBS_ENDPOINT=https://obs.cn-north-4.myhuaweicloud.com
OBS_BUCKET=<桶名>
OBS_ACCESS_KEY=***
OBS_SECRET_KEY=***
OBS_PREFIX=grape
```
2. 重启前先用 SDK 验证凭据/桶连通（ObsStorage 方法名是 **save_bytes/read_bytes/exists/delete_object**，
   不是 put_bytes/get_bytes——命名与直觉不同）：
```python
os.environ.update(...)  # 同上 6 变量
from src.storage import get_storage, reset_storage
reset_storage(); s = get_storage()
s.save_bytes('grape/_probe.txt', b'ok'); s.read_bytes(...); s.exists(...); s.delete_object(...)
```
3. 重启后确认：`journalctl -u grape-main | grep StorageBackend` → `obs (bucket=..., prefix=...)`；
   或 `/proc/<pid>/environ | grep ^OBS_`（进程环境已注入）。
4. 本次遇 metadata lock（旧进程僵尸事务）→ KILL 后迁移跑完，双服务 health ok。
