# codegraph / project-info 修复（2026-08-18 实测）

## npm 包名陷阱（关键）
- `npm install -g codegraph` 装的是**空壳占位包**（1.0.0：package.json 无 bin 字段、files 指向不存在的 dist/）——装完 `codegraph: command not found`；历史 project-info note 曾记 "broken install, no dist/" 即此。
- 真包 = **`npm install -g @colbymchenry/codegraph`**（1.5.0，bin=codegraph → npm-shim.js，github.com/colbymchenry/codegraph）。
- 仓库内 `skills/repo-onboarding/references/codegraph-commands.md` 与 `codegraph-project-analysis.md` 的安装命令仍是错的（`npm install -g codegraph`），2026-08-18 已建议用户修正，未确认前勿再照抄。
- 验证：`codegraph --version` → 1.5.0；`codegraph init` + `codegraph files --format tree` 实测 aarch64 正常（小仓 1.9s）。

## WORKSPACE_DIR 解析（config.py _resolve_workspace_dir）
- 优先级：DEVOPS_WORKSPACE_DIR env → `~/grape-workspaces`（root 用户 = **/root/grape-workspaces**）→ data/workspaces 兜底（仅无家目录系统服务场景）。
- **project-info 实际在 /root/grape-workspaces/{owner}/{repo}/project-info/**；/root/grape/data/workspaces/ 下同名路径是 8-15 迁移前残留——按旧路径查 codebase/project-info 会误判不存在/看旧数据。

## 仓库 clone 权限链（get_gitcode_token，src/user/db.py）
- 优先级：① devops_agent_session.repo_gitcode_token → ② managed_repos.bot_gitcode_token → ③ 全局 bot token（global-bot-token.json）。
- **managed_repos.bot_gitcode_token 为空 → 落全局 bot token，可能无权读该仓库**：ensure_repo_base 的 git fetch 报 `CH.00905404 can not read project. user: <bot身份>` / 403（git 凭据经 `-c http.extraheader=Authorization: Basic base64...EN)` 注入，见 repogit._run_git）。
- 修：`UPDATE managed_repos SET bot_gitcode_token=*** WHERE repo_key='gitcod...epo>'`（用户提供的仓库级 token；只影响该仓库读取，不动全局 bot）。
- 先验证 token 可读：GitCode API `GET /api/v5/repos/{owner}/{repo}`，header `Authorization: Bearer ***

## 重新生成 recipe（服务端 builder）
```python
from src.project_info.builder import build_project_info, _read_meta
r = build_project_info('gitcode:owner/repo')   # 后台跑；首次 clone mirror + codegraph init 分钟级
print(r)  # {'ok': True, 'degraded': False, 'reason': 'codegraph'} 为成功
meta = _read_meta('gitcode:owner/repo')        # degraded=False、note 空 = 非降级
```
- 配套修复已就位：`_ensure_analysis_worktree` 128-135 行 codebase 缺失时主动 `ensure_repo_base`（docs 定案），无需再改。
- 陷阱：bare mirror fetch 可能"看似成功但 refs 空"（worktree add 报 `invalid reference: origin/master`）——手动 `git --git-dir=<base> fetch --prune origin "+refs/heads/*:refs/remotes/origin/*"`（带 token extraheader）补齐后再跑。
- `codegraph explore` 输出 "No relevant code found for ..." = 索引 OK 但查询未命中（shelldev 实测），仍 degraded=False，看板显示非降级文案。
- 批量盘点降级仓库：`glob /root/grape-workspaces/*/*/project-info/.metadata.json` 读 degraded 字段。

## 遗留（2026-08-18 会话结束，待用户确认）
- 5 台 worker 未装 codegraph——worker 侧执行 repo-onboarding 技能时同样降级。
- test_tmpl/hello-skill GitCode 403 "project not found"（仓库不存在/私有，非环境问题）。
- repo-onboarding 技能文档安装命令修正（npm → @colbymchenry/codegraph）。
