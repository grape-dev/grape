# Pipeline 停在某 agent 阶段 ≠ 卡死：先查 stage 回退（agent 失败后的正确状态）

## 场景（2026-08-14 实测，wdmike/redbook-operate issue #1）
用户报障："GitCode issue 界面显示已 A2A 交给 SRE agent 闭环发布，但 grape 系统 pipeline 还停在 issue agent 流程"。

## 结论
**不是卡死，是 SRE 发布任务真实失败后 issue agent 回收并回退 stage**。pipeline 的 stage 列取自 `issue_state.stage`，回退后自然显示"停在 issue"——这是正确失败态，不是僵尸、不是显示 bug。

## 证据链（本次实测）
- `events` seq 229：`a2a_event` agent_type=sre，status=failed，result=`task timed out after 600.0s`
- `agent_tasks` t_0047ea805351：status=failed、exit_code=1、errors=`["task timed out after 600.0s"]`、started 03:10:24 → completed 03:20:27（**恰好整 600s = 硬超时被杀**）
- `events` seq 230（11:20:34）：a2a_event agent_type=issue completed，payload.context 含 SRE 失败总结——热搜Top20/选题(胖东来闭店)/4张配图/标题均已完成，但 **CDP 9222 已登录会话在执行机不存在**（无 Chrome 进程、无 Cookie、发布页 401 重定向登录页），建议等用户提供环境后重触发
- `issue_state` id=29：stage 从 sre（11:10:15）→ **issue（11:20:34，与 seq 230 同时刻）** = 回退证据

## 根因模式：环境声明与事实不符
用户评论声称"已登录 creator.xiaohongshu.com + Chrome CDP 9222 就绪"，VOD/issue agent **未做环境校验**直接评级升级 ready 并 A2A 派发 SRE；SRE 真正执行时发现执行机上没有该环境 → 内容准备全做完、卡死在发布环节空转 → 撞 600s 硬超时。教训：依赖外部真实环境（登录会话/CDP/凭据）的任务，派发前应校验环境，或至少让 SRE 快速失败而不是空转到超时。

## 判别三步（"pipeline 停在某阶段"时先走这个，再下卡死结论）
1. `events` 按 repo_key+issue_id 查各 agent 最新事件状态——找 failed 而非 running
2. `agent_tasks` 按 event_seq 查 errors：`task timed out after 600.0s` = 硬超时；started/completed 差整 600s 佐证
3. 看失败 agent 之后的下一事件（payload.context）或 GitCode 回写评论拿失败原因；对比 issue_state.updated_at 与回退时刻

## 与僵尸模式的区分（别混淆）
- 僵尸（本机没干活）：events 全 running 无 completed_at + agent_tasks 全 queued attempts=0 从未 claim + 日志无 claim 记录 → 见 event-stuck-running-diagnosis.md / dual-webhook-instance-diagnosis.md
- 本次（真失败）：events failed 有 completed 时间 + agent_tasks failed 有 errors + 日志有完整 step 执行 → 是真实执行后失败

## Schema 坑（本次踩过，省下次三条报错）
- `events` 列名是 `agent_type`（无 `agent` 列）、无 `issue_number` 列
- `agent_tasks` 错误列是 `errors`（无 `error` 列）
- `issue_state` 无 `status` 列（列：id/repo_key/issue_id/stage/assignee/updated_at）
- pymysql DictCursor 下 fetchall 行**已是 dict**，别再 `dict(zip(cols, row))` 二次转换——会把值全变成列名，静默产出假数据
