# Chat 配置被启动逻辑重置 → 「未配置远端引擎」（2026-08-18）

## 症状
Chat Agent 对话返回「⚠️ 未配置远端引擎，任务会话需先在 Agent 配置中绑定远端引擎」SSE done，任务不执行。

## 根因链
1. chat 配置行 `chat_agent_session`（id 格式 `sess-cfg-{user_id}`；gitcode 入口另有 `sess-gitcode:{repo}:{ts}` 行）runtime_id 指向**本机直连行**（agent_runtimes.credential_id=*** runtime 1）。
2. send_stream（src/api/routes/chat.py ~328-349）**直接读配置行 rid**（`cfg.get("runtime_id") or 0`），不重新解析；queue_remote 强制模式下 `runtime_execution_kind(rid)` 不看 credential_id 直接返回 queue_remote → 入队分支 `runtime_credential_id(rid)==0` → 拦截。rid=0 同拦（None or 0==0）。_enqueue_chat（~534 行）同款。
3. **真正元凶**：`src/api/db_setup.py _cleanup_chat_shared_worker_runtime()`（启动时执行，~710 行）把「指向共享全局 worker（scope='global' AND credential_id>0）」的 chat 配置行**回落为本机直连行**（同名 credential_id=0 行）——direct 时代防 backend 名解析被共享 worker 劫持的方案 C（chat-agent-backend-resolution-fix.md）。queue_remote 下本机直连行无 claim 方=黑洞，回落=每次重启把用户配置重置为死引擎。**这是 2026-08-17 晚「sess-cfg-2/3/4/15 改绑 58」全部失效、全表 sess-cfg-* 恒为 1 的真相**（技能里「改绑后回验」的教训在这是「改绑会被启动逻辑覆盖」）。
4. 用户映射：user_accounts.username ↔ id（songspace=4）。

## 修复（2026-08-18，本地已验证，待确认提交）
1. 数据层（只改报障用户的行，勿批量扩范围）：
   `UPDATE chat_agent_session SET runtime_id=<在线引擎id> WHERE id='sess-cfg-4' AND runtime_id=1`
2. chat.py send_stream + _enqueue_chat 拦截前加兜底（解析不到才真拦截）：
   ```python
   if (runtime_credential_id(rid) or 0) == 0 and backend_name:
       from src.session_manager import _resolve_chat_runtime_id
       _rid2 = _resolve_chat_runtime_id(backend_name) or 0
       if _rid2:
           rid = _rid2
           kind = runtime_execution_kind(rid)   # send_stream 里需重算 kind
   ```
3. db_setup.py `_cleanup_chat_shared_worker_runtime()` 函数开头：
   ```python
   from src.runtime.service import get_execution_mode, EXEC_MODE_REMOTE
   if get_execution_mode() == EXEC_MODE_REMOTE:
       return
   ```
   direct 模式保留原防劫持语义。

## 验证
- `_resolve_chat_runtime_id('opencode')` → 在线引擎（54/58/66 之一，credential>0）；旧 rid=1 兜底后不再拦截
- 重启双服务后 sess-cfg-4 保持改绑值（不被重置）；journalctl 无 `chat config worker->local direct` 记录
- pytest：test_chat_backend_resolution/test_chat_cwd/test_chat_task_scene/test_feishu_chat_unified 41 passed；verify 快速子集 175 passed

## 表结构备忘
- chat_agent_session 列：id/user_id/repo_key/source/repository/status/runtime/skill/im_provider/im_app_id/im_app_secret/event_history/created_at/last_active_at/runtime_session_id/runtime_id/skill_id
- events 列：seq/repo_key/event_type/source/**issue_id（非 issue_num）**/title/summary/actor/payload/agent_type/runtime/skill/status/exit_code/duration/agent_logs/result/created_at/started_at/completed_at（**无 updated_at**）
- agent_tasks 错误列是 errors 非 error；按 event_seq 关联 events
