# Worker 422 死循环：`_reregister` 元组未解包 bug（2026-08-17 实测）

## 症状
- 批量 revoke 凭据恢复（`UPDATE runtime_credentials SET status='active'`）后，worker 仍不可用
- nginx/journalctl 状态码：401（revoke 期）→ **422**（revoke 恢复后仍不可用）
- 422 响应体是 FastAPI 校验错误：`{"detail":[{"type":"int_type","loc":["body","runtime_ids",0],"msg":"Input should be a valid integer","input":[54,55]}]}` 或 `{"loc":["path","runtime_id"],"msg":"Input should be a valid integer","input":"[54, 55]"}`
- agent_runtimes 已重新注册成功（register 200），但 claim/heartbeat/recover-orphans 全 422

## 铁证日志（worker journal）
```
re-registered successfully, new runtime ids: ([54, 55], '')   ← 元组形态！
```
正常应为 `new runtime ids: [54, 55]`（纯列表）。

## 根因
`src/runtime/agent.py` 的 `_reregister`（dev 59bcfd28 与合并后 4a435ba6 都有）：
```python
ids = await client.register(installed, device_name=device_name)   # ← BUG：未解包
```
而 `RuntimeClient.register()` 返回 `(ids, probe_url)` 元组：
```python
async def register(self, runtimes, device_name="", cli_version="") -> tuple[list[int], str]:
    ...
    return ids, (data.get("probe_url") or "")
```
→ `ids = ([54, 55], '')`：
- `for rid in ids` → rid = `[54, 55]`（列表）→ `recover_orphans([54, 55])` → URL `/runtimes/[54, 55]/recover-orphans` → 422
- `return ids` 把元组交给 `_run_loop` → `client.claim(rid)` 里 rid 是列表 → 422；`client.heartbeat(runtime_ids)` body 嵌套 → 422
- 每次 422 → heartbeat 失败计数 → 再次 re-register → 再次元组 → 死循环

**为什么首次注册正常**：正常启动走 `main()` 里 `ids, probe_url = await client.register(...)`（正确解包）。`_reregister` 只在「心跳失败 ≥3 次」或「每 RE_REGISTER_INTERVAL=300s」触发——revoke 事件让心跳 401 连败，恰好引爆该路径。

## 修复
```python
# src/runtime/agent.py _reregister
ids, _probe = await client.register(installed, device_name=device_name)
```

## 判定链（从症状到根因）
1. `grep "re-registered successfully" <worker journal>` → 看到 `([54, 55], '')` 元组形态即确诊
2. 对照服务端 register 返回结构：`curl -X POST -H "Authorization: Bearer ***" -H 'Content-Type: application/json' -d '{"device_name":"t","cli_version":"t","runtimes":[{"name":"opencode","version":"t","healthy":true,"installed":true,"cli_path":"/tmp/x"}]}' https://grape-dev.topxtopx.com/api/runtime/register` → 返回 `{"runtimes":[{"id":54,...}]}` 单值 id，确认服务端没问题，问题在 worker 端解析
3. 检查 worker 端 client.py `register()` 返回签名（`-> tuple[list[int], str]`）与 `_reregister` 调用是否匹配

## 相关坑
- 状态码语义速查：**401** = 凭据 revoked/不匹配（先查管理台批量注销，见 worker-credentials-bulk-revoked.md）；**422** = 协议/格式不匹配（本 bug）；**502** = 服务重启/MySQL 迁移中（等几秒）。
- worker 安装包从服务端磁盘代码打包：服务端 checkout 在 merge-test/未提交分支时下发的包是半成品（见 SKILL.md Worker 安装包节）。
