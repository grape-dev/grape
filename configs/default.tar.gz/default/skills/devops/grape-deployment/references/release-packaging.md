# Grape 发布包制作 + OBS 上传 (grape-system / grape-tools)

## 包名规则
- `grape-system-<YYYYMMDDHHMM>.tar`(12 位时间戳, 如 202607220953 = 2026-07-22 09:53): 运营管理台系统(前后端安装包 + 数据库包)
- `grape-tools-<YYYYMMDDHHMM>.tar`: grape 及工具单独包(gitcode 事件处理 + 开发/SRE 分发 skills + 相关工具)
- 两个包都上传同一桶 `obs://obs-grape-release/release/`, 都含 agent 可读 INSTALL.md, 生产 hermes 解包后读 MD 自动安装。

## 工具与运行
- 脚本: `/root/deploy/release_pack.py`(本机无 mysqldump, 依赖 pymysql → 用 grape venv 的 python 跑)
- 运行: `/root/grape/.venv/bin/python /root/deploy/release_pack.py --kind system|tools|all [--ts 202607220953] [--full] [--skip-upload] [--out DIR] [--bucket ...] [--prefix ...]`
- `--kind all` 一次出两个包;产物 `/root/release/grape-system-<ts>.tar` + `/root/release/grape-tools-<ts>.tar`;`--skip-upload` 只打包不上传。
- 已验证: 2026-08-12 `--kind all --ts 202607220953 --skip-upload` 跑通, SHA256SUMS 校验全 OK, 自检通过。

## grape-system tar 内部结构
```
grape-system-<ts>.tar
├── INSTALL.md          # agent 可读安装指南(包根, 生产 hermes 解包后第一个读它)
├── SHA256SUMS          # 相对路径(event/xxx 这种带子目录前缀), 在包根 sha256sum -c 直接可验
├── backend/grape-backend-<ts>.tar.gz     # src/ + requirements*.txt + templates/(systemd) + scripts/ + configs/ + start_server.py + Dockerfile + docker-compose.yml + README
├── frontend/grape-frontend-<ts>.tar.gz   # src/api/static/ 全部静态资源
└── database/grape-db-<ts>.sql.gz         # 全表 CREATE TABLE + 种子表数据
```

## grape-tools tar 内部结构
```
grape-tools-<ts>.tar
├── INSTALL.md          # agent 可读安装指南(假定 grape-system 已装于 /root/grape, 本包只补事件/技能/工具)
├── SHA256SUMS
├── event/grape-event-<ts>.tar.gz         # gitcode 事件处理: event_pipeline/event_store/event_archive/routing/run_webhook/onboarding + routes/events,pipeline,webhook + 种子配置(agent/skill 字典 json)
├── skills/grape-skills-<ts>.tar.gz       # 开发/SRE 分发技能库: skills/ 全量官方技能(issue/pr/qa/implementation/build-debug/deploy-guard/incident-triage/changelog-gen/cloud-deploy/im-notify/chat/vod/repo-onboarding/skill-pr/_template), 排除 custom/(运行时用户上传, 不进发布包)
└── tools/grape-toolkit-<ts>.tar.gz       # 相关工具: src/runtime(worker 执行器) + scripts/install-worker.sh + requirements-worker.txt + examples/hello-skill + docs/(gitcode-api-guidance/codearts-cli-guide/feishu-agent-auto-config)
```
- toolkit 打包后二次过滤掉 `__pycache__`/`*.pyc`(验证时发现 src/runtime 带 pycache)。

## 关键设计决策(踩过的点)
1. **前端是纯静态、由 grape-main 直接托管** → 前端包 = static/ 目录, 无需 npm build。
2. **configs 只留 example + 种子 json**: 保留 `*.example.json` + `agent-description.json` / `skill-description.json` / `agent-skill-mapping.json`;剔除真实凭据(`db-backend.json`/`global-bot-token.json`/`login-whitelist.json` 均 gitignored 真实配置, 绝不能进发布包)。
3. **数据库包默认"结构+种子"**: 种子表白名单 = `admin_users` / `admin_roles` / `admin_permission_menus` / `admin_role_menu_rel` / `agent_type` / `skill` / `event_route_config` / `global_im_bot_config`。
4. **机密表永不导出**: `user_accounts`(含 gitcode token)、`user_credentials`、`runtime_credentials`、`managed_repos`(含 webhook token)、`oauth_states` 等;`--full` 也只加导出非机密非运行时表, 仍跳过 events/chat/tasks/agent_tasks 等运行时大表。
5. **admin_* 表由 flyway 迁移创建、迁移 SQL 不在仓库里** → 全新安装必须靠数据库包带 DDL + 种子, 否则管理台没表可查(仓库代码里搜不到 admin_users 的 CREATE)。
6. **无 mysqldump 二进制** → 脚本用 pymysql `SHOW CREATE TABLE` + `SELECT *` 生成 .sql 再 gzip;INSERT 值做 `'` 转义。
7. **INSTALL.md 由脚本生成**(git describe 版本号动态填充), 10 节: 包信息/包内容/解包校验/环境要求/后端安装/数据库初始化/三件套配置/裸跑验证/systemd/验证矩阵/已知坑。每步 = 完整 bash 块 + 验证命令 + 期望输出(如 /health 返回 {"status":"ok"}), 已知坑内嵌处置命令(meta.webhook_url UPDATE、events 僵尸清理)—— 生产 hermes 逐条执行即可完成安装。
8. **f-string 花括号坑**: INSTALL.md 模板里写 `{"status":"ok"}` 这类字面 JSON 必须写成 `{{"status":"ok"}}`, 否则 ValueError: Invalid format specifier。
9. **SHA256SUMS 必须写相对路径**(backend/xxx、event/xxx 带子目录前缀), 否则 `sha256sum -c` 在包根找不到文件(已修)。
10. **tools 包的 INSTALL.md 假设前置**: grape-system 已安装于 /root/grape, 事件模块 rsync 覆盖合并 + 重启 webhook;skills 并入 /root/grape/skills/;worker 工具用 install-worker.sh。已知坑含 worker 3 秒 401(runtime.env 缺 HERMES_CUSTOM_API_DEEPSEEK_COM_API_KEY)。

## OBS 上传
- 桶: `obs://obs-grape-release/release/`;公网地址 `https://obs-grape-release.obs.cn-north-4.myhuaweicloud.com/release/grape-system-<ts>.tar`(tools 同理)
- 工具: obsutil(本机未装时脚本自动下载 aarch64 版到 /usr/local/bin/obsutil)
- 凭据优先级: env `OBS_AK`/`OBS_SK` > `~/.obsutilconfig`(ini, AccessKeyId/SecretAccessKey) > 交互输入
- 桶是私有的(匿名 403): 上传必须有 AK/SK;生产 hermes 下载同样需公网可读策略或凭据。

## 现场状态(2026-08-14)
- OBS 凭据已配置: `~/.obsutilconfig`(obsutil 加密存储, 用户提供的 es_workload_vod_menglingchuang 子账号 AK/SK), 本机 obsutil 已装 /usr/local/bin/obsutil, endpoint obs.cn-north-4。
- 测试包已上传 **test/ 前缀**(不是 release/): `obs://obs-grape-release/test/grape-system-202607220953.tar`(5.26MB) + `grape-tools-202607220953.tar`(270KB), obsutil ls 确认 2 个对象, INSTALL.md 内下载地址指向 test/。桶私有(匿名 403), 生产 hermes 下载需凭据或放开读策略。
- ⚠️ 两个坑(2026-08-12 实测): ① `--prefix` 曾被模块级全局变量遮蔽(去掉 global 后赋值变局部, upload 仍用默认 release) → 已改为 bucket/prefix 全程参数传递; ② **upload 里不能每次重跑 `obsutil config`** —— obsutil 会把凭据加密写进 ~/.obsutilconfig, 脚本第二次读到加密串再 config 就污染凭据 → 403 InvalidAccessKeyId, 现仅当配置文件缺失才 config 一次。
- **首次正式发布完成(2026-08-14, system 包)**: `grape-system-202608141617.tar`(5.51MB, 代码 b3cad23f) 已上传 `obs://obs-grape-release/release/`。**老包一律保留不删**——桶内 release/ 现 3 包: grape-admin-202608131731.tar(另一实例打的 admin 包) + grape-system-202608132058.tar + 新包。流程: 打测试包 --skip-upload → 解包 sha256sum -c 全 OK + 抽查内容 → obsutil cp 上传(status 200)。**验收抽查要点**: examples 模板画廊在 **backend 包内**(tar tzf backend | grep examples/ 有 7 个 hello-* 目录, 不在 frontend 包, 别在 frontend 里找); 前端包 11 个页面 js(agents/chat/dashboard/events/pipeline/repos/runtimes/settings/skills/tasks/templates); 数据库包 zcat 抽查 DDL+种子。用户给的新 AK/SK 与 ~/.obsutilconfig 既有凭据一致, 上传直接可用无需再配。

## 工作流偏好(用户纠正, 2026-08-12)
用户问"这个怎么做/如何打包"这类问题时:**先讲清打包方案再执行** —— 包结构、每个子包装什么、INSTALL.md 怎么做到 agent 可读、凭据缺口。写好脚本正要跑时被用户打断("你先说一下你是如何打包的"), 说明方案说明本身就是用户要的交付物, 不要直接执行。
