# CDP 9222 发布环境：执行机映射 + 正确姿势（2026-08-14 wdmike/redbook-operate #1 实测）

> 判别"pipeline 停在某阶段是不是卡死"（stage 回退 vs 僵尸）见 `agent-failure-stage-rollback.md`。
> 本文件讲：发布类任务（小红书/浏览器自动化）的 CDP 9222 环境到底要配在哪台机器、怎么配。

## 核心事实：发布脚本硬编码 127.0.0.1:9222，Chrome 必须开在 agent 执行机
- redbook-operate 仓库 xiaohongshu_workflow/scripts/ 的发布脚本（publish_note.py / set_cookies_and_publish.py / try_login.py）**全部硬编码 `http://127.0.0.1:9222/json`** 拿标签页 + webSocketDebuggerUrl。
- 结论：**Chrome 必须在 agent 实际执行任务的那台机器上开**。用户在**自己电脑**浏览器登录的 creator.xiaohongshu.com 与 worker 无关——"已登录"声明若指的是用户本地浏览器，SRE 执行时必然 401。

## 执行机映射（本仓库 SRE/发布任务跑在哪）
- 本次 SRE 任务 runtime_id=17 → agent_runtimes.credential_id=8 → runtime_credentials `vod-worker1` / device_name=worker-ecs-grape-dev-build-0002（192.168.0.115，root/kaifazhe@123）。
- 查执行机映射：`runtime_credentials.last_ip`（**无 host 列**）。查询 SQL 用 `%s` 参数化 + DictCursor（行已是 dict，勿二次 zip）。
- 本机 sshpass 连 worker 曾 Permission denied（华为云 OpenSSH 禁密码），改用 `/root/deploy/venv/bin/python` + paramiko 脚本连（deploy.py 同款模式）。
- worker-0002 已装 playwright chromium：`/root/.cache/ms-playwright/chromium-1234/chrome-linux/chrome`（aarch64）；websocket-client 库已装。

## SRE 失败现场（本次实测，验证用）
- SRE 超时前 1 分钟（11:17）agent 自己起了 Chrome：`--headless=new --no-sandbox --disable-gpu --remote-debugging-port=9222 --remote-allow-origins=* --user-data-dir=/tmp/chrome-cdp-profile --window-size=1440,900 about:blank`
- 三个致命问题：① headless 无头模式；② `--user-data-dir=/tmp/...` 临时目录，重启即丢登录态；③ 当前标签 `creator.xiaohongshu.com/login?redirectReason=401` = 未登录被弹回。
- 配图已生成（/root/image/hot_1~4.jpg）、依赖已装，只差登录态。

## CDP 9222 正确姿势（给用户的方案）
1. Chrome 必须开在执行机（worker-0002），用**持久 profile**：`--user-data-dir=/root/chrome-profile`（勿用 /tmp 临时目录）。
2. 启动参数（实测可用模板）：`--headless=new --no-sandbox --disable-gpu --remote-debugging-port=9222 --remote-allow-origins=* about:blank`。
3. 登录三选一：
   - A（最快）：用户自己浏览器登录 creator.xiaohongshu.com → EditThisCookie 扩展或 F12 Application 导出 xiaohongshu.com 域全部 cookie（name/value/domain/path）→ 填 set_cookies_and_publish.py 的 COOKIES 数组（脚本有模板）→ 注入后发布。
   - B：try_login.py 手机号+验证码登录。
   - C（最稳防风控）：Xvfb + VNC 起**有头** Chrome 开 9222，人工扫码/短信登录一次，之后 agent 直接复用。
4. 验证：`curl http://127.0.0.1:9222/json` 看标签；导航 creator 发布页不再跳 `login?redirectReason=401`。
5. 坑：headless 登录可能触发滑块/风控（不行上方案 C）；cookie 有有效期，过期重导。

## 配套
- 判别"真失败 vs 僵尸"、Schema 坑（events.agent_type / agent_tasks.errors / issue_state 无 status / DictCursor 二次 zip）见 `agent-failure-stage-rollback.md`。
