# 前端占位符回显 → 静默覆盖真实凭据（issue #72，2026-08-17）

## 症状（生产环境实测）
- 托管仓库部署任务连续失败，注入的 HUAWEICLOUD_SDK_AK/SK 是占位符（`AK-demo-access-key-xxxx`），华为云 IAM 401 `APIGW.0301`，无法获取项目 ID
- 用户确认"已配置"，但库里实际是占位符 → 配置了但不生效的困惑

## 根因链
1. 前端 `src/api/static/js/pages/settings.js`（credentials 页）：已配置时输入框 `value` 回显占位符
   ```js
   value="${d.huawei_cloud && d.huawei_cloud.ak_exists ? 'AK-demo-access-key-xxxx' : ''}"
   ```
2. 保存时把输入框当前值（= 占位符）原样提交
   ```js
   huawei_cloud_ak: ak && ak.value ? ak.value : undefined,
   ```
3. 后端 `src/api/routes/settings.py` update_credentials 无校验：`if body.huawei_cloud_ak: acc[...] = body.huawei_cloud_ak` 非空即写
4. 用户打开设置页 → 看到占位符 → 直接点 Save → 占位符覆盖真实 AK/SK

## 同类模式（必须一并检查）
settings.js 里 **GitCode Bot Token 也是同样炸弹**：`value="${d.devops_bot_token_exists ? 'ghp_devopsbot_xxxxxxxxxxxxxxxxxxxx' : ''}"` → saveGitcodeRepoConfig 提交占位符覆盖 managed_repos.bot_gitcode_token。
排查命令：`grep -rn 'demo-\|xxxx\|value="${.*exists' src/api/static/js/`

## 修复（2026-08-17 已实施）
前端（settings.js）：
- 已配置 → `value=""` + placeholder「已配置，留空保持不变」+ 绿色「✓ 已配置」标记
- 保存时 `_isCredPlaceholder(v)` 过滤：空 / 精确占位符 / `^(AK-demo-|SK-demo-|ghp_devopsbot_)` 前缀 → 不提交
后端（settings.py）：
- `_is_placeholder(v)`：空 / 在占位符集合 / demo 前缀 / 含 `xxxx` → 拒绝写入
- `update_credentials` 四个字段（huawei_cloud_ak/sk + CODEARTS_CLI_AK/SK）与 `update_gitcode_repo_config` 的 bot_token 都拦
- 前端过滤是首选（用户输入层面拦），后端是兜底（防旧缓存前端/直接调 API）

## 数据清理
- `user_accounts.huawei_cloud_ak/sk`、`CODEARTS_CLI_AK/SK`、`managed_repos.bot_gitcode_token` 若为占位符 → 置 NULL
- 2026-08-17 实测当前库已无污染（真实 AK `HPUAVPXQMKH0WSTMTHDH` 在库，占位符被后续保存覆盖）——清理脚本幂等，跑了无事

## 验证
- `node --check src/api/static/js/pages/settings.js`
- `_is_placeholder` 单测 7 用例（占位符→True，真实 key→False，空→True）
- 服务重启后 `curl /static/js/pages/settings.js` 200 + `/health` ok

## 打包保障
- release_pack.py 代码源：frontend 包 = `src/api/static/`（含 settings.js）、backend 包 = `src/`（含 settings.py 路由）→ **源码修复后重新打包即包含**，无需改打包脚本
- 发布前检查清单：打包后 `tar tzf` 抽查 settings.js 是否含 `AK-demo-access-key-xxxx`（不应有 value 回显，只允许出现在 _isCredPlaceholder 过滤逻辑里）
