# Dashboard "无 engine，不可用" + 配置引擎落到吊销旧行（2026-08-17 实测）

## 症状与显示链路
- 前端 dashboard.js 每张 Agent 卡片 Backend 显示红字「无 engine，不可用」 ⇔ `ag.backend` 为空
- 后端 dashboard.py：
  `SELECT s.agent_type, r.name ... FROM devops_agent_session s LEFT JOIN agent_runtimes r ON s.runtime_id=r.id WHERE s.repo_key=***
  → backend = r.name；runtime_id=0 或指向已不存在的行 → NULL → 前端红字
- ⚠️ dashboard 的 JOIN **不查凭据状态**：revoked 凭据的旧 agent_runtimes 行仍能 JOIN 出 name → 显示引擎名但引擎实际已吊销（"假健康"，任务 claim/执行 401）

## 为什么「今天才显形」——前端兜底被删
- 部署前 dashboard.js：`const backend = ag.backend || meta.default_backend || 'opencode';` → 空 backend 假装显示 opencode
- 部署后：`ag.backend || ''` + 空则红字；后端 dashboard.py 同步把字段名 runtime→backend 对齐（HEAD 版本字段名与前端都对不上，全靠兜底才显示得出来）
- 结论：红字 = 会话**从未绑定引擎**（runtime_id=0），08-13 创建的一批会话如此，之前被兜底掩盖；不是新部署把引擎弄坏了

## 版本错位诊断法（部署 vs 运行进程）
- 静态文件（js/css/html）实时生效（uvicorn StaticFiles 读磁盘）；Python 代码要重启进程才生效
- 服务 08-14 启动但代码 08-17 部署 → 进程旧代码 + 前端新代码并存，行为不一致
- 判定：`stat -c '%y' src/api/static/js/pages/dashboard.js`（文件 mtime=部署时刻）vs `systemctl show grape-main --property=ExecMainStartTimestamp`（进程启动时刻）

## 核心 Bug：实例名撞车 + resolve_instance_id 命中吊销旧行
- instance_name = `{type}-{sanitize_device(device_name, 24)}`（instances.py）；sanitize 小写/非字母数字转 '-'/截 24
- `worker-ecs-grape-dev-build-0002..0006` 截 24 后**全是** `worker-ecs-grape-dev-bui` → 新旧行实例名全部撞车（实测 `hermes-...-bui` 撞 8 行、`opencode-...-bui` 撞 7 行，含 revoked 旧行 + active 新行）
- resolve_instance_id（instances.py）逐行重算派生名精确匹配：**无 ORDER BY、不过滤 revoked/offline** → MySQL 主键序第一个命中旧行（id 小 = 旧行）
- 实测：`resolve('hermes-worker-ecs-grape-dev-bui')` → 18（credential 8 revoked）、`resolve('opencode-...-bui')` → 17（revoked）
- 完整断点链：agents.js 下拉 checkbox value = `r.instance_name || r.name` → 用户勾选新引擎保存 → agents.py 先 `resolve_instance_id(bn)` 命中旧行 → set_binding/upsert_agent_session 写旧行 runtime_id → dashboard 显示旧行名（看似配置成功）→ 实际凭据已吊销
- get_runtime_id_by_name（user/db.py）有 `ORDER BY online 优先, last_seen_at DESC` 但**同样不过滤 revoked**——不过实例名路径根本不走它（先 resolve 命中就返回了）

## 当前数据状态（修复前快照）
- 10:42 批量 revoke 10 凭据 → 10:45 部署代码 → 11:26 backfill_existing_bindings（meta `bindings_backfilled`=1）把存量 session runtime_id>0 回填 binding 表（94 行），**全是旧行**（13/15/17/18/20/21/23/5/11/1）
- 5 台 worker 重新注册新凭据 → agent_runtimes 新行 52-61（active/online），**无任何会话绑定**
- 会话绑定集合 = {1,5,11,13,15,17,20,21,23}；其中 11 是已不存在的行（JOIN 失败同样显示无 engine，统计 SQL 按 runtime_id=0 会漏掉这类）

## 修复方向（2026-08-17 提议，待用户确认未实施）
1. resolve_instance_id：JOIN runtime_credentials 过滤 status='active'，撞车时 active 优先
2. get_runtime_id_by_name 同样过滤 revoked 凭据
3. instance_name 撞车根治：device 截断改「保头保尾」或 instance_name 带 credential_id 后缀（保证唯一）
4. 存量迁移：binding + session 从旧行 13/15/17/18/20/21/23/5/11/1 重绑到新行 52-61

## 复用排查配方
- 哪些仓库显示红字（注意 runtime_id=0 统计会漏掉指向已删行的会话）：
  `SELECT s.repo_key, SUM(s.runtime_id=0) unbound, COUNT(*) total FROM devops_agent_session s WHERE agent_type IN ('vod','issue','coding','qa','sre') GROUP BY s.repo_key HAVING unbound>0`
- 撞车清单（派生实例名分组看重复）：
  `SELECT ar.id, ar.name, ar.credential_id, rc.device_name, rc.status FROM agent_runtimes ar LEFT JOIN runtime_credentials rc ON rc.id=ar.credential_id WHERE ar.scope='global' ORDER BY ar.id`
- session vs binding 一致性：
  `SELECT s.repo_key, s.agent_type, s.runtime_id, (SELECT b.runtime_id FROM devops_agent_runtime_binding b WHERE b.repo_key=REPLAC...,'') AND b.agent_type=s.agent_type ORDER BY b.priority, b.runtime_id LIMIT 1) FROM devops_agent_session s WHERE s.agent_type IN ('vod','issue','coding','qa','sre')`（binding 表 repo_key **不带** gitcode: 前缀，session 表带）
