# Worker 全离线事故 2026-08-17（_reregister 元组未解包 + revoke 引信）

## 一句话根因
OBS 需求提交 e5c09544 把 `client.register()` 返回签名从 `list[int]` 改为 `tuple[list[int], str]`（新增 probe_url），
只改了 main() 调用点（`ids, probe_url = await client.register(...)`），**漏改 `_reregister` 调用点**
（`ids = await client.register(...)`）→ 重注册时 `ids` 拿到整个元组 → 全链路 422。

## 事故时间线（2026-08-17）
- 10:42 有人在管理台（Workers 页）批量 revoke 全部 runtime 凭据（nginx 有逐条 `POST /api/settings/runtime-credentials/{id}/revoke`，间隔 2-3s + 每次跟 `agent-runtimes/refresh`，IP 116.205.147.11 浏览器会话）
- worker 心跳 200→401（revoke 生效）→ 心跳失败 streak≥3 触发 `_reregister` → 元组 bug 爆发
- 之后每次 re-register 都把 runtime_ids 变元组 → claim/heartbeat 全 422 死循环 → 5 台 worker 全部"离线"

## 症状特征（判别用）
- worker 日志：`re-registered successfully, new runtime ids: ([54, 55], '')` ← 元组！正常应为 `[54, 55]`
- nginx/服务端日志：`POST /api/runtime/runtimes/%5B54,%2055%5D/tasks/claim` → 422（URL 里是 URL 编码的 [54, 55] 列表）
- heartbeat 422：`{"loc":["body","runtime_ids",0],"input":[54,55]}`（runtime_ids[0] 是列表）
- 恢复后正常形态：`/runtimes/54/tasks/claim` + `/runtimes/55/tasks/claim` 分开请求 200

## 修复
```python
# src/runtime/agent.py _reregister 内（400 行附近）
ids, _probe = await client.register(installed, device_name=device_name)   # 原: ids = await client.register(...)
```
回归测试：tests/test_runtime_agent_concurrency.py 新增
`test_reregister_unpacks_register_tuple` / `test_reregister_handles_empty_ids`（FakeRegClient 模拟 register 返回元组）。
验证测试有效性的方法：`git stash -- src/runtime/agent.py` 跑测试应 FAIL → `git stash pop` 后 PASS。

## 上游责任链
- 0559ee96（08-12 lvjuntao）：写 `_reregister`，当时 register 返回 list，写法正确
- e5c09544（08-14 grape，feat/obs-storage squash）：改 register 签名只更新 main() 调用点，漏 _reregister → bug 诞生
- 之后 dev/main 全继承；`_reregister` 平时不触发（只在心跳失败≥3 或 300s 定时），所以一直没暴露

## worker 重装三大坑（本次实测）
1. **install-worker.sh 默认 server 是 https://grape.topxtopx.com（错！）**——必须显式 `--server https://grape-dev.topxtopx.com`。
   不传会用错域名下载包（装了 git-73f9a79e 这种陌生版本）+ **把 runtime.env 的 RUNTIME_SERVER_URL 改写成错域名** → worker 彻底连错主控。
   恢复：用正确 --server 重跑一次安装即覆盖修复。安装日志会打印「主控: https://...」核对之。
2. **重装覆盖 runtime.env → 丢失 DEEPSEEK key**（HERMES_CUSTOM_API_DEEPSEEK_COM_API_KEY）→ 任务执行 3s 失败
   `Authorization Required`（401），agent_tasks.errors 为空、exit=1。5 台全中。
   - 检查：`/root/deploy/check_workers_key.py`（key_lines=0 = 缺）
   - 修复：key 源在本机 `/etc/grape/grape.env`，批量补写 + 重启 runtime-agent + 验证进程 environ 含 DEEPSEEK
   - 教训：重装/重部署后必须验 key（skill 早记过"勿假设之前补过就还在"，本次重装主动覆盖了它）
3. **systemctl restart runtime-agent 后 sleep 2 不够**——等 10s 再 is-active，否则显示 activating 误判失败。

## worker 安装包缓存坑（未提交修复不下发）
- `package_version()` 用 `git rev-parse --short HEAD` → **未提交的修复不改版本号** → `build_package()` 缓存命中返回旧包。
- 改完代码要下发 worker：`rm -f data/cache/worker-package/grape-worker.tar.gz data/cache/worker-package/VERSION`
  → 重建（`./.venv/bin/python -c "from src.worker_package import build_package; print(build_package())"`）
  → **必须验包内容**：`tar -xzf ... -O grape-worker/src/runtime/agent.py | grep 'ids, _probe'`。
- worker 版本自检：`journalctl -u runtime-agent | grep 版本不一致`（本地=git-... 服务端=git-... 不一致 = 包落后）。

## engine-selection 行为变更（4a435ba6 合并后，重要！）
- claim 改为**仅按 runtime_id 拉本引擎队列**，**claim 池已废除**（"claim-based 引擎池已弃用"）。
- **runtime_id=0 的池任务永远不会被 claim** → 事件卡 running、任务永久 queued。
- 处理卡死任务：不要清零 runtime_id 转池任务（无效！），要显式绑定
  `pick_engine(repo_key, agent_type)` 选出的 runtime_id：
  ```sql
  UPDATE agent_tasks SET runtime_id=<rid>, pool_agent_type='', status='queued', started_at=NULL WHERE id=...
  ```
  或直接调官方重派：`POST /api/events/{seq}/redispatch`（内部逻辑已含 pick_engine 重解析 + 复用旧快照 enqueue），
  服务端脚本里可 `asyncio.run(redispatch_event(seq, {'username':'mm6667','id':'1'}))` 绕过认证直接调。
- 事件 failed 后可重派（redispatch 兼容终态事件）。

## Git 误删恢复（git fsck --lost-found）
- `git reset --hard` 后已 `git add` 过的文件内容**仍在对象库**（dangling blob），不会被立即删除。
- 恢复：`git fsck --lost-found` → blob 落到 `.git/lost-found/other/`（按内容 hash 命名）
  → 用内容特征 grep 匹配（如 `grep -l 'clear_onboarding_mark' *` + 再 grep 第二特征确认并集版）
  → `cp` 回工作区 → 无冲突标记版本即最终版（有 `<<<<<<<` 的是中间态，弃用）。
- 分支删除本身无损失（merge --no-commit 时 HEAD 未变）；损失的是未提交的暂存内容，靠 blob 恢复。
- ⚠️ 流程教训：merge-test 这类临时评估分支被用户说"水操作"时，先确认是"评价"还是"指令删除"，勿自作主张删。

## VOD agent 仓库 403 排查（bot 无权限）
- 症状：任务 completed 但结果里「GitCode API 对该仓库返回 403（/user 正常、bot 自有仓库正常）= 仓库级权限不足」，
  VOD 只能 A2A 交办无法发评论。
- 判别：`GET /api/v5/repos/{owner}/{repo}/collaborators`（用 owner token，xiaowu2119 等账号 token 在 user_accounts.gitcode_api_token）
  → 看 grape_dev_bot 是否在列、access_level 多少（40=维护者）。
- 修复（gitcode-api skill hosting-flow）：owner token `PUT .../collaborators/grape_dev_bot`（permission=admin，幂等）
  → bot `GET /user/invite?access_token=<bot token>` 找 invitation_token
  → **`POST /user/invite/accept?access_token=...&invitation_token=...`（token 必须走 query 参数！放 body 会 400 "Required request parameter"）**
  → 验证 `GET .../collaborators/grape_dev_bot/permission` access_level≥40。
- 收尾：`UPDATE managed_repos SET bot_username='grape_dev_bot' WHERE repo_key=...`（托管记录可能还是旧 bot qq_59293410）。

## PR 合并后部署不自动触发（断点 + 手动 A2A 补救，2026-08-17 实测）
- **断点**：`pull_request_merged` 事件按 `issue_state.stage` 路由（event_pipeline `_resolve_issue_stage_agent`）——
  stage=qa 只派 QA、stage=sre 才派 SRE(cloud-deploy)。QA 技能完成后**不自动 set_issue_stage 到 sre**，
  stage 停在 qa → cloud-deploy 永远不触发（skill 早有"PR 合并不路由到 SRE 的断点"记录，本次确认该断点的具体形态）。
- **判别**：`SELECT stage, owner_agent FROM issue_state WHERE repo_key=... AND issue_id='#1'` 停在 qa，
  且 `pull_request_merged` 事件 completed 后无 sre 任务入队。
- **手动补救（完整配方）**：`POST /api/a2a`（webhook 路由到 8080，内网 8000 亦可）
  ```json
  {
    "agent": "sre",
    "payload": {
      "repository": "owner/repo",
      "issue_number": "1",
      "pr_number": "1",
      "context": "PR #1 已合并到 main（commit <sha>）。请执行真实部署：cloud-deploy 技能……",
      "account": "owner/repo"
    }
  }
  ```
  - 鉴权：`Authorization: Bearer *** gitcode_webhook_token>`（managed_repos.gitcode_webhook_token，非 bot token）
  - 返回 `{"status":"ok","seq":411,"agent":"sre"}` → 事件 411 a2a_event 入队 + **set_issue_stage 自动到 sre**（A2A 路径内部处理）
  - 服务端脚本内绕过认证：`asyncio.run(redispatch_event(seq, {...}))` 只适用 redispatch；A2A 无等价内部函数，直接 HTTP 调 127.0.0.1:8000/api/a2a 带 header 即可
- **验证闭环**：sre 任务 completed 后查 result_text——应含 ECS 创建（`deploy-<repo>-<ts>`）、EIP 绑定、代码上传路径、
  单测数、部署报告评论 id。本次实测：ECS deploy-signway-fluxgate-143819 + EIP 114.116.235.14 + 29/29 单测全绿 + 报告评论到 Issue。
- ⚠️ **创建 ECS 是真实花钱操作**（按量计费）——按用户偏好，触发 SRE 部署前先确认；且 cloud-deploy 有幂等检查（复用既有 VPC/subnet/密钥对）。

## coding 任务 600s 硬超时 ≠ 工作丢失（2026-08-17 实测）
- 症状：`agent_tasks.errors=["task timed out after 600.0s"]`、exit=1、started/completed 恰差 600s、
  events failed「task timed out after 600.0s」（RUNTIME_TASK_TIMEOUT 默认 600s，服务端杀任务）。
- **关键判别**：任务超时在**收尾复查阶段**（日志最后 `text: Everything works. Let me review...`）时，
  commit+push 可能已完成——**先查 GitCode 侧**再下"开发失败"结论：
  `GET /repos/{owner}/{repo}/branches`（看 feat/issue-N 分支）+ `GET /repos/{owner}/{repo}/commits?sha=<branch>`（看 commit 列表与 message）。
  本次实测：395 超时但分支上已有 `fix: #1 修复 PR 审查发现的问题并校正签名算法`（ad31589d），3 个 Required 问题全修 + 签名校正 + 黄金向量测试——工作完整落地，仅任务进程被掐。
- 与「环境声明不符导致 600s 空转」的区分：看超时前最后几步是**实质进展**（tool_use/step_finish 连续）还是**空转等待**；实质进展 → 工作已提交，直接人工合并 PR 继续流程即可。
