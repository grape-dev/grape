# skill 多平台同步真实执行复盘（2026-08-17）

场景：用户评论 fluxgate Issue #1「帮我把这个skill同步到clawhub」
→ 545 issue_comment（Issue Agent 识别为发布类 → A2A 交办 SRE）
→ 547 a2a_event SRE 执行 → 最终 huaweicloud-vpc-list v0.1.0 发布到 ClawHub（@yangaiwu）
→ 外部验证：ClawHub 公共搜索 API `GET https://clawhub.ai/api/v1/search?q=huaweicloud-vpc-list` 返回 `yangaiwu/huaweicloud-vpc-list` ✅（发布真实成功）

## 实际执行链路 vs 设计

| | 设计（v4.7 插件框架） | 实际发生 |
|---|---|---|
| 入口 | 聊天（process_chat_async → skill_sync_scene）| Issue 评论 → Issue Agent → SRE |
| 执行 | 服务端调 sync_service.publish_skill | SRE 用 cloud-deploy 技能 + 翻 /usr/local/lib/hermes-agent 考古（找到 test_skills_hub_clawhub.py）自己 curl |
| 确认 | 二次确认（CONFIRM_TTL_SEC） | 无确认直接执行 |
| 令牌 | user_platform_tokens 按用户隔离注入 | 3 用户共用同一 token |

## 根因（三层）

1. **接入点覆盖不全**：sync 框架只挂在 process_chat_async（IM/网页聊天），**Issue 评论入口未接入** → Issue 评论路径完全绕过框架。聊天入口先过 match_scene（handler_async.py:430/544），Issue 评论走 issue 技能 → A2A 交办，两个世界。
2. **worker 无框架代码**：worker 安装包 MANIFEST（src/worker_package.py）**不含 src/plugins/** → SRE 在 worker 上根本没有 sync_service 可调。代码只在服务端，而 SRE 在 worker 执行。
3. **SRE 技能缺位**：cloud-deploy 技能只有华为云 ECS 部署（入口判定=仅 pull_request_merged），无任何 ClawHub 内容 → SRE 收到发布请求只能考古。

## 令牌/账号问题（未解决，需用户确认）

- `user_platform_tokens` 表：admin / obs_mysql_user / xiaowu2119 **三个用户共用同一个 clh_ token**（19:20 插入）
- 发布账号 **@yangaiwu 在 user_accounts 中不存在** → 令牌归属不明，多用户隔离（谁配置发到谁名下）未生效
- 判断发布真实性的铁证路径：查 agent_tasks.env_extra 是否含有效令牌 + ClawHub 公共搜索 API 反向验证

## 结论与方向（已与用户对齐）

- SRE 官方职责 = 「构建部署、**发布管理**、监控运维、故障排查」→ 让 SRE 做 ClawHub 发布**职责上合理**（配置/描述见 configs/agent-description.json）
- 不合理的是「没有对应技能 → 只能考古」。**方案：新建独立技能 skill-publish**（不放 cloud-deploy 里，两者职责分开：cloud-deploy=华为云 ECS 部署服务，skill-publish=skill 发布外部平台）
- skill-publish 内容：定位 skill → 读注入令牌（$CLAWHUB_TOKEN）→ curl `POST https://clawhub.ai/api/v1/skills`（multipart: payload JSON{displayName/slug/version/contentType/tags/acceptLicenseTerms/changelog} + files[]）→ 校验（SHA256 与仓库逐字节比对 / 安全审计 / dry-run）→ 回评 Issue
- 服务端配套：`_inject_platform_tokens`（同 _inject_cloud_credentials 模式）把 Issue owner 的 CLAWHUB_TOKEN 注入 env_extra（多用户隔离，token 不落盘）
- **路由改动**：agent-skill-mapping.json 是静态 `sre -> cloud-deploy`（5 场景全如此），**无法区分「部署 vs 发布」** → 同步类任务须在 A2A 交办 payload/事件路由时**显式指定 skill 名（skill-publish）**，否则 SRE 永远拿 cloud-deploy

## 测试注意：bot 自触发防循环

用 **grape_dev_bot 自己建 Issue 不会触发 webhook 处理**——日志 `Pipeline skip: self-comment from bot=grape_dev_bot`（防 bot 自触发循环），事件表无新事件。测 issue 驱动流程须用**真实用户 token**（如 mm6667）建 Issue。

## ClawHub 关键事实速查

- 发布：`POST https://clawhub.ai/api/v1/skills`（multipart, Bearer clh_ token）；CLI 等价 `clawhub skill publish <path>`
- 令牌获取（无需装 CLI）：浏览器访问 `https://clawhub.ai/cli/auth` → GitHub 登录 → clh_ 令牌；设备码 `cli/device`
- 门槛：发布者需注册达门槛的 GitHub 账户；安全扫描自动（VirusTotal/skillspector）
- 速率：写入 300/分钟（匿名）3000/分钟（带令牌），429 带 Retry-After 需退避
- 公开搜索验证：`GET /api/v1/search?q=<slug>`（无需认证，发布验证用）
