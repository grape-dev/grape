# Worker 模型 key 替换流程(2026-08-18 实测)

## 场景
用户给新模型 key,要求替换本机 + 5 台 worker 的 DEEPSEEK API key。

## 关键区别:替换 ≠ 补缺
- `fix_worker_key.py`(skill scripts/)是**幂等补缺**:"已有则跳过"——只适用于 key 缺失场景,不能用来替换。
- 替换用 `/root/deploy/swap_worker_key.py`(2026-08-18 新建):
  - key 通过 `NEW_KEY=*** 环境变量传入,**不落盘明文**(heredoc/命令行不出现在日志);
  - 正则替换 `HERMES_CUSTOM_API_DEEPSEEK_COM_API_KEY=*** 行(本机 /etc/grape/grape.env + 远端 /etc/grape/runtime.env),缺失则追加;
  - 参数化 SFTP 读写,避免 shell 转义坑。

## 完整流程
1. 只读检查现状:本机 grep grape.env + 5 台 worker 的 key 尾号(`sed -E 's/(=.{8}).*/\1****/'` 脱敏)、runtime-agent 状态
2. `NEW_KEY=*** python /root/deploy/swap_worker_key.py`(文件层替换)
3. 本机 `systemctl restart grape-main grape-webhook`(EnvironmentFile 启动时读)
4. 5 台 worker `systemctl restart runtime-agent`
5. 验证三查:文件 key 尾号 + `/proc/<pid>/environ` key 尾号 + `systemctl is-active`
6. opencode 配置是 `{env:HERMES_CUSTOM_API_DEEPSEEK_COM_API_KEY}` 引用,env 换后重启即生效,无需改 opencode.json

## 坑 1:重启后端口未监听 = MySQL metadata lock(第 N 次再现)
本会话:restart 后 grape-main active 但日志停在建表、8000/8080 无监听、health 空。
- 判别:`information_schema.PROCESSLIST` 本机 IP 的 Query 卡 `Waiting for table metadata lock` + `innodb_trx` 里 Sleep+trx RUNNING 的持锁者。
- 本次持锁者 = **worker 0002(192.168.0.115)的 3 个遗留连接**(7178702 Sleep 2891s、7181491、7183125)——worker 侧连接泄漏,一次 KILL 3 个(`cur.execute("KILL %s", (tid,))`)后 ALTER 完成、端口起来。
- 教训:持锁者可能一次多个,且来自 worker 机器(不一定是本机);KILL 后 innodb_trx 复查无残留即可。

## 坑 2:pgrep 抓到非 systemd 实例(0004 双实例)
0004 机器上 root systemd 全局 worker(/opt/grape)与 mlc 用户个人 worker(/home/mlc/grape, 8-13 启动)并存。
- `pgrep -f "src.runtime.agent" | head -1` 抓到的是**旧个人实例**(key 尾号 49e0 与文件 f7c4 不一致 → 误报)。
- 判别:`systemctl show runtime-agent -p ExecMainPID` 才是要验证的实例;`ps aux | grep "[r]untime.agent"` 看完整进程列表(含运行用户)。
- 个人 worker(user scope 凭据)不在全局替换范围,勿动;tail -c 5 尾号对比法是快速判别手段。

## 验证脚本(现场用)
```bash
# 本机
for port in 8000 8080; do PID=$(ss -tlnp | grep ":$port " | grep -oP 'pid=\K[0-9]+' | head -1); tr '\0' '\n' < /proc/$PID/environ | grep "^HERMES_CUSTOM_API_DEEPSEEK_COM_API_KEY=*** | grep -oE 'sk-[a-zA-Z0-9]+$' | tail -c 5; done
# 远端 worker(尾号对比文件与进程)
FILE_KEY=*** "^HERMES_CUSTOM_API_DEEPSEEK_COM_API_KEY=*** /etc/grape/runtime.env | grep -oE 'sk-[a-zA-Z0-9]+$' | tail -c 5)
PROC_KEY=*** '\0' '\n' < /proc/$(systemctl show runtime-agent -p ExecMainPID | cut -d= -f2)/environ | grep "^HERMES_CUSTOM_API_DEEPSEEK_COM_API_KEY=*** | grep -oE 'sk-[a-zA-Z0-9]+$' | tail -c 5)
```
