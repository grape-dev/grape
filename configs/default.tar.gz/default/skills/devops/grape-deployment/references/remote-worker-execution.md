# 远端 worker 执行 401 排障（Authorization Required）

> 2026-08-11 实测。切 queue_remote 后任务被远端 worker claim，3 秒即失败 exit=1，
> agent_tasks.errors/stderr 全空，devops-bot.log 只有 `[task t_xxx] [seq=N] error: Authorization Required`。

## 根因（唯一确认的）: worker 环境缺 DEEPSEEK API key

- 远端 worker 的 opencode 配置 `~/.config/opencode/opencode.json`：
  `"apiKey": "{env:H...KEY}"`（**环境变量引用**）。
- worker 的 systemd unit `runtime-agent.service` 用 `EnvironmentFile=/etc/grape/runtime.env`，
  但该文件只有 `RUNTIME_*` 变量（RUNTIME_TOKEN / RUNTIME_SERVER_URL / RUNTIME_POLL_INTERVAL /
  RUNTIME_HEARTBEAT_INTERVAL / RUNTIME_MAX_CONCURRENT_TASKS / RUNTIME_DEVICE_NAME），**没有 DEEPSEEK key**。
- opencode 启动调 DeepSeek API → 401 "Authorization Required" → 任务秒失败。
- 本机能跑的原因：grape-main / grape-webhook unit 带 `EnvironmentFile=/etc/grape/grape.env`（含该 key）。
  ⚠️ **本机 grape.env 与远端 runtime.env 是两个文件，重部署/新装 worker 只恢复前者会漏后者。**
- 2026-08-11 现场：5 台 worker（0002-0006）全部缺 key —— 远端执行此前从未真正跑通过（心跳正常只是轮询 claim）。
- **2026-08-14 复发（重要）**：worker 0006（sre-worker1，192.168.0.213，credential 20/runtime 21）在 08-11 补过 key 后又丢失——`/etc/grape/runtime.env` 只剩 `RUNTIME_TOKEN`，疑重装/重部署覆盖。症状：模板项目 onboarding_exp/onboarding_explore 双双 failed（3 秒 401），GitCode 仓库无任何 issue。**教训：勿假设"之前补过就还在"，远端任务 401 一律先跑 `scripts/check_workers_key.py` 确认**；批量修复用 `scripts/fix_worker_key.py`（幂等，SFTP 写入去重 + 重启 runtime-agent + 验证）。

## 症状识别（区别于其他失败）

| 特征 | 值 |
|---|---|
| events.status | failed |
| exit_code | 1 |
| duration | ~3s（秒级失败，不是超时/挂起） |
| agent_tasks.errors / stderr | 空 |
| usage_json.session_id | "" |
| devops-bot.log | `[task ...] [seq=N] error: Authorization Required` |
| 远端 journalctl | worker 侧无 opencode 输出（进程起不来就 401） |

对比：direct 模式本地跑同款错误也曾出现（环境缺 key 时），不代表远端特有。

## 诊断命令（paramiko: /root/deploy/venv/bin/python, root/kaifazhe@123）

> ⚠️ **paramiko 运维手法（2026-08-14 两次实测）**：多步远端操作（写文件+重启+验证）**写脚本文件跑**（如 skill `scripts/fix_worker_key.py`），勿用 `python -c` 内联——`$`/反引号/引号在 -c 字符串里多层转义必炸（`chan.exec_command` 抛 `_wait_for_event` 异常）。远端改文件用 **SFTP 读写**（`sftp.open(path,'w')`）比 exec_command 拼 shell 稳；paramiko 依赖装在 grape venv（`/root/grape/.venv/bin/python`）或 /root/deploy venv。

```bash
# worker 上：进程环境里有没有 key
PID=$(pgrep -f 'src.runtime.agent' | head -1); tr '\0' '\n' < /proc/$PID/environ | grep -iE 'DEEPSEEK'
# 空 = 缺 key。再确认配置文件
grep -cE 'DEEPSEEK' /etc/grape/runtime.env   # 0 = 没写入
cat ~/.config/opencode/opencode.json | grep apiKey   # 应看到 {env:HERMES_CUSTOM_API_DEEPSEEK_COM_API_KEY}
```

## 修复（5 台批量）

```python
# 本机取 key（/etc/grape/grape.env），写入每台 worker 的 /etc/grape/runtime.env（去重），重启：
grep -q '^HERMES_CUSTOM_API_DEEPSEEK_COM_API_KEY=*** /etc/grape/runtime.env \
  && sed -i 's|^HERMES_CUSTOM_API_DEEPSEEK_COM_API_KEY=*** /etc/grape/runtime.env \
  || echo '<KEY_LINE>' >> /etc/grape/runtime.env
systemctl restart runtime-agent
```

## 验证

- `systemctl is-active runtime-agent` → active；新 PID 的 environ grep DEEPSEEK = 1。
- journalctl -u runtime-agent 尾部：`RuntimeAgent registered: [11, 12] -> https://grape-dev.topxtopx.com ...`。
- 触发一条新任务（旧 failed 任务不会自动重跑），观察 agent_tasks 新行走 running→completed。

## worker 拓扑速查

- 5 台：ecs-grape-dev-build-0002..0006 = 192.168.0.115 / .64 / .39 / .194 / .213（root/kaifazhe@123）。
- unit：runtime-agent.service（Type=simple, EnvironmentFile=/etc/grape/runtime.env,
  WorkingDirectory=/root/grape, ExecStart=/root/grape/.venv/bin/python -m src.runtime.agent）。
- worker 归属：runtime_credentials(device_name, last_ip) ↔ agent_runtimes(credential_id, status online)。
- 2026-08-11 现场：credential 8 = vod-worker1 = 0002；runtime 11(opencode)/12(hermes) 属它。
