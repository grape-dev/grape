# Worker 全部 401 离线 = 管理台批量注销凭据（2026-08-17 实测）

## 症状
- 5 台 worker 心跳/claim/register 每 5 秒重试但全部 401，响应体 75 字节（应用层 `{"detail":{"code":401,...}}`）
- worker 进程全活（`ps aux | grep runtime.agent` 正常），systemd active，机器/网络无异常
- agent_runtimes 表大量行 status='offline'、last_seen_at 陈旧

## 关键判别：先分清「机器问题」vs「凭据问题」
worker 还在**持续发包**（nginx 每 5 秒有请求）= 机器没挂，问题在服务端拒绝。
- 401 = 凭据校验失败（token 不在 runtime_credentials 或 status != 'active'）
- 完全无请求 = 网络/安全组/进程问题（走 webhook-event-dropped-diagnosis 或 event-stuck-running 路线）

## 排查步骤
1. **找翻转时刻**：逐 worker IP 对比心跳最后 200 与首次 401：
   ```bash
   for ip in 120.46.2.221 101.46.0.215 ...; do
     last200=$(grep "$ip" /var/log/nginx/access.log | grep heartbeat | grep " 200 " | tail -1 | awk '{print $4}' | sed 's/\[//')
     first401=$(grep "$ip" /var/log/nginx/access.log | grep heartbeat | grep " 401 " | head -1 | awk '{print $4}' | sed 's/\[//')
     echo "$ip: 最后200=$last200 首次401=$first401"
   done
   ```
   全部 worker 同分钟翻转 = 单点事件（人/管理台操作），非逐台故障。

2. **该时刻前后找 revoke 调用**（定位操作者）：
   ```bash
   grep -E "runtime-credentials/.*/revoke" /var/log/nginx/access.log | head -25
   ```
   注意 revoke 后必跟 `agent-runtimes/refresh`（管理台 Workers 页自动刷新列表）——这是「人在页面上操作」的痕迹。
   用 IP + UA + referer 识别操作者（2026-08-17 实测：116.205.147.11, Chrome/145, referer grape-dev.topxtopx.com，10:22:07 刚走完 GitCode OAuth 登录，10:42:16 起连点 10 次 revoke）。

3. **journalctl 同秒对照**：确认 401 来自应用层而非 nginx 层：
   ```bash
   journalctl -u grape-main --since "10:55:17" --until "10:55:20" | head -8
   ```
   journalctl 显示 `401 Unauthorized` = 应用层拒绝，token 校验逻辑（src/api/routes/runtime.py `_get_credential_id`）执行到了 `status != 'active'` 分支。

4. **查凭据表确认受害面**：
   ```python
   c.execute('SELECT id, name, device_name, scope, owner_name, status, last_seen_at, last_ip FROM runtime_credentials WHERE id IN (...)')
   ```
   runtime_credentials 列：id/token_hash/name/device_name/scope/owner_id/owner_name/status/last_seen_at/last_ip/created_at。
   被 revoke 凭据的 last_seen_at = revoke 时刻（UTC，+8 换算），可与 nginx revoke 请求时间对上。

## 根因（2026-08-17 现场）
116.205.147.11（Chrome 浏览器，管理台登录用户）在 Workers 页逐个点「注销」，把 10 个凭据全 revoke：
#38 test2(0004) → #37 test1 → #36 mlc-test → #31 → #17 chat-worker(0002) → #52 VOD-Worker-01 → #44 deploy-worker-zww2 → #35 build04-mlc-user → #20 sre-worker1(0006) → #14 coding-worker。
受害 owner：mm6667（6 个）、gcw_IEzSI05D、xiaowu2119、songspace——**跨 owner 批量清空**，不是单个 worker 问题。

## 恢复
⚠️ **2026-08-17 下午语义变更：revoke = 删除**（用户指示「只要吊销就删掉对应的 worker 记录」）——settings.py revoke 接口改为 DELETE runtime_credentials 行 + 级联删 agent_runtimes 行 + 清 devops_agent_runtime_binding + devops_agent_session.runtime_id 置 0。**以下 UPDATE status='active' 恢复法只对变更前的历史 revoked 行有效**；删除后的凭据无法恢复，只能重建凭据 + worker 重装（token 已丢）。
变更前（历史 revoked 行仍可用此法）：
```sql
UPDATE runtime_credentials SET status='active' WHERE id IN (14,17,20,38,44,52);
```
⚠️ 先确认批量注销是否用户/同事有意（可能是在清理旧设备），涉及多 owner 时尤其要问。

## 与其他 401 场景区分
- worker 3 秒 401 "Authorization Required"（opencode 401）= 缺 DEEPSEEK key，见 remote-worker-execution.md
- 本场景 = 凭据被 revoke，响应 75 字节、所有 worker 同分钟翻转、nginx 有 revoke 请求记录
