# 仓库级 skill 保存后回退「默认官方技能（自动）」——owner_id 前缀不匹配根因

## 症状
控制台 Agent Configuration 里把某 agent 的 skill 切成**仓库级**（scope='repo'，
下拉显示 `xxx(仓库)`），save 后切走再回来，下拉变成「默认官方技能（自动）」，
好像没保存成功。**官方级 skill 保存正常**，只有仓库级这一档回退。

用户原话（liufei_cloud，2026-08-18）：
> issue agent 下 skill 切换为 issue-advance(仓库)，切到其他页面再回来，
> 发现 skill 没切换，变成了默认官方技能（自动）。

## 根因：repo 级 skill 的 owner_id 前缀与 repo_key 不一致
链路彻底确认（后端读写逻辑、agents.py / session_store.py 本身无 bug）：

- service 仓库级 skill 行 `skill.owner_id` 存的是**不带 `gitcode:` 前缀**的裸 owner/repo，
  例如 `gcw_3FZApeLT/huaweicloud-iac-best-practices`（实库 id=2603）。
- 保存时后端 `_find_skill("repo", repo_key)`，其中 `repo_key=to_rep...po)` **带** `gitcode:` 前缀。
- `_find_skill` 用 `owner_id=?` 精确等值匹配 → 带前缀 vs 不带前缀 → **匹配不到 → skill_id=0**。
- skill 名虽因 `upsert_agent_session(skill=body.skill)` 写进 session，但 skill_id=0。
- 重新 GET agent 详情时，`skill_scope` 靠 `SELECT scope FROM skill WHERE id=skill_id` 回查，
  skill_id=0 → scope=""。
- 前端下拉按 `scope:name` 精确匹配当前配置 → `""` → 无任何 `<option selected>` → 落到第一项
  「默认官方技能（自动）」。表现为「保存没生效」。

## 判别（为何不是前端/写库 bug）
1. 直接 SQL 查 `SELECT id,skill_name,scope,owner_id FROM skill WHERE scope='repo' AND skill_name=<名>`，
   看 owner_id 是否带 `gitcode:` 前缀（表里风格本就混：有的带、有的不带 → 历史遗留，两种都并存）。
2. 查 session：skill 名已写进去但 `skill_id=0`（`SELECT skill,skill_id FROM devops_agent_session WHERE repo_key=*** AND agent_type=...`）。
3. 关键对照：官方级 skill 保存正常，只有 repo 级回退 → 单点只在这条 owner 匹配。

## 修复
`agents.py` 的 `_find_skill(scope, owner_id)` 对 owner 匹配做归一化，兼容带/不带前缀：
- 命中的 owner 候选 = 原 repo_key 与 `from_repo_key(repo_key)`（去前缀）两者都查（IN 匹配）。
- 幂等，无论历史行存的是哪种风格都能命中。
- 不动 pipeline/webhook/A2A/数据模型——只补匹配逻辑。
- 前端无需改：只要 skill_id 正确回传，`skill_scope="repo"` 就拿到了，下拉即能选中「xxx(仓库)」。

≥iffré验证：改后直接 SQL 比对 `SELECT id FROM skill WHERE skill_name=? AND scope='repo' AND owner_id IN (<repo_key>, <from_repo_key>) AND is_active=1`
能命中正确行=修复成立；旧写法 `owner_id=<repo_key>` 为空。

## 备注（本项目独有）
- 存在同名的官方级（scope='official'）与仓库级（scope='repo'）两个 skill（如 issue 有两个 issue-advance）。
  修好后要确认选中的是仓库级那个 id（owner_id 匹配的那行），勿误命中官方版。
- Python 改动需重启 grape-main 才生效（静态前端实时，进程内 Python 等重启）；重启会杀 in-flight
  opencode 任务并踩 MySQL metadata lock 死锁——处置见 grape-deployment SKILL.md 该节
  （PROCESSLIST 里 `Waiting for table metadata lock` 的持锁 trx，`KILL <trx_mysql_thread_id>`
  后迁移跑完端口才起；可能要多轮，innodb_trx 复查再杀，只杀 db=grape_test_db 的连接）。

## 复现方法（不污染生产）
直接 SQL 层对比补丁前后 `_find_skill` 命中即可判定修复正确，无需起临时 uvicorn 实例
（临时实例 Share init 会在 metadata lock 上卡死，与修复无关）。