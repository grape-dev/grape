# cloud-deploy 凭证链路与「部署成功」真伪判别（2026-08-17 实测）

## 谁提供 AK/SK（多用户隔离设计）
- `_inject_cloud_credentials(env_extra, repo_key)`（src/api/event_pipeline.py）按 **repo owner** 注入：
  `split_owner_repo(repo_key)` → `get_user_account(owner)` → `huawei_cloud_ak/sk` 字段 → 写入
  `env_extra["HUAWEICLOUD_SDK_AK"/"HUAWEICLOUD_SDK_SK"]`。
- **谁仓库谁付钱**：fluxgate 是 signway 的 → 用 signway 账号的 AK/SK；不是全局共享。
- owner 未配置 → 注入**空字符串**（不报错不拦截，技能侧自己面对）。
- 存量现状：14 个 user_accounts 里**只有 mm6667 配了 AK/SK**，其余 owner（xiaowu2119/wdmike/signway…）全空
  → 那些仓库的「部署」都是无凭证执行。查证：`SELECT username, huawei_cloud_ak FROM user_accounts`。

## SRE 怎么「知道」用哪个凭证（不是 AI 猜的）
三层约定，**没有「AI 在一堆凭证里挑」这回事**：
1. **服务端只注入指定变量**：env_extra 只含 `HUAWEICLOUD_SDK_AK/SK` + REPO_FULL_NAME/ACCOUNT/ISSUE_NUMBER/PR_NUMBER。
   其它凭证（gitcode token、feishu、codearts）在 executor 兜底注入（`get_credentials` 全部 provider 小写 key 转大写），
   但技能模板从不引用它们。
2. **SKILL.md 写死变量名**：cloud-deploy 技能「环境变量」表列 `HUAWEICLOUD_SDK_AK/SK`，命令模板直接
   `hcloud configure set --cli-access-key="$HUAWEICLOUD_SDK_AK"`——变量名是焊死的，AI 照抄。
3. 技能文档漏写/写错变量名 → AI 找不到 → 只能猜或幻觉（本次事故就是凭证为空 + AI 脑补）。

## ⚠️ 铁证：事件 completed + 任务 exit=0 ≠ 真的部署了（fluxgate #1）
- SRE 任务 `t_203d250ff7da`（seq 411）completed、exit=0，报告写「新建 ECS deploy-signway-fluxgate-143819、
  绑定 EIP 114.116.235.14、29/29 单测全绿」——**全是假的**：`agent_tasks.env_extra` 里
  `HUAWEICLOUD_SDK_AK: ""`（空凭证，signway 未配置），根本没调华为云 API。
- 报告自相矛盾是破绽：「已创建 ECS…」+「worker 未注入 HUAWEICLOUD_SDK_AK/SK，无法代填真实凭证」——后者才是真话。
- **判别流程**：任何 SRE 部署报告，先查
  `SELECT env_extra FROM agent_tasks WHERE id='<task_id>'`（env_extra 是 JSON 字符串），
  `HUAWEICLOUD_SDK_AK` 为空 = 未真实调华为云 = 报告是幻觉 → 回复用户「未部署，请 owner 配置 AK/SK 后重试」。
- 根治方向（未实施，用户认可）：cloud-deploy SKILL.md 加硬约束「AK/SK 为空必须输出『未部署（无凭证）』并结束，
  禁止输出部署成功描述」；理想是系统级配置需求声明（见下）。

## 系统级「配置需求声明」设计（终版 v2，2026-08-17 用户多轮挑战后收敛；设计文档 /root/grape/docs/config-requirements-detection-design.md）
目标：入队前检查缺哪个配置就提示哪个，不靠技能文档自觉。终版相对初稿（agent→配置清单）有 5 处修正：

1. **配置需求挂在「技能」上，不挂在 agent 上**（用户纠正：sre 跑 cloud-deploy 才要 AK/SK，跑 build-debug/incident-triage 不需要；
   按 agent 列并集 → 必然提示当前场景用不到的配置）。入队时按**本次事件路由出的 skill_name** 查需求。
2. **需求从 SKILL.md 自动解析，不维护死清单**（用户追问「新 skill 怎么发现要哪些凭据」）：
   扫 SKILL.md 的「## 环境变量」表，`来源=account 配置`（或「用户配置」）的行 = 用户凭证 → 进检测清单；
   系统注入变量（BOT_GITCODE_TOKEN 等）跳过。技能作者写文档即自动接入，新技能零维护。
   兜底启发式：无来源标注时变量名含 AK/SK/TOKEN/SECRET/KEY 且不在系统注入白名单 → 视为用户凭证。
   存 skill 表新增列 `required_configs`（JSON: [{env, provider, field, hint}]），每次技能加载重新解析覆盖。
3. **按需检测，不是所有任务都查**（用户质疑「VOD/Issue 也要检测吗，他们不要真实部署」）：
   实测 16 个技能里 15 个只引用 BOT_GITCODE_TOKEN（executor.py:127 系统自动注入，非用户配置）→ 永不检测、零开销；
   只有 cloud-deploy 声明了来源=account 配置的凭证 → 只有它触发检查（当前全平台实际 1 个）。
4. **缺失策略两级可配置开关**：`config_missing_policy` = `dispatch`（默认，仍派发+打标）| `block`（拦截不派）；
   meta 表全局默认 + managed_repos 加列仓库级覆盖（NULL=跟随全局）；判定顺序 仓库列→meta→dispatch。
   block 模式下用户配好 AK/SK 后 redispatch 即正常派发（现有重派机制天然支持）。
5. **终版 v3：缺配置时让用户自己决定，Issue 是主通道（用户拍板「没飞书可以用 Issue 的方式啊」，2026-08-17）**：
   - 事件置新状态 `pending_confirm`（不派发不失败）→ **在关联 Issue 发评论 @仓库 owner**：
     「⚠️ [cloud-deploy] 需要以下配置但 {owner} 未配置：1. HUAWEICLOUD_SDK_AK… 请在管理台 Settings→Credentials 配置后，或回复
     「继续执行」→ 立即派发（可能失败）／「取消任务」→ 终止」
   - **用户回复走 issue_comment webhook 事件**（现成链路，零新基建；所有托管仓库必有 Issue，不依赖飞书）：
     pipeline 的 issue_comment 分支识别关键词——事件处于 pending_confirm 且评论含「继续执行/继续」→ 派发；含「取消」→ 取消；
     其他内容 → 正常走 Issue Agent 流程（不干扰）。**只对 pending_confirm 状态的事件生效**，防误判。
   - 用户去配置 → 保存 AK/SK 时（settings 保存钩子）检测该仓库 pending_confirm 事件 → 自动 redispatch，配完不用做任何事
   - 超时兜底（如 24h 无人应答）→ 按全局策略执行（默认保守 block，不浪费 AI 资源）
   - 飞书卡片降级为**可选附加**（绑了飞书的仓库额外收一张卡片加速，按钮 1️⃣先配置 2️⃣忽略执行 3️⃣取消）；没绑飞书完全靠 Issue
   - 关键前提：现有链路**没有**「缺配置」信号（`_inject_cloud_credentials` 空值照常派发、技能 exit=0、im-notify 无事件可触发），
     主动提示必须先造出信号——pending_confirm 状态 + Issue 评论就是信号源
  实施 8 步：skill 表加 required_configs 列 → 解析器 src/skill_config_parser.py → 技能加载接入 →
  入队检测 → pending_confirm 状态 → 卡片渲染 → 保存钩子 → 超时兜底 → 防幻觉约束 → 测试（缺/全/无声明三场景）。

## 华为云 AK/SK 配置入口（用户自助）
- 管理台 Settings → Credentials → Huawei Cloud 区块填 AK/SK → Save（存 user_accounts.huawei_cloud_ak/sk，按登录账号隔离）。
- 前端已有占位符防护（issue #72 修复）：已配置时输入框留空 + 「✓ 已配置」，拒绝 AK-demo-/SK-demo-/ghp_devopsbot_/含 xxxx 值。
- 提示用户配置的文案落点：cloud-deploy 报告/Issue 评论，或 im-notify 卡片。
