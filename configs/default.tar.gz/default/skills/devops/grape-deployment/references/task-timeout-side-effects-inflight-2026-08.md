# 600s 超时失败 ≠ 工作没完成：在途副作用照常落地，下游 agent 继续跑（2026-08-18 实测）

XOcto/ai-campus-event-planner Issue #3 实证：用户问「为什么 coding 超时失败后 qa agent 还会运行」。
答案：**超时 kill 的是 worker 上的 opencode 进程，但 agent 在超时前/边缘已发出的外部动作（git push、PR 创建、Issue 评论、curl POST /api/a2a 交办）全部照常落地**。任务标 failed 只是进程没来得及正常退出，不代表工作没完成。下游运行是 agent 自己的交办生效，属设计内行为，不是 pipeline bug。

## 完整时间线（CST）

| 时间 | 事件 | 证据 |
|---|---|---|
| 10:17:34 | seq=771 coding 启动（runtime 66, worker-0002） | events |
| 10:27:05 | coding 完成四份交付物+自洽校验 | devops-bot.log "All deliverables are consistent" |
| 10:27:37 | coding t_9a27ff70f933 标 timed-out failed（600s） | agent_tasks.errors |
| 10:27:49 | **PR #1 在 GitCode 创建**（kill 后 12 秒） | GitCode API pulls/1 |
| 10:28:10 | coding 发完成评论（kill 后 33 秒） | GitCode API issues/3/comments |
| 10:28:15 | coding curl POST /api/a2a 交办 QA → seq=775, stage→qa | nginx access.log + devops-bot.log |
| 10:28:18 | QA t_649481b312ab 被 worker-0006 claim，Step 1-48+ 正常审查 | devops-bot.log |
| 10:34:21/26 | coding 又发完成评论 + 二次 A2A 交办 QA → seq=776（重复交办） | 同上 |
| 10:37:56 | QA 交办 coding 修复 → **500 Invalid control character** | devops-bot.log "Webhook error: Invalid control character at: line 8 column 54" |
| 10:38:01 | QA 重试成功 → seq=777 coding 修复（含 3 条 Required 审查结论） | 同上 |
| 10:38:18 | QA 也超时 failed（活干完、收尾没退） | agent_tasks.errors |
| 10:43:27 | coding 修复 t_045860497008 跑完（34s，补 PR fix commits） | agent_tasks |
| 10:43:49 | 修复完成 A2A 交办 QA 复审 → seq=782 | devops-bot.log |

## 判别链（「X agent 在 Y agent failed 后还跑」类问题）

1. **查 DB 全链路**（先 SHOW COLUMNS 再查，列名易变）：
   - `events`：seq/repo_key/event_type/**issue_id**（'#3' 格式，非 issue_number）/agent_type/skill/status/exit_code/payload/created_at/started_at/completed_at。**无 agent 列、无 updated_at 列**。
   - `issue_state`：repo_key/issue_id/stage/owner_agent/a2a_seq/updated_at/created_at/assignee。
   - `agent_tasks`：id/event_seq/**issue_id='#3'**/agent_type/skill/status/exit_code/errors/started_at/completed_at/attempts/runtime_id。**时间戳是 UTC ISO（+00:00），events.created_at 是 CST**——跨表对时间先换算，否则差 8 小时。
   - 排查脚本：pymysql 连 `configs/db-backend.json`，autocommit=True + `%s` 参数化，结尾 close（防僵尸事务）。
2. **谁交办的 = nginx access.log grep `POST /api/a2a`**，按时间窗取来源 IP → 对 `runtime_credentials.last_ip` 反查是哪台 worker。本次 775/776/777 全来自 worker 公网 IP 的 curl/7.79.1 = worker 上 agent 自己调的。
3. **外部产物真实性 = GitCode API**（bot token 取 `configs/global-bot-token.json` 的 gitcode_api_token，`?access_token=*** query 参数；**~/.git-credentials 是 oauth2 格式不能直接用于 API，会 401**）：
   - `GET /repos/{owner}/{repo}/pulls/{n}`（PR 存在性/state/head sha）
   - `GET /repos/{owner}/{repo}/pulls/{n}/commits`（commit 时间线，可证明 push 发生在 kill 前/后）
   - `GET /repos/{owner}/{repo}/issues/{n}/comments`（agent 完成评论，注意有时两条=重复交办信号）
4. **任务级日志在 `/root/grape/data/devops-bot.log`**（uvicorn 日志重定向，journalctl -u grape-webhook 基本没有任务级内容）。格式 `[task t_xxx] [seq=N|issue:#M|agent:X|repo:...] text:/tool_use:/step_start:`——能还原 agent 每一步干了什么、超时前卡在哪一步。
5. **看 stage 矩阵确认路由**：`_resolve_issue_stage_agent`（event_pipeline.py）——Issue 类事件按 stage 路由（vod→VOD，其余→Issue Agent）；PR 类事件 stage=coding/qa/sre → 对应 agent，done → 不分发。但本次 QA 触发**不走 stage 矩阵**，是 coding agent 直接 POST /api/a2a agent=qa（webhook.py A2A 入口：鉴权→is_agent_enabled→set_issue_stage(agent_name)→append_event(running)→pick_engine→enqueue/direct）。`A2A: repo not managed (no bot token), defer to downstream` 是仓库没配 bot_gitcode_token 的正常降级，非故障。

## busy_slots 计数漂移（本次实证的新卡队根因）

- 症状：事件 running 但 agent_tasks 永久 queued、worker 明明 online 心跳正常却不 claim。
- 根因：`agent_runtimes.busy_slots` 只增不减（claim +1，complete/fail -1 的路径没对齐），本次 runtime 60 busy_slots=468 vs max_concurrent=4、66=254、56=30。claim/选引擎判 `busy_slots < max_concurrent` 恒假 → worker 自认满槽不接新任务。设计文档说 recover_orphans 会按实际 dispatched+running 重算防漂移，实测未兜住。
- 判别 SQL：`SELECT id, name, status, busy_slots, max_concurrent FROM agent_runtimes WHERE busy_slots > max_concurrent`。
- 影响：seq=776/782 的 QA 任务（t_5b4ee0e4de0e、t_785286803540）卡 queued。修复方向 = 手工 `UPDATE agent_runtimes SET busy_slots = (SELECT COUNT(*) FROM agent_tasks WHERE runtime_id=? AND status IN ('dispatched','running')) WHERE id=?` 或修增减路径（未实施，需用户确认）。

## A2A 500 坑

`Webhook error: Invalid control character at: line 8 column 54 (char 249)` = A2A payload context 含非法控制字符（如 \x00/\x0b），JSON 解析失败返回 500。agent 重试后成功——但这是接口缺 context 清洗的缺陷（未修）。诊断时看到 500 先看 devops-bot.log 的 Webhook error 行，别当成鉴权/网络问题。

## 要点总结

- 判「下游该不该跑」看**外部产物真实性**（PR/评论存在 = 该跑），别只看任务 status=failed。
- 超时 kill 不撤销已发出的 HTTP/副作用；两个 agent 连续「活干完但超时」时，流程照常闭环是预期。
- 重复交办信号：同 agent 两条完成评论 + 两个 A2A 事件（775/776）→ 可能产生重复任务，清理时注意去重。
