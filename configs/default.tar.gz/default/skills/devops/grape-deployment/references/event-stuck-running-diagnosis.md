# 事件卡 running / 任务卡 queued 排查配方（2026-08-12 实测, issue #33 seq=115）

## 症状
- events 表某行 status='running' 数小时不变（started_at 有值、completed_at 空、exit_code NULL）
- 对应 agent_tasks 行 status='queued' 永远无人 claim（started_at 空）

## 排查顺序（每步都有 SQL / 命令）

### 1. 看事件本体
```sql
SELECT * FROM events WHERE seq=<N>;
```
注意 schema 坑：
- events **没有 issue_number 列**，只有 `issue_id TEXT`（值形如 '#33'），按 issue 过滤用 `issue_id='33'` 会查不到——要带 # 或直接按 seq 查。
- events 无 `agent` 列（agent_type 才是）。
- agent_tasks **没有 claim_token 列**（查询时别引用）；id 是 varchar 无 AUTO_INCREMENT。

### 2. 找对应任务，看它绑定到哪个 runtime
```sql
SELECT id, event_seq, runtime_id, agent_type, status, started_at, created_at
FROM agent_tasks WHERE event_seq=<N>;
-- 全表状态分布快速定位卡点：
SELECT status, COUNT(*) FROM agent_tasks GROUP BY status;
```

### 3. 关键判断：runtime_id 是否还存在于 agent_runtimes
```sql
SELECT id, name, credential_id, status, last_seen_at FROM agent_runtimes WHERE id=<runtime_id>;
```
- 查不到 = **幽灵 runtime id**。`claim(runtime_id)`（src/runtime/service.py）按 `WHERE runtime_id=? AND status='queued'` **严格匹配**，没有任何 worker 注册这个 id → 任务永远 queued → 事件永远 running。这是"一直 running"最常见的直接根因。
- 佐证行被删过：`SELECT AUTO_INCREMENT FROM information_schema.TABLES WHERE TABLE_SCHEMA=<db> AND TABLE_NAME='agent_runtimes'` 若比当前 max(id) 大且表里有缺号（如 3/4/11/12 缺失），说明曾经插入后又被删。

### 4. 幽灵 id 怎么来的（根因）
事件入队时未绑定 runtime 时，`_enqueue_pipeline_task`（src/api/event_pipeline.py）调 `ensure_default_runtime('opencode')`（src/user/db.py），按 `status='online' 优先 + last_seen_at DESC` 选一个 → 硬绑定其 id。
- 该行若在**之后**被删（典型：服务重启跑 `_migrate_tables`（src/api/db_setup.py）做重复凭据去重 `DELETE FROM runtime_credentials WHERE id NOT IN (SELECT MIN(id) GROUP BY name)` + `_rebuild_agent_runtimes_inst_key` 重建唯一键，会连带清掉对应 agent_runtimes 行），任务就绑在已删除的 id 上，永无人抢。
- 判定"重启时被迁移清过"：devops-bot.log 里找 `Renamed backend* -> runtime* columns (M0)` / `Rebuilt agent_runtimes` / `Table '...' ready` 时间戳。
- 注意 ensure_default_runtime 选 id 与事件入库之间的窗口：事件 14:23 入队选到 id=11，11 之后被清，任务 t_xxx 卡死。

### 5. 叠加故障：worker 整体失联（安全组/网络变更）
```bash
# 各来源 IP 最后心跳时间
grep "/api/runtime/heartbeat" /var/log/nginx/access.log | awk '{print $1, substr($4,2,20)}' | sort -k2 | awk '{last[$1]=$2} END {for (i in last) print i, last[i]}' | sort
# 某时刻后某 IP 完全消失 = 被安全组拦（请求根本没到 nginx）
```
- 全部 worker 心跳停在**同一分钟**、只剩个别 IP 还活 → 几乎必是安全组/地址组变更没放行 worker 公网 IP（见 huawei-cloud-security-group.md）。本次 5 台 build worker 15:43:38~53 齐断，只有 chat-worker(120.46.2.221) 存活，对照用户新地址组 16 条清单：5 个 worker 公网 IP 一条未放。
- 这层即使修好幽灵 runtime，任务也没人执行——两层都要修。

## 修复动作
1. 清僵尸（改 failed 而非删行，保留现场）：
```sql
UPDATE agent_tasks SET status='failed', completed_at=NOW() WHERE id='<task_id>' AND status='queued';
UPDATE events SET status='failed', exit_code=-15, completed_at=NOW() WHERE seq=<N> AND status='running';
```
2. 安全组补放 worker 公网 IP（或改内网访问方案）。
3. 防复发：入队时若选中的 runtime_id 已不存在，应回退选一个真实在线的 runtime，不要硬绑幽灵 id（当前代码无此兜底）。
