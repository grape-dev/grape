# 双 webhook 实例判别：本机僵尸 vs 另一实例执行（2026-08-13 wdmike/gallery issue #1 实测）

## 症状
- 托管仓库的 issue 事件在本机 events 表全部 status='running'（无 completed_at），agent_tasks 全部 queued（attempts=0、runtime_session_id 空、无 claim 日志）。
- 但 GitCode 网页/API 上 issue 有完整 agent 评论链（[VOD Agent]→[Issue Agent]→[Coding Agent]）、labels 已打、PR 真实存在。
- 结论陷阱：直接按"幽灵 runtime 卡队列"处理（见 event-stuck-running-diagnosis.md）会漏判——**活儿是另一个实例干的**。

## 根因
GitCode 仓库可配多个 webhook（本仓库两个）：
- hook 71720 → `https://grape-dev.topxtopx.com/webhook/gitcode`（本机 dev，2026-08-11 建）
- hook 70366 → `http://121.36.33.129:8080/webhook/gitcode`（另一实例，2026-08-06 建，先于本机托管）
两侧同时收同一批事件；另一实例（活跃，其 A2A seq 已到 618）执行了完整工作流（VOD 结构化→Issue 打标签分诊→A2A 交办 Coding→提交代码→开 PR→收尾），本机只入队不执行。

## 判别三证据（按获取成本排序）
1. **GitCode 侧真实进展**（最先看，零成本）：
   - `GET /repos/{owner}/{repo}/issues/{n}/comments` → 看有没有 agent 评论、谁发的、时间线
   - `GET /repos/{owner}/{repo}/issues/{n}/labels` → 标签是否真实存在
   - `GET /repos/{owner}/{repo}/branches` → PR 分支是否存在
   - `GET /repos/{owner}/{repo}/commits?sha=<branch>` → 分支最新提交的作者/时间（本次：14:35:32 grape_bot 提交 "fix: 修复 REWARD_MISSION_ID..."）
2. **发评论账号身份**：webhook payload 的 `user.id` / `user.username`。本机 bot=grape_dev_bot；本次执行者是 **grape_bot**（id 12224835）——不同账号即另一实例。本机 devops-bot.log 会打 `comment from grape_bot, not a bot (...)`（不在本机 bot_usernames 名单）。
3. **hook 列表（用仓库 owner 的 token）**：`user_accounts.gitcode_api_token` 取仓库 owner 行，`GET /repos/{owner}/{repo}/hooks` → 数 URL。**bot token 查 hooks 返回 403 Forbidden**（权限不足），owner token 才看得到完整列表含 password/result。
4. **序列号佐证**：评论里 A2A seq（本次 618）远大于本机 `SELECT MAX(seq) FROM events`（本次 174）。

## 本机侧核查清单（确认本机确实没跑）
- `SELECT ... FROM agent_tasks WHERE event_seq BETWEEN ...` → 全 queued、attempts=0、runtime_session_id=''
- `grep "claim:" data/devops-bot.log` 对应时间窗 → 无本仓库任务 claim
- devops_agent_session 绑定：vod 会话 runtime_id=11（agent_runtimes 已无此行=幽灵）、issue 会话 runtime_id=1（offline 本地）
- issue_state 表 stage 停在 'vod'（从未推进到 issue/coding/done）
- devops-bot.log 该时间窗无 `[task ...] step_start` 执行日志

## 注意事项
- events.issue_id 是**字符串** `"#1"`（不是整数 1）——`WHERE issue_id=1` 查不到，须 `'#1'`。
- 幽灵 runtime 修复（重绑 devops_agent_session.runtime_id 到在线 runtime）仍然必要，否则本机后续事件继续卡。
- 若 121.36.33.129 是生产环境，双 webhook 可能是设计；若不想本机接收，可停用本机 hook 或改 event_route_config。
- GitCode MR/PR 详情 API 路径（merge_requests/pull_requests 变体）曾 404；PR 信息可从 webhook payload 或仓库 branches/commits API 拼。

## 2026-08-14 复测：wdmike/gallery PR #1 (pull_request_opened seq 169/170) 卡住 — 同款双 webhook 僵尸

### 用户报障
"wdmike/gallery 仓库中提的 新 PR #1: pull_request_opened @grape_bot Seq #170 #1，为什么卡主了"

### 症状与本机核查（ecs-grape-dev-build-0001）
- 服务正常：grape-main/grape-webhook active，8000/8080 监听正常
- nginx access.log 里 gallery 只有浏览器 GET 轮询（/api/skills、/api/agents/vod|issue|coding/wdmike/gallery），无 webhook POST 特征
- events 表（MySQL grape_test_db）：wdmike/gallery 从 seq 157 到 172 全部 status='running'、completed_at 全空，含两条 `pull_request_opened`（seq 169 @14:35:51、seq 170 @14:36:03，issue_id 均字符串 `'#1'`）
- agent_tasks 表：对应 16 条任务全部 queued、attempts=0、runtime_session_id 空；**从未被 claim**
- devops-bot.log：无任何 gallery 任务的 claim/step_start 记录（仅 08-14 10:22 一条 "First repo: wdmike/gallery" 托管日志）
- MAX(seq) 本机 227（远小于另一实例评论里的 A2A seq 618）
- 死因同 08-12 issue#33 幽灵 runtime：events 157-168 绑定 runtime_id=11（**agent_runtimes 表已无此行**）、169/170 绑定 runtime_id=1（offline）；claim 按 id 严格匹配 → 永无 worker 接单
- meta.execution_mode=queue_remote（入队模式，所以事件入了 agent_tasks 而不是 direct 就地执行）

### GitCode 侧真实进展（owner=wdmike token，bot token 查 hooks 会 403）
- hooks：**71720 → https://grape-dev.topxtopx.com/webhook/gitcode（本机）+ 70366 → http://121.36.33.129:8080/webhook/gitcode（另一实例）**，双 hook 并存、均 200
- PR 列表 `/repos/wdmike/gallery/pulls`：**9028200**「fix: 修复 REWARD_MISSION_ID 回归及错误码映射缺失（Issue #1 代码审查）」 state=open、作者 **grape_bot**（另一实例 bot，id 12224835）、head=feat/issue-1；created 08-13 14:35:49、updated 14:36:03，之后无合并无新评论
- ⚠️ `/repos/wdmike/gallery/pulls/9028200` 详情 API 返回的字段全为 None（空壳），PR 信息以列表 API 为准
- issue #1 comments（全部 grape_bot 发出，时间线完整）：14:09 VOD Agent 接单 → 14:28 Issue Agent 分诊打 bug/triaged 标签 → 14:33 A2A 交办 Coding（seq 618）→ 14:36:37 [Coding Agent] "已完成全面代码审查并修复发现的 bug，请审查 PR #1"
- issue #1 state=open、updated 14:38:27；branches：main + feat/issue-1

### 结论
- **PR #1 本身没卡**：另一实例（121.36.33.129，grape_bot）已走完 VOD→Issue→Coding 全流程，停在"Coding 完成、等 owner 审查合并 PR"（open 一天多无人合）
- **本机显示的"卡住"是双 webhook 僵尸**：两侧同收事件，另一实例干活，本机入队即死（幽灵 runtime 11 + offline runtime 1，无人 claim）
- 与 2026-08-13 issue #1 案例完全同款，唯一新增：PR 事件（pull_request_opened）同样会落入该僵尸模式

### 处理
按用户指示"只看不动"，仅存档。修复选项未执行：
1. 重置本机僵尸：events 157-172 与对应 agent_tasks 清理/重置 + 重绑 devops_agent_session.runtime_id 到在线 runtime
2. 本机若不应收该仓库事件：停用 hook 71720 或改 event_route_config
3. 若 121.36.33.129 是生产实例，双 webhook 可能是设计，需与用户确认归属

