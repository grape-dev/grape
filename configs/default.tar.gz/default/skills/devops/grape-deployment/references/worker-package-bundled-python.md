# Worker 安装包内置 Python>=3.10（2026-08-13, commit 5dc76e3c）

背景：worker 端 install-worker.sh 原来要求目标机有系统 Python>=3.10，没有就 fail。
5dc76e3c 起把 python-build-standalone 解释器打进 grape-worker.tar.gz，目标机零依赖可装。

## 打包来源与精简子集

- 来源：`UV_PYTHON_DIR`（默认 `~/.local/share/uv/python/`）下 cpython-3.1x* 目录，
  `_find_python()` 扫 >=3.10 取版本最高者；无则现场 `uv python install 3.12`；仍无 → 降级
  （包内无 python，安装回退依赖系统解释器，log warning）。
- 精简子集 `_python_subset_entries()`：只打
  - `bin/python3.12`（含 python/python3/python3.12 symlink）
  - `lib/python3.12/`（stdlib 整目录）
  - `lib/libpython*.so*`（bin 动态链接 libpython3.12.so.1.0，必须带）
  剔除：include/、share/、lib 根下 tcl/tk/itcl/thread/pkgconfig、`__pycache__`、`*.pyc`。
- 打包位置：`grape-worker/python/`；包体 ~2.6MB → ~26MB。
- 版本指纹：`package_version()` = `git-<sha>-w<wheels指纹>-p<python指纹>`
  （python 指纹 = 子集相对路径+size+mtime 的 sha256[:8]；没有 python 时为 "none"）。
- standalone 构建自带 ensurepip：`python/bin/python3.12 -m venv` 后 pip 25.0.1 可用，已验证。

## install-worker.sh 两阶段探测（时序坑）

包内 python 的探测必须放在**解压之后**（脚本第 3 步），第 1 步探测时包还没解压：

1. 第 1 步（解压前）：只探测系统 `python3.12/3.11/3.10/python3`，找不到不 fail，打日志
   "将尝试使用包内自带解释器"。
2. 第 3.5 步（解压 + SHA256SUMS 校验 + data/ 创建后）：`[ -z "$PY" ]` 时检查
   `$INSTALL_DIR/python/bin/python3`，可用则 `PY=...` 并 log "使用包内自带 Python"。
3. 仍为空才 fail（提示先装 python 或重新下载含 python/ 的安装包）。

## 三个实测坑

1. **uv venv 无 pip → wheels 静默缺失**：`_ensure_wheels()` 用 `sys.executable -m pip
   download`，uv 建的 venv 无 pip 模块 → returncode!=0 仅 log.warning → 包内无 .whl →
   `test_sha256sums_match_payload` 断言 `any(.whl)` 失败。修复：
   `uv pip install --python .venv/bin/python pip`（本机 2026-08-13 已补装）。
2. **tar filter 与 SHA256SUMS members 不一致**：`tar.add(..., filter=_tar_filter)` 会过滤
   `__pycache__`/`.pyc`，但 build_package 里 members 收集若没同步跳过，SHA256SUMS 条目数 >
   tar 实际条目数 → 断言 `ok == len(sums)` 失败（实测 1509 vs 1269）。修复：os.walk 时
   `dirs[:] = [d for d in dirs if d != "__pycache__"]` + files 跳过 `*.pyc`，指纹与打包共用
   同一 entries 函数，天然一致。
3. **python/bin/python3 是 symlink**：SHA256SUMS 只收集普通文件
   （`os.path.isfile and not os.path.islink`），symlink 无 sums 条目。断言/校验须指向真实
   二进制 `grape-worker/python/bin/python3.12`，不是 `python3`。

## 改后必做（验证配方）

```bash
cd /root/grape
./.venv/bin/python -m py_compile src/worker_package.py && bash -n scripts/install-worker.sh
./.venv/bin/python -m pytest tests/test_worker_package.py -q    # 9 passed, ~66s（25MB 包全量 SHA256）
# 手动构建检查内容：
./.venv/bin/python -c "import src.worker_package as wp; p=wp.build_package(); import tarfile,os; \
  tf=tarfile.open(p); n=tf.getnames(); print(os.path.getsize(p)//1048576,'MB'); \
  print('py3.12:', 'grape-worker/python/bin/python3.12' in n, 'libpython:', 'grape-worker/python/lib/libpython3.12.so.1.0' in n); \
  print('unwanted:', [x for x in n if any(y in x for y in ('/tcl','/tk','/include/','/share/'))][:3])"
# 端到端模拟离线安装（无系统 python 场景）：
rm -rf /tmp/worker-sim && mkdir -p /tmp/worker-sim
tar -xzf data/cache/worker-package/grape-worker.tar.gz -C /tmp/worker-sim --strip-components=1
/tmp/worker-sim/python/bin/python3.12 -m venv /tmp/worker-sim/.venv
/tmp/worker-sim/.venv/bin/pip install --quiet --no-index --find-links /tmp/worker-sim/wheels -r /tmp/worker-sim/requirements-worker.txt
/tmp/worker-sim/.venv/bin/python -c "import aiohttp; print(aiohttp.__version__)"
# 重启双服务（服务端代码，不重启会下发旧包）→ 公开端点验证（无鉴权，install-worker.sh 用它）：
systemctl restart grape-main grape-webhook
curl -s https://grape-dev.topxtopx.com/api/runtime/grape-worker.tar.gz -o /tmp/dl.tar.gz
tar -tzf /tmp/dl.tar.gz | grep -E 'python/bin/python3.12|python/lib/libpython3.12.so.1.0'
```

注意：standalone 构建按打包机架构（aarch64），跨架构目标机解压后 python 跑不起来 →
pip 离线安装失败会回退在线（install-worker.sh 已有该分支），属预期降级。
