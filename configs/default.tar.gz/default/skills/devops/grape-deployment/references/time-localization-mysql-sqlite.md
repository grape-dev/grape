# 时间存储语义与本地化展示（MySQL/SQLite/UTC ISO 混存 → normalize_event_time，2026-08-17 实施）

## 时间存储语义（grape 现状，跨后端不一致）
| 来源 | 格式 | 语义 |
|---|---|---|
| MySQL 表默认 `now()`（events/chat_messages/tasks/agent_shared_knowledge/chat_conversations/event_thread/runtime_credentials.created_at 等） | `2026-08-17 22:47:05` 无时区 | CST（服务器本地，UTC+8） |
| SQLite `datetime('now')`（测试库/单机） | 无时区 | UTC |
| 代码写入（events.started_at/completed_at、agent_tasks 时间） | `2026-08-17T14:47:05.394419+00:00` | UTC ISO 带偏移 |

**核心坑**：无时区字符串无法自描述，前端不能猜——MySQL 下 CST 被当 UTC 解析会 +8h 错位且跨天（22:47 → 次日 06:47）。必须后端按 backend 语义归一化。

## 已实施方案（dev 57a43c36，设计文档 docs/event-time-localization-design.md）
- 后端 `src/api/time_utils.py normalize_event_time(raw)`：
  - 带时区（Z 结尾 / ±HH:MM）→ 解析后 astimezone(UTC) 输出 `+00:00` ISO
  - 无时区 `YYYY-MM-DD HH:MM:SS[.ffffff]` → mysql=CST(+08:00) 转 UTC / sqlite=UTC 直接标 +00:00
  - 空值/坏值原样返回；幂等（已归一化输入再归一化不变）
  - backend 判定：`src.mysql_compat.load_db_backend_config()`（测试由 conftest 强制 sqlite）
- 序列化点统一包裹（events 列表/详情/thread、dashboard recent/agent_recent、agents recent_events/vod 会话、pipeline、tasks、runtime 任务列表、knowledge、settings 凭据、session_store、session_manager 会话与消息）——新写 API 输出 created_at/last_active_at 等一律过 normalize_event_time
- 前端 `fmtLocalTime`（api.js）正则 `^(\d{4})-(\d{2})-(\d{2})[ ](\d{2}):(\d{2}):(\d{2})(?:\.\d+)?([+-]\d{2}:\d{2})?`：带偏移还原绝对 UTC 时间点再转本地；无时区兜底当 UTC（SQLite 语义）
- 展示截取约定：Event History 用 substring(5,16)（MM-DD HH:MM）；dashboard 用 substring(11,16)（HH:MM）；运行日志用 substring(11,19)（HH:MM:SS）

## 验证配方
- 后端：`pytest tests/test_time_utils.py`（10 用例：mysql/sqlite 语义、±HH:MM 偏移、Z 结尾、坏值、幂等）
- 前端：`node --check` 语法；`TZ=Asia/Shanghai node -e` eval fmtLocalTime 函数体后打印各输入，核对本地时间
- 生产：venv python `from src.api.event_store import get_events; get_events("gitcode:<owner>/<repo>", limit=1)` 看 created_at 是否 `+00:00` 结尾
- **静态 JS 改动必须 bump index.html 的 ?v=（api.js?v=10→11、agents.js?v=17→18、events.js?v=16→17、knowledge.js?v=1→2），否则浏览器缓存旧文件**——部署后 curl `http://127.0.0.1:8000/static/js/<file>?v=<新>` grep 新标记确认

## 易漏点
- MySQL 下所有「表默认 now()」的列都是 CST：任何直接输出给前端的序列化点都要包裹（本次漏查 pipeline/event_thread/chat_conversations/knowledge/runtime_credentials 等，逐个补齐）
- 前端直显点（`replace('T',' ')`、`slice(11,19)` 这类手工截取）与已走 fmtLocalTime 的点要一起改，否则同一页面时间格式不一致
- 归一化只在序列化层做，不迁移 DB、不改历史数据（读时转换）
