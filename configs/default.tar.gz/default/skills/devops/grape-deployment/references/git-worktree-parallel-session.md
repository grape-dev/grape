# git 管道掩盖失败状态 + 并行会话共享工作区：worktree 隔离（2026-08-17 实测）

## 事故一：`git checkout 2>&1 | tail -1 && ...` 管道吞掉失败（exit code 被 tail 覆盖）
- **坑**：`cmd 2>&1 | tail -1 && next` 的 exit code = **管道最后一个命令（tail）的 exit code**，不是 git 的。
  git checkout 失败（exit 128，输出 `error: ... Aborting`）时 tail 仍返回 0 → `&&` 链继续执行
  → 后续 `git pull` / `git checkout -b` / `git push` 照跑，**分支创建在错误基线**上。
- **本次实例**：工作区有并行会话的未提交改动 → `git checkout dev` 失败（tail -1 显示 "Aborting"），
  但链继续 → `git checkout -b feat/xxx` 从 feat/skill-sync-multiplatform（而非 dev）创建 → 新提交 parent 错误。
- **判别**：`git branch --show-current` + `git log --oneline -3`（看 parent 是否符合预期基线）+
  `git reflog -10`（看真实 checkout 序列）。远程分支 hash 与预期不符（`git ls-remote origin <branch>`）
  也是信号——push 时 HEAD 根本不是你以为的分支。
- **预防**：① git 命令链里不要用 `| tail` 包 git 命令（要截断输出先 `set -o pipefail`，或分开执行：
  `git checkout dev` 单独一条、看输出确认成功后再下一条）；② 切分支前 `git status --short` 确认
  工作区干净（有未提交改动时 checkout 会失败，尤其跨分支内容不同的文件）。

## 事故二：并行会话共享同一工作区（/root/grape）→ 分支被切走、提交落错分支
- **现象**：多 Hermes 会话共用仓库工作区时，另一会话会 `git checkout` 切分支——你的
  `git add/commit` 会落在**它切到的分支**上（本次：文档提交误落 feat/skill-sync-multiplatform）。
- **判别**：reflog 出现非本会话的 `checkout: moving from X to Y` 条目；工作区出现不属于本任务的
  未提交改动（如 `M docs/skill-publish-design.md`，mtime 新近）——**那是并行会话的工作，勿 stash/丢弃**；
  若 `git stash` 报 `No local changes to save` = 对方已自行提交（工作区安全，可直接切分支部署，无需备份）。
- **修复（误提交搬回正确分支）**：不要在主工作区 reset（会动并行会话的 HEAD/工作区）。
  用 **git worktree 隔离**：
  ```bash
  git worktree add /tmp/grape-etl <正确分支>      # 独立目录 checkout，不碰主工作区
  cd /tmp/grape-etl && git cherry-pick <误提交>    # 搬提交
  git push origin <正确分支>
  git worktree remove /tmp/grape-etl
  ```
  误提交残留的原分支**先不动**（并行会话可能正在其上工作，reset 会干扰其 HEAD）；
  报告用户由其在并行会话结束后清理。
- **worktree 里跑测试/verify 的补丁**：worktree checkout 不含 gitignored 文件——需 `mkdir -p data`
  （conftest 写日志/测试库）+ 复制 `configs/db-backend.json`（集成验证用，用完删，勿提交）+
  复制 `/.hermes/`（hermes verify 的 manifest，否则 verify 找不到 recipe）；跑完清理复制品。

## 附带：本地 dev 出现非本会话提交
- 并行会话/用户可能直接向本地 dev 提交（本次 `1a784208 docs: skill-publish 设计 v3.0`）→
  `git rev-list --left-right --count dev...origin/dev` 变为 `N/0`。
- **处理**：不擅自推送/撤销/合并（非本会话操作，意图不明）——报告用户，由用户决定推不推。

## 相关
- 误删分支/`git reset --hard` 后暂存内容可救回（git fsck --lost-found）见 SKILL.md 对应节。
- 远端 dev 被上游 force-push 重写历史的恢复流程见 SKILL.md Services 节。
