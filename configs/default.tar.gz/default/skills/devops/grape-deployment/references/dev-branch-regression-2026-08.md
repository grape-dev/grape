# dev 分支拓扑变更 & 已知回归实录（2026-08-11）

## 分支拓扑变更
- 远程 `lvjuntao` 分支 2026-08-11 被删除（`git fetch --prune` 后 origin/lvjuntao 显示 gone）。
- 部署分支切换为 `dev`；`dev` 与 `main` 指向同一提交 b252ff2 "!6 merge new-version2 into main"（20:30 推送）。另存在 `new-version2` 分支。
- 本地 lvjuntao 分支（指向 2d58493）保留为 [gone] 状态，其中含 dev 分支缺失的修复提交——删除前先确认无需再 cherry-pick。
- 切换命令：`git checkout -B dev --track origin/dev`（工作区干净、configs/ 均 gitignored，切换安全）。

## 已知回归：issue_opened webhook 500（已由上游 979c0d1 修复，2026-08-11 21:30 部署验证）
- 回归根因：dev 分支 `src/api/session_store.py::set_issue_stage` 签名曾为 `(repo_key, issue_id, stage, owner_agent, a2a_seq=None)` —— **无 `assignee` 参数**；且函数末 log 行引用未定义变量 `assignee`（NameError）。
- 调用方 `src/api/event_pipeline.py:267`：`set_issue_stage(repo_key, _rid, "vod", "vod", assignee=_asg)` → TypeError → issue_opened webhook 必 500（nginx 日志 `TypeError: set_issue_stage() got an unexpected keyword argument 'assignee'`，实测 21:04:43 / 21:07:13 两次 500）。
- 修复轨迹：2d58493 只存在于已删的 lvjuntao 分支；用户 21:2x 决策"严格按 dev 原样部署，接受回归"；随后上游 979c0d1（"fix(issue-state): 合并冲突回归 - set_issue_stage 恢复 assignee 参数"）合入 dev（tip 14c0976 "!7 merge new-version2 into main"），`git pull --ff-only` 后验证：tests/test_issue_state.py + test_issue_lifecycle_routing.py 24 个全过，webhook 500 消失。
- **教训：dev/main 合并线会丢 lvjuntao-only 的修复**。切/拉合并线分支后，先 grep 关键修复签名（`grep -n 'assignee' src/api/session_store.py`）再跑相关测试，确认无回归再重启。

## events 表结构（诊断用，注意无 agent 列）
SHOW COLUMNS FROM events:
seq int | repo_key text | event_type text | source text | issue_id text | title text | summary text | actor text | payload text | agent_type text | runtime text | skill text | status text | exit_code int | duration double | agent_logs text | result text | created_at text | started_at text | completed_at text

running 事件查询用 agent_type（不是 agent）：
```sql
SELECT seq,status,event_type,agent_type,runtime,started_at,created_at,title FROM events WHERE status='running';
```

## pkill 自匹配事故
- `pkill -f 'opencode run'` 经 bash -c 执行时，模式会匹配 bash 自身命令行（内含该字面量）→ shell 被 SIGTERM，整条命令 exit -15，后续步骤不执行。
- 正确写法：`pkill -f '[o]pencode run'`（正则括号技巧：自身命令行不含字面量 `[o]pencode`，目标进程名含 `opencode` 仍能匹配）。

## 部署要点补充
- 重启前检查 in-flight：`ps -o pid,ppid,etime,cmd -p <pid>` 看 ppid——ppid=1 说明父进程已死，是孤儿（空烧 CPU/LLM），直接 pkill。
- 孤儿 opencode 不一定对应 DB running 事件（2026-08-11 有 3 个 ppid=1 孤儿但 events 表 running=0），两者独立检查。

## meta 幂等迁移坑（2026-08-11 改 oauth 配置实测）
- `migrate_accounts_from_json`（src/user/db.py）启动时只把 global-bot-token.json 的 3 个 oauth key **在 meta 不存在时** INSERT（幂等）——改 JSON 后重启不会覆盖 meta 旧值。
- 症状：JSON 已更新、服务 health OK、日志无 err，但 OAuth 登录仍用旧凭据（meta 表 oauth_gitcode_client_id/secret 还是旧值）。
- 修复（二选一）：
  ```sql
  UPDATE meta SET value='<新值>' WHERE `key`='oauth_gitcode_client_id';  -- 列名是 key/value，不是 meta_key/meta_value
  -- 或先 DELETE FROM meta WHERE `key` LIKE 'oauth_gitcode%'; 再重启让迁移重写
  ```
- redirect_uri 值未变时 UPDATE rowcount=0，属正常（值相同不更新），用 SELECT 确认即可。

## bot_usernames 用户覆盖（2026-08-11）
- 用户明确要求 configs/global-bot-token.json `bot_usernames=["grape_dev_bot"]`（display name，非 login qq_59293410）。
- 基线事实仍是：GitCode member API 只认 login。若托管仓库 member/邀请操作 404，先核对 bot 账户实际 login 与此配置，再问用户是否回退——勿自作主张改回。
