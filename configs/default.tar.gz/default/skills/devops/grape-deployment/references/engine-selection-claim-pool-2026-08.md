# 2026-08-17 worker 全离线事故链 + engine-selection 新机制运维变化

## 事故时间线（一天内全链路）
1. **10:42** 有人（管理台登录用户 116.205.147.11，Chrome）在 Workers 页批量 revoke 了全部 runtime 凭据
   （10 次 POST /api/settings/runtime-credentials/{id}/revoke，覆盖 mm6667/gcw_IEzSI05D/xiaowu2119/songspace 的 worker）
   → 5 台 worker 心跳从 200 变 401。
2. 401 触发 worker 端 `_reregister`（心跳失败≥3次/每300s）→ 暴露潜伏 bug → 422 死循环。
3. 11:23 上游把 main→dev 合并（4a435ba6，engine-selection 重构）提交并重启服务。
4. 11:43 另会话手改 instances.py/user/db.py（revoked 排除）→ 弄挂 3 个测试。
5. 10:06 重装的 worker 包还丢了 DEEPSEEK key → 修好 422 后任务又 3s 401 Authorization Required。

## 根因 bug：_reregister 未解包 register() 元组（e5c09544 引入）
- e5c09544「feat(obs): worker 直连 OBS」把 `client.register()` 返回签名从 `list[int]` 改成
  `tuple[list[int], str]`（多带 probe_url），**只改了 main() 调用点，漏改 _reregister**。
- `_reregister` 里 `ids = await client.register(...)` → ids 拿到 `([54, 55], '')` 元组 →
  `for rid in ids` 时 rid=[54,55] 列表 → claim/recover URL 变 `/runtimes/[54, 55]/...` → 422。
- 症状特征（worker 日志铁证）：`re-registered successfully, new runtime ids: ([54, 55], '')`。
- 修复（已提交 67fd7443）：`ids, _probe = await client.register(...)` 解包。
- **通用教训**：改函数返回签名必须 grep 全部调用点（main 改了、_reregister 漏了）。
- 回归测试：tests/test_runtime_agent_concurrency.py 新增 test_reregister_unpacks_register_tuple
  / test_reregister_handles_empty_ids（FakeRegClient 模拟 register 返回元组）。

## engine-selection 新机制（4a435ba6 起）——卡死任务恢复法已变
- **claim-based 引擎池已废除**：service.py claim 只按 `WHERE runtime_id=? AND status='queued'`
  定向拉取，**runtime_id=0 的池任务永不被 claim**（旧「清 0 + pool_agent_type 转池」恢复法失效）。
- 卡死任务（绑定 revoked/offline 旧 runtime）正确恢复法：
  1. `rid = pick_engine(repo_key, agent_type)`（src.runtime.engine_select，专属→全局→本机）
  2. `UPDATE agent_tasks SET runtime_id=?, pool_agent_type='', status='queued', started_at=NULL WHERE id=?`
  3. 或直接调官方重派接口 `POST /api/events/{seq}/redispatch`（内部自动 pick_engine 重解析路由，
     复用旧 task 快照新建任务；30s 幂等 meta redispatch:{seq}）。
- 事件 failed「无可用引擎（engine_unavailable）」= engine-selection 找不到健康引擎
  （worker 全挂或 binding 指向 revoked 凭据行时出现）。

## LEFT JOIN 排除 revoked 凭据必须兼容 NULL
- 用户手改的 get_runtime_id_by_name/ensure_default_runtime/resolve_instance_id 用
  `LEFT JOIN runtime_credentials rc ... AND (ar.credential_id=0 OR rc.status='active')`
  排除 revoked 行——但测试 seed 直接插 agent_runtimes（无对应凭据行）→ rc.status 为 NULL →
  `NULL='active'` 为 False → 行被过滤 → 返回 None / 重复插入（test_runtime.py 3 个失败）。
- 修复：条件加 `rc.status IS NULL`（无凭据历史行回退，revoked 仍排除）：
  `AND (ar.credential_id=0 OR rc.status IS NULL OR rc.status='active')`；
  resolve_instance_id 的匹配条件同样 `cst is None or cst == "active"`。

## worker 升级操作（install-worker.sh）
- ⚠️ **install-worker.sh 默认 server 是 https://grape.topxtopx.com（错域名）**，必须显式
  `bash -s -- --token <t> --server https://grape-dev.topxtopx.com`。用错域名会把 runtime.env
  的 RUNTIME_SERVER_URL 改成错的 + 装到错误包（worker.version 变陌生 hash）。
- ⚠️ **重装会覆盖 runtime.env 丢 DEEPSEEK key**（10:06 重装后 5 台 key_lines=0）→ 升级后必须
  跑 /root/deploy/check_workers_key.py 复查 + fix_workers_key_0817.py 补（key 源 /etc/grape/grape.env）。
- 打包缓存按 git HEAD 版本号判断（未提交修复不触发重建）：改代码后重打包需
  `rm -f data/cache/worker-package/grape-worker.tar.gz data/cache/worker-package/VERSION`
  再调 build_package()；包内容读磁盘（含未提交改动），版本号不变。
- 验证包内容：`tar -xzf ... -O grape-worker/src/runtime/agent.py | grep 'ids, _probe'`。
- 升级脚本参考 /root/deploy/upgrade_workers_0817.py（读 token → curl install --server → restart →
  cat worker.version）。验证要点：心跳 200、claim URL 单 id（非 [60, 61]）、注册日志单层列表。

## 服务端重启 metadata lock（第三次实锤）
- 症状同前：重启后 8000 不监听，PROCESSLIST 见 CREATE/ALTER TABLE events 卡
  `Waiting for table metadata lock`，innodb_trx 有旧进程残留长事务。
- KILL 3 个僵尸事务（trx_mysql_thread_id）后迁移跑完、端口起来。worker 心跳自动恢复无需动 worker。
- 本机内存仅 7G：全量 pytest 与 worker 升级并发会 OOM（-9）——升级/验证错峰。

## GitCode bot 权限 403（fluxgate 案例）
- 症状：`/user` 可访问但 `/repos/{owner}/{repo}/*` 全 403 = **bot 不是该仓库成员**（非系统 bug）。
- 判别：owner token `GET /repos/{o}/{r}/collaborators/{bot}/permission` → 404 User not found。
- 修复：owner token `PUT /repos/{o}/{r}/collaborators/{bot}` {"permission":"admin"} → bot token
  `GET /user/invite?access_token=` 查邀请 → `POST /user/invite/accept?access_token=&invitation_token=`
  （**invitation_token 必须放 query 参数**，放 body 报 400）→ 验证 access_level>=40。
- 附带：managed_repos.bot_username 可能残留旧 bot（fluxgate 是 qq_59293410），与全局 bot
  grape_dev_bot 不一致——按需 UPDATE。

## 600s 任务硬超时
- 复杂 coding 任务（89 步/近 10 万 tokens，含端到端测试）撞 RUNTIME_TASK_TIMEOUT=600s 被杀
  （`task timed out after 600.0s`），非卡死非 bug——pipeline 通过后续 a2a 事件重试继续推进。
- 判别：errors 含 task timed out、started/completed 恰差 600s、日志最后一步是正常收尾（非挂起）。
