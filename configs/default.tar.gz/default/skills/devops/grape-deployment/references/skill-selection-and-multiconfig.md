# Skill 选择机制 / 多技能改造 / ClawHub 发布链路（2026-08-17 代码核实）

## 1. 技能选择 3 路径机制（勿再说「某技能用不到」）

skill 表里的技能（如 SRE 的 deploy-guard/build-debug/incident-triage/changelog-gen/cce-terrapilot/repo-to-k8s-iac）**不是没用**——它们是「配置页可选项 + AI 能力池」。选择路径：

1. **配置页下拉**（主路径，用户可手动选）：管理台 Agents 页 `.cfg-skill` `<select>`（agents.js ~line 202，单值 `scope:name`）→ 保存写 `devops_agent_session.skill` + `skill_id`（agents.py `_find_skill` 按 scope+owner 精确解析）→ pipeline 优先用会话配置（event_pipeline.py ~380 `SELECT runtime_id, skill, skill_id FROM devops_agent_session`）。
2. **路由默认**（会话未配时回退）：`configs/agent-skill-mapping.json` scenes 映射，SRE 全场景 = cloud-deploy。
3. **AI 能力池**（所有技能都进角色定义，AI 自主选行为）：`get_skill_capabilities()`（prompt_builder.py:17）扫描 `skills/` 目录，每个 SKILL.md 的 `description:` 第一行 + 图标拼进 `build_chat_role_definition()`（prompt_builder.py:231）→ chat/agent prompt 的 "Your capabilities:" 段。AI 按用户请求匹配技能名/描述自主决定行为（如用户说「构建失败」→ 用 build-debug 的行为）。但**注意**：任务工作目录 .skills/ 只物化路由/配置选中的那个技能文件——AI「知道」其他技能存在（能力列表）但**读不到它们的 SKILL.md**（除非多技能物化）。

**验证某技能是否被用 = 查这 3 条路径**（配置页选没选 / mapping 映射 / get_skill_capabilities 输出），**不是 grep 引用计数**。deploy-guard 等只有 prompt_builder 图标映射 + validator 白名单 + skill-description.json 种子——它们是「可配置可感知」的技能，不是「死代码」。

## 2. 对话模式 ≠ Issue 模式（事件传播差异，skill_sync 只接对话）

| | 对话模式（飞书/网页） | Issue 模式（GitCode 评论） |
|---|---|---|
| 入口 | `process_chat_async`（handler_async.py:452） | webhook → events 表 → `run_pipeline` |
| 事件表 | ❌ 不产生 events 行 | ✅ 有 seq 事件 |
| 任务表 | ✅ agent_tasks（agent_type=chat, event_seq=None） | ✅ agent_tasks（有 event_seq） |
| skill_sync 接入 | ✅ **入口直接拦截**：match_scene 识别同步/发布/撤销/确认 → publish_skill/remove_skill（含二次确认 CONFIRM_TTL_SEC） | ❌ 无任何环节调 sync_service |
| 普通需求处理 | chat 技能（元技能）AI 判断场景 → 引导建 Issue 转正式流程 | 按 stage 路由 vod→issue→coding→qa→sre |

- 对话路径已通：`src/im/skill_sync_scene.py`（match_scene/handle_scene/_parse_skill_name/_RE_CONFIRM）+ `src/plugins/sync_service.py`（publish_skill/remove_skill/get_bind/_get_platform_token，bind 表 skill_sync_bind）。
- Issue 评论「同步到 ClawHub」→ Issue Agent 当发布/部署类操作 A2A 交办 SRE → SRE 用 cloud-deploy 技能自由发挥（翻 /usr/local/lib/hermes-agent 考古 + `npx -y clawhub@0.23.3` 临时 CLI）——**这条路径没有二次确认/重复检测/框架调用**。
- **用户明确：不改 pipeline/webhook/A2A 架构**——解法是给 SRE 加技能（skill-publish）+ 服务端注入令牌，不是改事件流。设计文档 = 分支 docs/skill-publish-design.md（v2.0）。

## 3. ClawHub 令牌存储 + 下架失败根因

- 令牌表：`user_platform_tokens`（user_id/platform/clawhub_token/updated_at，PRIMARY KEY(user_id,platform)），settings.py `update_credentials` 保存（`ON DUPLICATE KEY UPDATE`）；**可被直接插库绕过 web**（19:20 obs_mysql_user 行先写入、20:15 xiaowu2119 复制同令牌——发布账号 @yangaiwu 不在 user_accounts，多用户隔离未生效）。
- 发布成功链路（547，SRE 考古版）：`env | grep -iE "claw|hub|yangaiwu"` → `npx -y clawhub@0.23.3` → POST /api/v1/skills（multipart: payload displayName/slug/version/contentType/tags/acceptLicenseTerms/changelog + files[]）。
- **下架失败根因链（594）**：SRE 任务 env_extra **无 CLAWHUB_TOKEN**（服务端 `_inject_platform_tokens` 未实现——只有 `_inject_cloud_credentials` 注 AK/SK）+ SRE 技能是 cloud-deploy（无发布/下架流程）+ 安全约束禁止越权 → 报「ClawHub 撤回被发布账号凭证阻塞，无法代为下架；skill 仍在线」。修复 = skill-publish 技能（发布/下架标准流程 + 读 $CLAWHUB_TOKEN）+ env_extra 注入 CLAWHUB_TOKEN（同 AK/SK 模式，按 repo_owner 从 user_platform_tokens 取）。

## 4. 多技能改造瓶颈分析（worker 已就绪，瓶颈在上游）

- **worker 端已支持多技能**：agent.py `for _sn, files in skill_files.items()` 遍历 dict 物化到 `.skills/{skill_name}/`；zip 解压 `for info in zf.infolist()` 天然支持多目录。**worker 加载/协议/安装包都不用改**。
- **瓶颈三件套（上游）**：① 前端 agents.js `.cfg-skill` 单选 `<select>` → 需多选（checkbox 组）；② `devops_agent_session.skill` TEXT 单值 → 需 JSON 数组字符串 `["cloud-deploy","skill-publish"]`（兼容旧单值：json.loads 失败 → 单元素数组）；③ pipeline skill_name 单值 → 需数组解析 + 多技能物化（enqueue_task 循环 `_pack_skill_dir` 合并 dict）。
- **OBS 分发路径是单技能 zip 模型**：`_attach_skill_obs`（runtime.py）从 task.skill 单值 → 1 个预签名 URL（skill_obs_url，TTL 1800s）→ worker 下载 1 个 zip。多技能方案 A 兼容版（obs-multi-skill-redesign.md，**用户选定**）：**复用 skill_obs_url 不新增字段**——单技能裸 URL、多技能 JSON 数组字符串 `["url1","url2"]`；新 worker json.loads 解析循环下载，老 worker 拿到 JSON 字符串当 URL 下载失败 → **降级 skill_files 文本物化**（功能不丢）。OBS 当前未启用（StorageBackend: local, OBS_ENABLED 未配）——改造代码就绪但多技能走文本物化。
- 单测坑：agent_tasks 表**没有 mode 列**（查分发模式用 skill_obs_url/skill 字段）。

## 5. 用户交互偏好（本主题相关）

- 设计讨论中**勿自主主张**：不替用户拍板方案、不主动更新/提交/推送设计文档（用户明确说「继续聊天啊。方案还不确定」「你不要自主主张」）——摆问题+选项让用户定，用户逐项确认后才写文档。
- **先讲清现状机制再谈方案**：用户问「对话模式怎么处理事件」「这是怎么做到的」= 先解释现有代码链路（入口→路由→执行），再给方案；直接给方案会被批「沙雕，先分析下」。
- 下「某功能没用/未激活」结论前必须深度核实（3 路径机制），否则被批「你吹牛逼，用不到她存在的意义是什么」。
- **加功能不改现有架构**：用户明确「不能改流程，改了就不对了，破坏她现有的架构」——优先「新增」（新技能/新配置/新增函数），动核心路由/事件传播前必须用户拍板。
