# Runtime 绑定 vs 执行模式（"配了远端 IP 为什么还在本机跑"）

> 2026-08-11 实测。用户配置 vod agent 绑定远端 worker 后任务仍在本机执行，根因是执行模式仍是 direct。

## 架构速览（三张表决定 agent 跑在哪）

- `meta.execution_mode`：direct（默认，meta 无键且 env 无 DEVOPS_EXECUTION_MODE 时）| queue_local | queue_remote
- `devops_agent_session.runtime_id`：**仓库级** agent 会话绑定的 runtime（UI "配置远程服务器" 实际写这里）
- `agent_type.default_runtime_id`：agent 类型默认 runtime（vod/issue/coding/qa/sre 各一行）
- `agent_runtimes`：runtime 实例，`credential_id` 关联 worker；`status` offline=本机/未注册, online=worker 在线
- `runtime_credentials`：worker 凭据，含 `device_name`（如 worker-ecs-grape-dev-build-0002）、`last_ip`（worker 出口 IP）、`status`（active/revoked）、`last_seen_at`（心跳，UTC）

## 根因（代码路径）

- `get_execution_mode()`（src/runtime/service.py）：env DEVOPS_EXECUTION_MODE > meta.execution_mode > 默认 direct。
- `src/api/event_pipeline.py` 分派：`if mode != "direct" ...: _enqueue_pipeline_task(...)`（入队，runtime_id 在此路径被消费）；`elif ...: threading.Thread(_execute_agent)`（**direct 就地在 webhook 进程内跑**）。
- `src/im/vod_handler_async.py` 同理：direct → `consume_stream_async` 本地流式；非 direct → enqueue_task。
- 结论：**runtime 绑定只在 queue 模式有意义**。direct 模式下绑了也白绑，任务永远本机执行。

## 快速判定 SQL（pymysql 直连，凭据在 configs/db-backend.json）

```sql
-- 1) 执行模式：查不到 execution_mode 键 = direct
SELECT `key`,value FROM meta WHERE `key` IN ('execution_mode','server_base_url');

-- 2) 队列是否用过：0 行 = 从未入队（远端 worker 永远拿不到任务）
SELECT COUNT(*) FROM agent_tasks;

-- 3) 某仓库/agent 会话绑了哪个 runtime
SELECT repo_key, agent_type, runtime_id, status, enable FROM devops_agent_session;

-- 4) runtime 归属哪个 worker + 心跳/IP
SELECT id, credential_id, name, status, last_seen_at FROM agent_runtimes;
SELECT id, name, device_name, status, last_seen_at, last_ip FROM runtime_credentials;
```

注意：agent_runtimes 有 `binary` 保留字列（DML 需反引号）；devops_agent_session 无 id 列（主键是 repo_key+agent_type 组合）；managed_repos 无 id 列（主键 repo_key）。events 表无 agent 列（是 agent_type）。

## 切换执行模式（平台级，影响所有 agent 类型）

```sql
-- queue_remote = 远端 RuntimeAgent 轮询 claim；queue_local = 本地 worker 线程池
UPDATE meta SET value='queue_remote' WHERE `key`='execution_mode';
-- 若行不存在：
-- INSERT INTO meta (`key`,`value`) VALUES ('execution_mode','queue_remote');
```

然后 `systemctl restart grape-main grape-webhook`（get_execution_mode 每事件读 meta，但稳妥起见重启）。

## 切换前必查（否则切完更糟）

1. **所有相关会话的 runtime_id 必须指向在线远端 runtime**：绑 runtime_id=1（本机 opencode，status=offline）的会话入队后可能拿不到任务。核对 devops_agent_session 全表，把要跑远端的仓库/agent 会话 UPDATE 到在线 runtime id。
2. **worker 必须活着**：runtime_credentials.status='***' 且 last_seen_at 在几分钟内（UTC）；`ps aux | grep opencode` 应看到本机无 in-flight（direct 遗留），远端 worker 在轮询。
3. 观察验证：切完触发一条 vod 任务 → agent_tasks 出现新行 → events.status 走 running→completed；events.runtime 显示远端 backend 名。

## 常见 worker 命名对照（2026-08-11 现场）

| credential | name | device_name | last_ip |
|---|---|---|---|
| 8 | vod-worker1 | worker-ecs-grape-dev-build-0002 | 1.92.115.229 |
| 9 | qa-worker | qa-work | 121.36.28.141 |
| 10 | sre-worker | worker-ecs-grape-dev-build-0006 | 113.44.183.56 |
| 13 | issue-worker1 | issue-worker | 120.46.209.201 |
| 14 | coding-worker | coding-worker | 120.46.214.60 |

（vod 会话当时绑 runtime 11 = credential 8，属正常绑定；问题纯粹是 direct 模式不吃这套。）
