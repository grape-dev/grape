#!/usr/bin/env python3
"""补 worker 的 DEEPSEEK key（幂等：已有则跳过）+ 重启 runtime-agent。

2026-08-11 首次 5 台全缺、2026-08-14 worker 0006 复发缺 key（疑似重装/重部署后丢失）。
key 来源：本机 /etc/grape/grape.env（grape-main/webhook 用的文件，勿与远端 runtime.env 混淆）。

运行：/root/grape/.venv/bin/python fix_worker_key.py [ip...]   # 不传 IP = 5 台全查全修
"""
import paramiko, time, sys

WORKERS = [
    ("0002", "192.168.0.115"),
    ("0003", "192.168.0.64"),
    ("0004", "192.168.0.39"),
    ("0005", "192.168.0.194"),
    ("0006", "192.168.0.213"),
]
KEY_PREFIX="HERMES...KEY="

# 本机取 key（去重）
key_line = None
for l in open('/etc/grape/grape.env'):
    if l.startswith(KEY_PREFIX):
        key_line = l.rstrip('\n')
        break
if not key_line:
    print("FATAL: 本机 /etc/grape/grape.env 无 DEEPSEEK key，无法修复")
    sys.exit(1)

targets = sys.argv[1:] or [ip for _, ip in WORKERS]

for ip in targets:
    try:
        c = paramiko.SSHClient()
        c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        c.connect(ip, username="root", password="kaifazhe@123", timeout=10)
        # 1. 写入 key（去重，SFTP 读写避免 shell 转义坑）
        sftp = c.open_sftp()
        try:
            with sftp.open('/etc/grape/runtime.env', 'r') as f:
                content = f.read().decode()
        except FileNotFoundError:
            content = ''
        if KEY_PREFIX in content:
            print(f"{ip}: ALREADY present, skip write")
        else:
            with sftp.open('/etc/grape/runtime.env', 'w') as f:
                f.write(content.rstrip('\n') + '\n' + key_line + '\n')
            print(f"{ip}: ADDED key line")
        sftp.close()
        # 2. 重启 runtime-agent
        stdin, stdout, stderr = c.exec_command('systemctl restart runtime-agent')
        stdout.read(); stderr.read()
        # 3. 验证
        time.sleep(4)
        check = ('systemctl is-active runtime-agent; '
                 'PID=$(pgrep -f "src.runtime.agent" | head -1); '
                 'tr "\\0" "\\n" < /proc/$PID/environ 2>/dev/null | grep -c DEEPSEEK')
        stdin, stdout, stderr = c.exec_command(check)
        print(f"{ip}: verify={stdout.read().decode().strip()}")
        c.close()
    except Exception as e:
        print(f"{ip}: FAIL {e}")
