#!/usr/bin/env python3
"""worker 重装防护：备份 runtime.env 关键 key → 重装 → 对比缺失 → 补回 + 重启。

背景（2026-08-17 事故）：install-worker.sh 重装会整体覆盖 /etc/grape/runtime.env，
只保留它认识的字段，丢失 AI 密钥（HERMES_CUSTOM_API_DEEPSEEK_COM_API_KEY 等）→
worker 在线但任务执行 3 秒 401 Authorization Required。

用法：
  python3 guard_worker_reinstall.py backup        # 重装前：备份 5 台的 runtime.env 到本地
  python3 guard_worker_reinstall.py restore       # 重装后：对比缺失 key 并补回 + 重启 runtime-agent
  python3 guard_worker_reinstall.py check 0003    # 只检查某台的 key 完整性（不写）
"""
import sys
import paramiko
from paramiko import AutoAddPolicy

IPS = {
    "0002": "192.168.0.115",
    "0003": "192.168.0.64",
    "0004": "192.168.0.39",
    "0005": "192.168.0.194",
    "0006": "192.168.0.213",
}
USER, PASS="***", "kaifazhe@123"
BACKUP_DIR = "/root/deploy/worker-env-backup/"

# 必须保留的 key（重装会丢的敏感字段，白名单之外按需加）
CRITICAL_KEYS=***
    "HERMES_CUSTOM_API_DEEPSEEK_COM_API_KEY",   # AI 密钥（2026-08-17 丢的就是它）
    "DEEPSEEK_API_KEY",                          # 别名（有些环境叫这个）
    "OPENAI_API_KEY",
    "HERMES_CUSTOM_API_",                        # 前缀匹配，覆盖其他自定义 provider
    "RUNTIME_TASK_TIMEOUT",                      # 任务超时秒数（2026-08-18 调至 900，重装勿丢）
]
# 安装脚本会自己写的字段（不用管）
SCRIPT_OWNED = ["RUNTIME_TOKEN", "RUNTIME_SERVER_URL", "RUNTIME_DEVICE_NAME",
                "RUNTIME_MAX_CONCURRENT_TASKS", "RUNTIME_POLL_INTERVAL", "RUNTIME_HEARTBEAT_INTERVAL"]


def ssh_conn(ip):
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(AutoAddPolicy())
    ssh.connect(ip, username=USER, password=PASS, timeout=15)
    return ssh


def run(ssh, cmd, timeout=60):
    _, out, err = ssh.exec_command(cmd, timeout=timeout)
    return out.read().decode(errors="replace"), err.read().decode(errors="replace")


def read_env(ssh):
    o, _ = run(ssh, "cat /etc/grape/runtime.env 2>/dev/null")
    return o


def missing_keys(content):
    """返回缺失的 critical key 列表（按行 key= 前缀匹配）。"""
    miss = []
    for k in CRITICAL_KEYS:
        if not any(line.startswith(k) for line in content.splitlines()):
            miss.append(k)
    return miss


def backup_all():
    import os
    os.makedirs(BACKUP_DIR, exist_ok=True)
    for name, ip in IPS.items():
        try:
            ssh = ssh_conn(ip)
            content = read_env(ssh)
            path = f"{BACKUP_DIR}{name}_runtime.env"
            with open(path, "w", encoding="utf-8") as f:
                f.write(content)
            miss = missing_keys(content)
            print(f"worker-{name} ({ip}): 备份 {len(content)} 字节 → {path}"
                  + (f" | ⚠️ 当前已缺: {miss}" if miss else " | 当前完整"))
            ssh.close()
        except Exception as e:
            print(f"worker-{name}: [FAIL] {e}")


def restore_all():
    for name, ip in IPS.items():
        try:
            ssh = ssh_conn(ip)
            cur = read_env(ssh)
            miss = missing_keys(cur)
            if not miss:
                print(f"worker-{name}: key 完整，无需补回")
                ssh.close()
                continue
            try:
                with open(f"{BACKUP_DIR}{name}_runtime.env", encoding="utf-8") as f:
                    bak = f.read()
            except FileNotFoundError:
                print(f"worker-{name}: [FAIL] 无备份 {BACKUP_DIR}{name}_runtime.env，先跑 backup")
                ssh.close()
                continue
            add_lines = []
            for k in miss:
                for line in bak.splitlines():
                    if line.startswith(k + "=") or line.startswith(k):
                        add_lines.append(line)
                        break
            if not add_lines:
                print(f"worker-{name}: 备份里也没有缺失的 {miss}，无法补回")
                ssh.close()
                continue
            sftp = ssh.open_sftp()
            with sftp.open("/etc/grape/runtime.env", "a") as f:
                f.write("\n" + "\n".join(add_lines) + "\n")
            sftp.close()
            # 重启让环境变量生效
            o, _ = run(ssh, "systemctl restart runtime-agent; sleep 8; systemctl is-active runtime-agent")
            # 验证进程环境
            o2, _ = run(ssh, "PID=$(pgrep -f 'src.runtime.agent' | head -1); tr '\\0' '\\n' < /proc/$PID/environ 2>/dev/null | grep -c DEEPSEEK")
            print(f"worker-{name}: 补回 {add_lines[0].split('=')[0]} 等 {len(add_lines)} 行 | 服务={o.strip()} | 进程 DEEPSEEK={o2.strip()}")
            ssh.close()
        except Exception as e:
            print(f"worker-{name}: [FAIL] {e}")


def check_one(name):
    if name not in IPS:
        print(f"未知 worker: {name}")
        return
    ip = IPS[name]
    try:
        ssh = ssh_conn(ip)
        cur = read_env(ssh)
        miss = missing_keys(cur)
        o, _ = run(ssh, "systemctl is-active runtime-agent")
        print(f"worker-{name} ({ip}): 服务={o.strip()} | 缺失 key: {miss if miss else '无（完整）'}")
        ssh.close()
    except Exception as e:
        print(f"worker-{name}: [FAIL] {e}")


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "check"
    if cmd == "backup":
        backup_all()
    elif cmd == "restore":
        restore_all()
    elif cmd == "check" and len(sys.argv) > 2:
        check_one(sys.argv[2])
    else:
        for n in IPS:
            check_one(n)
