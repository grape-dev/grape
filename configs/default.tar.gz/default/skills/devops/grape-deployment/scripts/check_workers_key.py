#!/usr/bin/env python3
"""批量检查 5 台 worker 的 runtime.env 是否含 DEEPSEEK key + runtime-agent 状态。

用途：远端任务 3 秒 401 "Authorization Required" / onboarding 事件 failed 时，
先跑本脚本确认是不是 worker 缺 key（2026-08-11 全缺、2026-08-14 0006 复发）。
只读，无副作用。运行：/root/grape/.venv/bin/python check_workers_key.py
"""
import paramiko

WORKERS = [
    ("0002", "192.168.0.115"),
    ("0003", "192.168.0.64"),
    ("0004", "192.168.0.39"),
    ("0005", "192.168.0.194"),
    ("0006", "192.168.0.213"),
]
KEY="HERMES..._KEY"

for name, ip in WORKERS:
    try:
        c = paramiko.SSHClient()
        c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        c.connect(ip, username="root", password="kaifazhe@123", timeout=8)
        stdin, stdout, stderr = c.exec_command(
            'grep -c "^%s=" /etc/grape/runtime.env 2>/dev/null; '
            'systemctl is-active runtime-agent 2>/dev/null' % KEY)
        out = stdout.read().decode().strip().split("\n")
        key_count = out[0] if out else "?"
        active = out[1] if len(out) > 1 else "?"
        print(f"worker {name} ({ip}): key_lines={key_count}, runtime-agent={active}")
        c.close()
    except Exception as e:
        print(f"worker {name} ({ip}): CONNECT FAIL {e}")
