#!/usr/bin/env python3
"""替换本机 + 5 台 worker 的 DEEPSEEK API key（只改文件，不重启）。

2026-08-18 实测：用户要求整体换模型 key 时 fix_worker_key.py（已有则跳过）不适用，
本脚本是「替换」语义。改完文件后需另行重启服务才生效：
  本机: systemctl restart grape-main grape-webhook
  worker: systemctl restart runtime-agent（每台）
验证：本机与 worker 的 /proc/<pid>/environ 里 key 尾号一致；
worker 机上 pgrep -f src.runtime.agent 可能抓到非 systemd 实例（0004 有 mlc 个人 worker 并存），
判别用 systemctl show runtime-agent -p ExecMainPID。

用法: NEW_KEY=*** /root/grape/.venv/bin/python swap_worker_key.py
"""
import os, re, sys, paramiko

NEW = os.environ.get("NEW_KEY", "")
if not NEW or not NEW.startswith("sk-"):
    print("FATAL: NEW_KEY env 缺失或格式不对")
    sys.exit(1)

KEY_NAME="HERMES..._KEY"
LINE_RE = re.compile(rf"^{KEY_NAME}=.*$")

WORKERS = [("0002", "192.168.0.115"), ("0003", "192.168.0.64"),
           ("0004", "192.168.0.39"), ("0005", "192.168.0.194"),
           ("0006", "192.168.0.213")]

def swap(content):
    if LINE_RE.search(content):
        return LINE_RE.sub(f"{KEY_NAME}={NEW}", content)
    return content.rstrip("\n") + f"\n{KEY_NAME}={NEW}\n"

# 1. 本机
local_path = "/etc/grape/grape.env"
with open(local_path) as f:
    content = f.read()
new_content = swap(content)
if new_content != content:
    with open(local_path, "w") as f:
        f.write(new_content)
    print("local /etc/grape/grape.env: swapped")
else:
    print("local /etc/grape/grape.env: already new key?")

# 2. 远端 worker
for name, ip in WORKERS:
    try:
        c = paramiko.SSHClient()
        c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        c.connect(ip, username="root", password="kaifazhe@123", timeout=10)
        sftp = c.open_sftp()
        try:
            with sftp.open("/etc/grape/runtime.env", "r") as f:
                content = f.read().decode()
        except FileNotFoundError:
            content = ""
        new_content = swap(content)
        if new_content != content:
            with sftp.open("/etc/grape/runtime.env", "w") as f:
                f.write(new_content)
            print(f"worker {name} ({ip}): swapped")
        else:
            print(f"worker {name} ({ip}): already new key?")
        sftp.close()
        c.close()
    except Exception as e:
        print(f"worker {name} ({ip}): FAIL {e}")
