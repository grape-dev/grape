---
name: grape-deployment-best-practices
description: "Grape 部署/重启/排障规范: 架构、配置清单、安全重启、僵尸清理、验证矩阵。"
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags:
      - grape
      - deployment
      - best-practices
      - ops
    related_skills:
      - grape-deployment
      - linux-service-deployment
---

# Grape 本地部署最佳实践（ecs-grape-dev-build-0001）

## When to Use
- 在 ecs-grape-dev-build-0001 上从零部署 grape（clone → venv → MySQL → systemd → nginx → certbot）。
- 重启 grape-main / grape-webhook 前后（先查 in-flight 任务，后清僵尸事件）。
- 部署/排障后的健康验证，或快速定位已知坑（端口归属、webhook 鉴权、verify 误报）。

部署/运维 grape 时的规范流程、配置清单与已知坑。操作型细节（Python 环境、DB、测试基线）见 `grape-deployment` skill，本 skill 聚焦"怎么部署是对的、重启前必须做什么、出问题怎么收尾"。

## 架构拓扑（当前线上实况）

```
公网 grape-dev.topxtopx.com (120.46.90.173)
  └─ nginx :80  (301 → https) + :443 (TLS, certbot/letsencrypt)
       ├─ / ->            proxy 127.0.0.1:8000  (grape-main.service, uvicorn src.api.main:app)
       ├─ /webhook/ ->    proxy 127.0.0.1:8080  (grape-webhook.service, uvicorn src.api.run_webhook:app)
       └─ /api/a2a ->     proxy 127.0.0.1:8080  (A2A 协议端点, agent 经 server_base_url 调用)
MySQL 192.168.4.167:3306 / grape_test_db (utf8mb4, 28 表)
```

- 应用不直接暴露公网；webhook 也走 nginx HTTPS 全链路，不直连 8080。
- nginx 关键调优已就位：`client_max_body_size 100m`、`proxy_read/send_timeout 600s`（agent 长任务）、webhook/a2a location 用 `proxy_set_header Connection ""` 防 keep-alive 挂起。

## 从零部署流程（已验证）

```bash
# 1. 代码（gitcode 私仓凭据在 ~/.git-credentials, 用户 mm6667）
git clone -b lvjuntao https://gitcode.com/Jason7602/grape.git /root/grape

# 2. Python 3.12（系统 3.9.9 跑不了 PEP 604 注解, 必须 uv）
curl -LsSf https://astral.sh/uv/install.sh | sh        # ~/.local/bin/uv
uv python install 3.12
cd /root/grape && uv venv --python 3.12 --clear .venv
uv pip install --python .venv/bin/python -r requirements.txt -i https://mirrors.aliyun.com/pypi/simple/

# 3. 数据目录（config.py 写 data/devops-bot.log, 缺目录 import 就炸）
mkdir -p /root/grape/data

# 4. MySQL 建库（如不存在; 表结构首次 import src.session_manager 时自动建）
mysql -h192.168.4.167 -uroot -p -e \
  "CREATE DATABASE IF NOT EXISTS grape_test_db CHARACTER SET utf8mb4;"

# 5. 配置（全部 gitignored, 见下节）
# 6. 部署 systemd unit + nginx conf + certbot（见下）
systemctl daemon-reload && systemctl enable --now grape-main grape-webhook
```

## 配置清单（/root/grape/configs/, 均 gitignored）

| 文件 | 关键内容 | 坑 |
|---|---|---|
| `global-bot-token.json` | gitcode_api_token、gitcode_oauth_*、bot_usernames、webhook_url、gitcode_webhook_token | bot_usernames **必须是真实 login**（grape_dev_bot = qq_59293410），display name 调 member API 会 404；启动时只迁移 3 个 oauth key 到 meta，**webhook_url 不会从该文件加载**，须先种 meta.webhook_url，否则自动探测成 http://<公网IP>:8080 |
| `db-backend.json` | `{"backend":"mysql","mysql":{host,port,user,password,database}}` | 可用 DEVOPS_DB_BACKEND/HOST/... 环境变量覆盖 |
| `login-whitelist.json` | GitCode login 白名单 | 缺失/空 = 放行所有 |

## systemd unit 规范（templates/ 下有模板）

两个 unit 均：`User=root`、`WorkingDirectory=/root/grape`、`Restart=always`、`RestartSec=5`、`Environment=PYTHONUNBUFFERED=1`、`EnvironmentFile=/etc/grape/grape.env`。

- `/etc/grape/grape.env` 含 `HERMES_CUSTOM_API_DEEPSEEK_COM_API_KEY`——**opencode agent 执行必需，重部署后必须恢复**（opencode config ~/.config/opencode/opencode.json 的 provider 引用该 env）。
- grape-main 额外带 `OAUTH_REDIRECT_URI=https://grape-dev.topxtopx.com/api/auth/callback/gitcode`。
- 端口：main 绑 127.0.0.1:8000（内网），webhook 绑 0.0.0.0:8080（被 nginx 代理）。

## 安全重启流程（重点！）

重启 grape-webhook/grape-main 会 **SIGTERM 杀掉 in-flight 的 opencode agent 进程** → events 表永久停在 running（无孤儿恢复机制）→ UI 显示"一直在运行"实际已死。僵尸事件还会连带卡断 A2A 交办链。

**重启前必做：**
```bash
ss -tlnp | grep -E ':(80|8080|8000)'      # 确认端口归属，架构会悄悄变
ps aux | grep 'opencode run' | grep -v grep   # 有 in-flight 任务 → 先等它完成或记录 seq
```

**重启后必做（清理僵尸）：**
```sql
-- 把被 SIGTERM 杀死的 running 事件标记 failed（注意：datetime('now') 是 SQLite 方言，直连 pymysql 必须用 NOW()）
UPDATE events SET status='failed', exit_code=-15, completed_at=NOW(), result='agent process killed by service restart (SIGTERM)' WHERE status='running';
-- 顺手杀孤儿 opencode 进程（ppid=1、空烧 CPU/LLM 额度）
pkill -f 'opencode run' || true
```

## 验证矩阵（部署/重启后全过才算 OK）

```bash
systemctl is-active grape-main grape-webhook nginx        # 全 active
curl -s http://127.0.0.1:8000/health                      # {"status":"ok","version":"2.0.0"}
curl -s http://127.0.0.1:8080/health                      # service:"webhook"
curl -s https://grape-dev.topxtopx.com/health             # 200, 全链路
journalctl -u grape-main -u grape-webhook -p err --since '24 hours ago'  # 无 err
```

测试基线：`cd /root/grape && ./.venv/bin/python -m pytest tests/ -q`（conftest 强制 sqlite，不碰生产库）。已知基线失败 2 个：`test_host_strict_mode_check`（需 bot token）、`test_skills_upload_repo_scope_via_form`（repo_key 前缀漂移）。改代码后证明"失败与你无关"用对照实验：`cp 文件 /tmp/x.patched && git checkout 文件 && 跑测试 && cp /tmp/x.patched 文件`。

## 已知坑速查

1. **hermes verify 配方失配**：工具按 `.hermes/environment.json` 跑裸 `pytest`（exit 127）+ `uvicorn main:app`（入口不存在）+ pip 装系统 py3.9（污染）。该文件受保护改不了 → 用上面的 venv 配方实测代替，别被 verify 误报带偏。
2. **8080 被占**：webhook 子进程会静默退出（曾发生过 hello_server.py 占 8080）。
3. **GitCode 403 噪音**：`/user/invite` 403 = bot 已是成员无邀请，正常。
4. **证书续期**：certbot-renew.timer（00:00/12:00）+ deploy hook /etc/letsencrypt/renewal-hooks/deploy/reload-nginx.sh，无需手动。
5. **webhook 鉴权**：X-GitCode-Token 按仓库比对 managed_repos.gitcode_webhook_token，无全局秘钥；未托管 404 / 不匹配 403。

## 收尾检查（每次部署后）

- [ ] /etc/grape/grape.env 存在且含 DEEPSEEK key
- [ ] 3 个端口归属正确（nginx:80, grape-main:8000, grape-webhook:8080）
- [ ] /health 三路 200
- [ ] events 表无 running 僵尸、无孤儿 opencode 进程
- [ ] configs 三件套 JSON 合法
