---
name: grape-release-packaging
description: 制作 grape 发布包(system/tools)并上传 OBS, 含校验与发布流程。
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags:
      - grape
      - release
      - packaging
      - obs
    related_skills:
      - grape-deployment
      - grape-production-install
      - grape-deployment-best-practices
---

# Grape 发布包制作 + OBS 上传(打包操作手册)

## When to Use
- 制作 grape 发布包并上传 OBS(正式发布或测试包)。
- 用户问"怎么打包/包名规则/怎么上传 OBS"时, 先讲方案再执行(见文末工作流偏好)。
- 发布新版本、重打测试包、清理 OBS 旧包。

消费端(生产安装)见 `grape-production-install`;发布包完整设计决策背景见
`grape-deployment` skill 的 references/release-packaging.md。

## 包名规则(单包, 2026-08-17 用户纠正: 只打一个包)
- `grape-system-<YYYYMMDDHHMM>.tar` — **唯一发布物**, 覆盖用户控制平台全部功能:
  前后端安装包 + 数据库包 + skills + toolkit(worker 运行时)。
- 12 位时间戳, 如 `202607220953` = 2026-07-22 09:53;包内含 agent 可读 INSTALL.md + SHA256SUMS。
- ⚠️ **不再打 grape-tools 包**(历史设计 system+tools 双包已被用户否定: "只能打一个包")。
  tools 的 event 代码本就在 backend 的 src/api 内, 无需单独子包; toolkit(worker 运行时)
  已并入 system 包的 tools/ 子包。脚本 main() 已改为 choices=["system"]。

## 工具与运行(ecs-grape-dev-build-0001)
```bash
# 脚本(本机无 mysqldump, 依赖 pymysql → 用 grape venv 的 python 跑)
/root/grape/.venv/bin/python /root/deploy/release_pack.py \
  [--ts 202607220953] [--full] [--skip-upload] \
  [--out /root/release] [--bucket obs-grape-release] [--prefix release|test]
```
- 产物 `/root/release/grape-system-<ts>.tar`(单包, --kind 已固定为 system)
- `--prefix test` 传测试桶前缀, `--prefix release` 传正式;**必须显式指定**, 默认 release
- `--full` 数据库包全量导出(含运行时数据, 仅迁移用, 慎用)
- `--skip-upload` 只打包不上传(发布前必跑一步验证)

## 打包流程(标准操作序列)
1. **先讲方案**(用户问"怎么做"时): 包结构、每个子包装什么、INSTALL.md 可读性、凭据缺口。
2. **打测试包验证**: `--ts <新时间戳> --prefix test --skip-upload`
   → 产物 + 脚本自检(INSTALL.md/SHA256SUMS/五子包齐备)。
3. **解包复核**(可选但推荐): tar xf 后 `sha256sum -c SHA256SUMS` 全 OK;抽查 INSTALL.md
   的下载地址前缀(OBS 下载/wget 行)与 --prefix 一致。
4. **上传**: 去掉 --skip-upload 重跑同一命令(obsutil cp 幂等覆盖)。
5. **清理旧测试包**: `obsutil ls obs://obs-grape-release/test/ -s` 看清单,
   `obsutil rm obs://obs-grape-release/test/grape-system-*-<旧ts>.tar -f` 删旧的, 保持 test 只有最新。
   ⚠️ 正式 release 前缀**不删老包**(用户明确要求保留历史包)。

## 包内部结构(单包全功能)
```
grape-system-<ts>.tar
├── INSTALL.md  (agent 可读, §1.1 拓扑落点 + §6.5 技能 + §6.6 worker)
├── SHA256SUMS  (相对路径, 包根可验)
├── backend/grape-backend-<ts>.tar.gz    → 服务端(src 含事件模块)
├── frontend/grape-frontend-<ts>.tar.gz  → 服务端(静态资源)
├── database/grape-db-<ts>.sql.gz        → 服务端(结构+种子)
├── skills/grape-skills-<ts>.tar.gz      → 服务端(官方技能)
└── tools/grape-toolkit-<ts>.tar.gz      → worker 机(运行时+注册脚本)
```
> ⚠️ **system 包必须含 skills 子包**(2026-08-14 生产事故): 原设计 skills 只在 tools 包,
> 用户只装 system 包 → Agent 报 "Skill 文件不存在, 当前目录仅有 .project-info/"。
> 已改: build_system 调 pack_skills + gen_system_install_md 加 §6.5 技能安装步骤。
> 验收: tar tzf system 包 | grep skills/grape-skills → 有; INSTALL.md 含 "6.5"。
> ⚠️ **单包必须含 tools/toolkit 子包**(2026-08-17 用户纠正双包): worker 运行时
> (src/runtime + install-worker.sh) 以前只在 grape-tools 包, 单包模式下并入 system 的 tools/ 子包,
> INSTALL.md §6.6 说明 worker 机只解压 tools/ 子包注册。

## 关键设计决策(踩过的点, 改脚本前先读)
1. 前端纯静态由 grape-main 托管 → 前端包 = src/api/static/, 无需 build。
2. configs 只留 example + 种子 json(白名单: `*.example.json` + agent-description/skill-description/agent-skill-mapping);真实凭据(gitignored 三件套)绝不进包。
3. 数据库包默认"结构+种子": 种子表 = admin_users/admin_roles/admin_permission_menus/admin_role_menu_rel/agent_type/skill/event_route_config/global_im_bot_config。
4. 机密表永不导出: user_accounts/user_credentials/runtime_credentials/managed_repos/oauth_states;--full 也跳过运行时大表(events/chat/tasks/agent_tasks)。
5. admin_* 表 DDL 只在库里(迁移 SQL 不在仓库) → 全新安装靠数据库包带 DDL, 缺了管理台没表。
6. 无 mysqldump → pymysql `SHOW CREATE TABLE` + `SELECT *` 生成 .sql 再 gzip;INSERT 值 `'` 转义。
7. INSTALL.md 脚本生成(git describe 版本号填充), f-string 里字面 JSON 花括号必须 `{{}}` 转义(如 `{{"status":"ok"}}`), 否则 ValueError: Invalid format specifier。
8. SHA256SUMS 必须写相对路径(backend/xxx、event/xxx 带子目录前缀), 否则包根 `sha256sum -c` 找不到文件。
9. toolkit 打包后二次过滤 `__pycache__`/`*.pyc`(src/runtime 会带)。
10. 两个 INSTALL.md 都含 §1.1 部署拓扑: system 包标注"只装 1 台服务端"; tools 包表格标明 event/skills→服务端、tools→worker 机, 并警告 worker 机勿执行服务端步骤。
11. ⚠️ 模板画廊内容必带: 项目模板 local 内容在 `examples/<id>/`(commit cbbe76f2 从 configs/project-templates/ 迁来), 清单在 `configs/project-templates.json`。打包脚本两处依赖: includes 列表含 "examples"; SYSTEM_CONFIG_KEEP 白名单含 "project-templates.json"(2026-08-13 曾漏打, 用户反馈模板页无内容)。git source 模板无本地内容。验收: tar tzf backend 包 | grep examples/ 有 7 个 hello-* 目录 + project-templates.json。

## OBS 上传要点
- 桶 `obs://obs-grape-release/<prefix>/`; 桶私有(匿名 403)。
- obsutil 在 /usr/local/bin/obsutil(本机已装); 凭据在 ~/.obsutilconfig(obsutil 加密存储, 勿手动改)。
- ⚠️ **upload 里不能每次重跑 `obsutil config`**: obsutil 会把凭据加密写进配置文件, 脚本第二次读到加密串再 config 会污染凭据 → 403 InvalidAccessKeyId。脚本已修: 仅当配置文件缺失才 config 一次。
- 凭据优先级: env OBS_AK/OBS_SK > ~/.obsutilconfig > 交互输入(首次无配置文件时)。

## 验证矩阵(发布后确认)
```bash
obsutil ls obs://obs-grape-release/test/ -s        # 最新包在列, 旧包已清
tar xf <包> -C /tmp/v && cd /tmp/v/<包目录> && sha256sum -c SHA256SUMS   # 全 OK
grep -A2 "OBS 下载" INSTALL.md                       # 前缀与 --prefix 一致
```

## 现场状态(2026-08-17)
- 正式 release 前缀现有: grape-admin-202608131731.tar + grape-system-202608132058/141617/141630/171531.tar
  (老包全部保留; 最新全功能单包 = grape-system-202608171531.tar)
- 单包模式已生效: grape-tools 不再产出(202608171522 曾误打双包, 已删除多余包)。

## 工作流偏好(用户纠正, 2026-08-12)
用户问"这个怎么做/如何打包"这类问题时:**先讲清打包方案再执行** —— 包结构、每个子包装什么、
INSTALL.md 怎么做到 agent 可读、凭据缺口。方案说明本身就是用户要的交付物, 不要写好脚本直接跑。
