---
name: grape-production-install
description: 生产环境从 OBS 获取最新 grape 发布包, 读包内 INSTALL.md 自动安装。
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags:
      - grape
      - install
      - obs
      - production
    related_skills:
      - grape-deployment
      - grape-deployment-best-practices
      - grape-release-packaging
---

# Grape 生产安装(从 OBS 发布包自动安装)

## When to Use
- 生产/新环境从 OBS 下载最新 `grape-system-<ts>.tar`(单包全功能)并安装。
- 生产 hermes 接到"从 OBS 获取最新包自动安装"任务时,按本 skill 执行。
- 需要给生产 hermes 派安装任务、或人工按包内 INSTALL.md 操作时。

发布包机制见 `grape-deployment` skill 的 references/release-packaging.md;
本地服务运维(重启/排障/验证矩阵)见 `grape-deployment-best-practices`。

## 核心机制(先讲清楚)
生产 hermes 的安装动作 = **下载 tar → 解包 → 读包内 INSTALL.md → 逐条执行其中的命令**。
INSTALL.md 由 release_pack.py 生成,每步都是完整 bash 块 + 验证命令 + 期望输出,
包根还有 SHA256SUMS 供校验。**只装一个包: grape-system** —— 它已含全部功能
(2026-08-17 起 grape-tools 不再产出; worker 运行时 toolkit 在 system 包的 tools/ 子包内)。

## 部署拓扑与主机角色(hermes 先读这节再动手)
发布包/INSTALL.md 只解决"怎么装",不解决"装哪台" —— 主机角色由本拓扑决定,
安装任务只须给主机清单(IP/角色),hermes 按角色分流执行。

```
主服务器(服务端, 1 台)
  装: grape-system 全量(backend + frontend + database + skills + 事件处理已含于 backend)
  跑: grape-main:8000 + grape-webhook:8080 + nginx(可选)
  数据库: MySQL(可同机或独立)
        │ 注册/心跳/任务分发
worker-1..N(执行机)
  装: grape-system 包内 tools/ 子包(toolkit: src/runtime + install-worker.sh + requirements-worker.txt)
  跑: runtime-agent, 注册到服务端
```

角色判定表:
| 包子包 | 落点 | 原因 |
|---|---|---|
| grape-system 全量(backend/frontend/database/skills) | 服务端(1 台) | 运营管理台 WebUI + 后端 + 事件处理 + 官方技能 |
| grape-system tools/ 子包(toolkit) | 每台 worker | worker 端执行器 + 注册脚本 |

任务模板必须带主机角色(示例):
> "主服务器 10.0.0.10 装 grape-system 全量 + grape-tools 的 event/skills;
> worker 机 10.0.0.11~15 只装 grape-tools 的 toolkit 并 install-worker.sh 注册。
> MySQL 凭据/域名/gitcode token 在 <交接位置>。"


## 前置准备(生产现场信息, INSTALL.md 里是占位符)
1. MySQL 实例 host/port/user/password, 安装前手动建库:
   `CREATE DATABASE IF NOT EXISTS grape_db CHARACTER SET utf8mb4;`
2. GitCode 机器人 token(gitcode_api_token)+ OAuth client_id/secret + webhook token + bot_usernames(真实 login)
3. `HERMES_CUSTOM_API_DEEPSEEK_COM_API_KEY`(agent 执行必需, 写进 /etc/grape/grape.env)
4. 域名(可选, 配 nginx/TLS)
5. admin 账号密码(数据库包种子自带, 装完立即改密)

## 一、下载最新包(桶是私有的, 必须 obsutil + AK/SK)
```bash
# AK/SK: env OBS_AK/OBS_SK 或已配置 ~/.obsutilconfig(obsutil 加密存储)
obsutil ls obs://obs-grape-release/<test|release>/ -s     # 看有哪些包, 挑最新时间戳
mkdir -p /root/grape-release && cd /root/grape-release
obsutil cp obs://obs-grape-release/<test|release>/grape-system-<最新ts>.tar .
```
> 桶匿名访问 403: 生产 hermes 下载必须带凭据, 或给 OBS 前缀(test/release)加匿名读策略。
> 想用 wget 直连的前提是桶/前缀已放开公网读。
> ⚠️ 单包时代只有 grape-system-*.tar 一个包要下(2026-08-17 起)。

## 二、安装 grape-system
```bash
cd /root/grape-release
tar xf grape-system-<ts>.tar && cd grape-system-<ts>
sha256sum -c SHA256SUMS        # 期望全 OK; 任一 FAILED = 包损坏, 停止
```
然后按包内 INSTALL.md 的 4~8 节执行, 要点:
1. **后端 + venv(必须 Python 3.12, 系统 3.9 跑不了 PEP 604)**:
   ```bash
   mkdir -p /root/grape /root/grape/data
   tar xzf backend/grape-backend-<ts>.tar.gz -C /root/grape
   command -v uv >/dev/null || curl -LsSf https://astral.sh/uv/install.sh | sh
   cd /root/grape && uv venv --python 3.12 --clear .venv
   uv pip install --python .venv/bin/python -r requirements.txt -i https://mirrors.aliyun.com/pypi/simple/
   ```
2. **导数据库包**(表结构 + 种子数据, admin_* 表 DDL 只在库里, 迁移 SQL 不在仓库):
   ```bash
   gzip -dc /root/grape-release/grape-system-<ts>/database/grape-db-<ts>.sql.gz | \
     mysql -h<MYSQL_HOST> -u<MYSQL_USER> -p<MYSQL_PASS> grape_db
   ```
3. **配置三件套**(cp example 后填真实值):
   - configs/db-backend.json → 指向 MySQL
   - configs/global-bot-token.json → gitcode_api_token / oauth_* / bot_usernames / webhook_url / gitcode_webhook_token
   - configs/login-whitelist.json → 留空数组 = 放行所有
4. **启动 + 验证**:
   ```bash
   uvicorn src.api.main:app --host 127.0.0.1 --port 8000 &
   uvicorn src.api.run_webhook:app --host 0.0.0.0 --port 8080 &
   curl -s http://127.0.0.1:8000/health    # {"status":"ok",...}
   curl -s http://127.0.0.1:8080/health    # service:"webhook"
   ```
5. **systemd**(生产推荐): templates/grape-main.service + grape-webhook.service 拷到
   /etc/systemd/system/, WorkingDirectory=/root/grape, 补 EnvironmentFile=/etc/grape/grape.env
   (必须含 HERMES_CUSTOM_API_DEEPSEEK_COM_API_KEY), daemon-reload + enable --now。
6. **补 meta.webhook_url**(INSTALL.md 第 6 节):
   `UPDATE meta SET value='https://<域名>/webhook/' WHERE \`key\`='webhook_url';`

## 三、安装 worker(toolkit 在 system 包 tools/ 子包内)
```bash
# 每台 worker 机: 从 system 包取 tools/ 子包(不要解压 backend/frontend 到 worker)
mkdir -p /root/grape && cd /root/grape
tar xzf /root/grape-release/grape-system-<ts>/tools/grape-toolkit-<ts>.tar.gz -C /root/grape
chmod +x /root/grape/scripts/install-worker.sh
# worker 机: /root/grape/scripts/install-worker.sh --token <rta_...> --server https://<域名>
# ⚠️ 勿用默认 --server grape.topxtopx.com(错域名), 必须显式 --server https://grape-dev.topxtopx.com
```

## 四、验证矩阵(全过才算安装成功)
```bash
systemctl is-active grape-main grape-webhook    # active
curl -s http://127.0.0.1:8000/health            # {"status":"ok","version":"..."}
curl -s http://127.0.0.1:8080/health            # service:"webhook"
ls /root/grape/skills/issue/SKILL.md            # 技能文件存在
/root/grape/.venv/bin/python -m py_compile /root/grape/src/api/event_pipeline.py  # 语法 OK
ss -tlnp | grep -E ':(80|8080|8000)'            # 端口归属正确
```

## 五、给生产 hermes 的一句话任务模板
> "从 OBS obs://obs-grape-release/<test|release>/ 下载最新 grape-system 包,
> 解包后读取包内 INSTALL.md, 按步骤自动安装(服务端全量 + worker 机取 tools/ 子包
> 注册)并跑完验证矩阵, MySQL 凭据/域名/gitcode token 在 <交接位置>。"

## 已知坑速查
1. **桶私有 403**: 下载必须 obsutil + AK/SK, 或放开前缀读策略; 匿名 wget 直连会 403。
2. **Python 3.9 崩**: 必须 3.12(uv 装); 系统 3.9 直接 import 失败。
3. **admin 改密**: 数据库包带种子 admin 账号, 装完第一件事改密码。
4. **webhook 静默退出**: 8080 被占时子进程直接退出; 先 `ss -tlnp` 查端口。
5. **meta 幂等**: 改 oauth 值后重启不同步 meta, 须手动 UPDATE meta 表。
6. **重启杀任务**: 重启会 SIGTERM 掉 in-flight agent, 事后清 events 僵尸
   `UPDATE events SET status='failed', exit_code=-15, completed_at=NOW() WHERE status='running';`
7. **worker 3 秒 401**: /etc/grape/runtime.env 缺 HERMES_CUSTOM_API_DEEPSEEK_COM_API_KEY。
8. **发布包不含机密**: 用户令牌/webhook token 不进包, 现场配置里填; --full 只用于迁移。
