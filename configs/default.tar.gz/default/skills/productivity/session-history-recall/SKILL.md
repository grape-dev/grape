---
name: session-history-recall
description: Use when user asks to return a past prompt/command verbatim.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags:
      - hermes
      - sessions
      - recall
      - sqlite
      - history
---

# Recall past session prompts / commands verbatim

## When to Use
- User asks 「返回/找回之前 XX 的提示词 / 命令 / 消息」 — they want the EXACT original text of something said in an earlier Hermes session, usually to reuse it (repackage, redeploy, re-run a job). The request is a signal the prompt will be reused — deliver verbatim, not paraphrased.
- Any "what did we do / what did I say" question needing the source text.

## Two-layer retrieval
1. **session_search** (fast, semantic): discovery shape, try several keyword variants (Chinese + English + distinctive tokens like `rta_`, 包名规则, worker 升级). Use `sort=newest` for recency-shaped recall. Link results back with the `@session:default/<id>` link value verbatim.
2. **Direct SQLite** (authoritative fallback): session_search FTS discovery only surfaces a small recent window (observed: keeps returning the same ~5-6 sessions; the target session never appears no matter the keywords). Query `~/.hermes/state.db` directly — it holds FULL history including the exact message text.

## Direct SQL recipe (default profile)
DB: `~/.hermes/state.db` (SQLite). Other profiles: `~/.hermes/profiles/<name>/state.db` (check if the default DB misses it).

Schema essentials (verify with `PRAGMA table_info(...)` if queries fail):
- `sessions(id TEXT PK, title, started_at REAL unixepoch, last_activity_at REAL, model, cwd, git_branch, profile_name, ...)`
- `messages(id INTEGER PK, session_id TEXT, role, content, tool_calls JSON, tool_name, timestamp REAL unixepoch, ...)`

Step 1 — find candidate sessions by title keyword:
```
sqlite3 ~/.hermes/state.db "SELECT id, title, datetime(started_at,'unixepoch','localtime') FROM sessions WHERE title LIKE '%<kw>%' ORDER BY started_at DESC LIMIT 25;"
```

Step 2 — find the verbatim user message (preview with substr, then pull the full row for the winner):
```
sqlite3 ~/.hermes/state.db "SELECT session_id, datetime(timestamp,'unixepoch','localtime'), content FROM messages WHERE role='user' AND content LIKE '%<kw>%' ORDER BY timestamp DESC LIMIT 30;"
```

Step 3 — confirm full text: re-query the winning row WITHOUT substr before quoting "verbatim".

## Pitfalls
- **Noise in role='user'**: background-process notifications (`[IMPORTANT: Background process ...]`), context-compaction handoffs (`[CONTEXT COMPACTION — REFERENCE ONLY]`), and platform/system messages (e.g. `Event Context`) are all stored as user-role rows. Exclude with `AND content NOT LIKE '%IMPORTANT: Background%'` etc. when hunting the real user prompt.
- **Secret-bearing prompts** (rta_ tokens, AK/SK, clh_ tokens): present the prompt to the user, but do NOT copy live secrets into skills/memory — point to the holding file/session instead (e.g. `/root/deploy/upgrade_workers_newtoken.py`). Flag that embedded tokens may be rotated/stale since the original session.
- message ids in state.db match session_search message ids — usable for cross-referencing.
- The session DB is written by Hermes only: read-only queries are safe; never UPDATE/DELETE it.

## Output format
- Verbatim text block (no paraphrase), then:
  - source session link `@session:default/<id>` (+ timestamp if known)
  - one line on what was executed with it that time (context)
  - staleness warning if it embeds tokens/credentials
- If multiple candidate prompts exist (e.g. morning vs evening upgrade instructions), list them and ask which is wanted.
