---
name: hermes-cli-invocation
description: "Invoke hermes CLI from scripts; know streaming/reasoning."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [hermes, cli, scripting, streaming, subprocess, automation]
    related_skills: [hermes-agent]
---

# Hermes CLI invocation: output modes & real-time output

## When to Use
- "为什么调用 hermes 时没有实时日志 / CLI 是不是不支持流式输出 / 为什么不显示思考过程" — debugging missing real-time output from a hermes invocation.
- Writing scripts / subprocess / CI code that calls `hermes chat` or `hermes -z` and needs predictable stdout.
- Turning the thinking (reasoning) display on/off for the classic CLI.

## Output modes (source-verified against installed CLI)

| Invocation | Streams tokens | Shows thinking | stdout |
|---|---|---|---|
| `hermes` / `hermes chat` (interactive) | yes, live | yes if `display.show_reasoning: true` | REPL + spinner + tool previews |
| `hermes chat -q "q"` (no -Q) | yes (goes through cli.chat()) | yes | "Query: …" label then streamed response |
| `hermes chat -q "q" -Q` (quiet) | **NO — by design** | NO | only final response; `session_id:` goes to **stderr** |
| `hermes -z "q"` (oneshot) | NO | NO | only the final content block |

Key facts:
- **Quiet mode is intentional, not a bug.** `-q -Q` explicitly nulls the streaming display callbacks (`stream_delta_callback = None`, `tool_progress_mode = "off"`) so stdout stays machine-readable; the response is printed once at the end. The `-Q` help text says exactly this: "Only output the final response and session info."
- **Thinking display is config-controlled**: `display.show_reasoning` (default true), `display.streaming` (default true), `display.reasoning_full` (post-response recap box uncollapsed; live streaming is always full). CLI flag `--reasoning LEVEL` (none|minimal|low|medium|high|xhigh|max|ultra) overrides `agent.reasoning_effort` for the run. The model must actually emit reasoning tokens for anything to appear.
- User's own config often overrides defaults — check `/root/.hermes/config.yaml` `display:` section first (e.g. `show_reasoning: false` there = no thinking shown even on a reasoning model).
- `-Q` and `-z` suppress reasoning regardless of `show_reasoning`.

## Buffering pitfall (the #1 "no real-time logs" cause from scripts)
When stdout is a **pipe** (subprocess, CI, redirected file) instead of a TTY, Python block-buffers stdout: even with streaming enabled, output is held in the buffer and dumped when the process exits. Looks exactly like "no real-time output". Fixes (any one):
- `PYTHONUNBUFFERED=1 hermes …` (or `python -u …`)
- `stdbuf -oL hermes …`
- Run under a PTY: `tmux new-session -d -s agent1 'hermes …'` then `tmux capture-pane -t agent1 -p`

## Pitfalls
- Don't tell users "streaming is broken" — check which mode they invoked: `-Q`/`-z` never stream; pipes buffer; only interactive and bare `-q` stream live.
- In non-TTY contexts ANSI/spinner output is suppressed or garbled — use `-Q` for clean machine output.
- Interactive spawning needs a real terminal (prompt_toolkit); use tmux, not a raw background process (raw PTY has `\r` vs `\n` issues).

## Source map (for re-verification; paths are for a pip/global install)
- `/usr/local/lib/hermes-agent/cli.py`: display defaults in `CLI_CONFIG` (~line 480-505: `show_reasoning: True`, `streaming: True`); single-query path in `main()` (~18679-18906: quiet branch nulls callbacks; non-quiet branch streams via `cli.chat()`); streaming callback (~6775, line-buffered, suppresses raw reasoning tags when show_reasoning off); reasoning gate `_current_reasoning_callback` (~6566).
- `/usr/local/lib/hermes-agent/hermes_cli/oneshot.py`: `-z` mode — final content block only, no stderr chatter.
- `/usr/local/lib/hermes-agent/hermes_cli/config_defaults.py`: display defaults (~line 1171).
- Live truth: `hermes chat --help` for current flags.

## Quick verification
```
hermes chat -q "hi"                        # streams live (output before exit)
hermes chat -q "hi" -Q                     # nothing until done, then final + session_id on stderr
PYTHONUNBUFFERED=1 hermes chat -q "hi" | cat   # real-time even through a pipe
hermes config set display.show_reasoning true  # enable thinking display
```
