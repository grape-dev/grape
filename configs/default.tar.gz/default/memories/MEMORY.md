ecs-grape-dev-build-0001: EulerOS aarch64, 系统 py3.9 会崩(PEP604), 用 uv py3.12 venv.
§
opencode config ~/.config/opencode/opencode.json 的 provider 引用该 env；远端 worker /etc/grape/runtime.env 亦须含同 key（5 台曾全缺→远端任务 3s 401），重部署勿漏）。
§
gitcode 私仓凭据 ~/.git-credentials(mm6667)；OBS 上传凭据已配 ~/.obsutilconfig；GitHub/Gitee 无凭据，需要时先向用户要。
§
换新 token 升级→旧凭据设备名在管理台显失联(新凭据接管非故障, token_hash=sha256(token))；旧 runtime 行若被自愈置 offline 而 binding/会话仍指它→事件秒败 engine_unavailable(无任务行, redispatch 404, 重跑=存库 payload 重放 run_pipeline)
§
grape webhook 鉴权: X-GitCode-Token 按仓库比对 managed_repos.gitcode_webhook_token（未托管 404/不匹配 403）。⚠️安全组白名单漏 GitCode 回调出口 IP(121.36.87.186)会全量断流(已修复)；收紧: 放开 0.0.0.0→cron grape-webhook-ip-monitor 每5分钟收集 IP(/root/grape/data/webhook-ips-all.txt)→收紧+监测，详见 grape-deployment references/webhook-ip-whitelist.md。global-bot-token.json 启动时仅迁移 3 个 oauth key 到 meta（改 oauth 值须手动 UPDATE meta）；webhook_url 不会从该文件加载，须先种 meta.webhook_url 否则启动探测成 http://<公网IP>:8080。
§
grape_dev_bot 是合法 login（与 qq_59293410 两个账号）；GitCode member API 只认 login 不认显示名；bot_usernames=['grape_dev_bot']。
§
⚠️ claim 池废除后 runtime_id=0/死行永不被 claim；本机直连行(runtime 1, credential_id=0)在 queue_remote 下亦成黑洞——set_chat_config 解析裸引擎名(opencode)落 runtime 1、send_stream 无 credential 保护直接入队→chat 无回应，诊断/修复见 grape-deployment references/chat-task-blackhole-local-direct-2026-08.md。重派: pick_engine() 拿新 rid→UPDATE agent_tasks 保持 queued 即被接走；redispatch API 需内存态 token CLI 不可用。MySQL 盲区见 grape-deployment references/mysql-reserved-words-1064.md。
§
skill 多平台同步 feat/skill-sync-multiplatform v4.2 已实施：skill-publish 独立技能(ClawHub/GitHub/GitCode, skill 单选切换)、A1 废弃 skill_sync_scene+sync_service+bind、令牌方案 B(user_platform_tokens platform+token 列, 仅 sre 按 repo owner 注入——fluxgate owner=signway 无令牌行→撤回失败根因)；grape_dev_bot 自建 Issue 被 webhook skip 须真实用户身份；死代码已清(_run_scene_async/src/plugins)
§
⚠️ /root/grape 工作区可能被并行 hermes 会话同时操作（2026-08-17 实测：并行会话切分支+重启服务致部署回退，用户报时间未本地化）——改码/部署前先查 git branch --show-current 与 reflog，主工作区被占用时用 git worktree 隔离；部署回退判定与配方见 grape-deployment references/parallel-session-workspace-contention.md
§
OBS 已启用(2026-08-17)：桶 obs-grape-dev-file(cn-north-4)，AK=HPUA1RGZONSTYDPQLPZR，配置 /etc/grape/grape.env(OBS_ENABLED=true)，StorageBackend: obs