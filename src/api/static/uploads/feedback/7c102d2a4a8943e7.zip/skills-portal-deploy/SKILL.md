---
name: skills-portal-deploy
description: 非交互式同步+构建+部署 skills 门户全栈(gitcode.com/songspace/skills → nginx /var/www/html 静态门户 + like-service Spring Boot 后端)。用户提到"更新 skills 网站/部署最新代码/拉取 gitcode skills 仓库"时使用。全程零交互:一条命令完成 git 同步(自动备份本地改动)、后端变更检测与 mvn 构建、静态文件部署与哈希/冒烟校验、systemd 服务重启与健康检查。
---

# Skills Portal 一键部署(零交互,前端+后端)

主机特定流程(用户 lvjuntao / Linux)。核心策略:**gitcode main 是唯一事实源**;
本地任何未提交改动先自动备份到 backups 再丢弃;远端 like-service/ 有变更时自动重建 jar 并重启服务。全程不弹确认。

## 关键路径与事实
- 仓库根:/home/lvjuntao/skillsportal/skills(remote = https://gitcode.com/songspace/skills.git,分支 main)
  - ⚠️ 前端在子目录 skills-portal/,不是仓库根
- 前端 webroot:/var/www/html(属主 xiaotao、755、lvjuntao 无写权限)→ 静态部署必须 root
- 后端:like-service(Spring Boot 3.2/Java 17),systemd 服务 **like-service.service**(User=lvjuntao,ExecStart=java -jar target/like-service-1.0.0.jar,Restart=always,监听 :8080,nginx 反代 /api)
  - Maven:/usr/bin/mvn 3.8.7;构建命令 mvn -q -DskipTests package
  - 数据源/邮件等敏感配置在 like-service/src/main/resources/application.properties(systemd 重启自动沿用,无需手工传参)
- 线上 8 个静态文件:index.html detail.html app.js skills-data.js skills-detail-data.js admin.html privacy.html logo.jpg
  - ⚠️ 仓库自带 deploy.sh 只拷 5 个文件,**不含** logo.jpg/admin.html/privacy.html,不可单独依赖
- 备份目录:/home/lvjuntao/backups/
  - 历史定制备份(2026-09-02 移除的 SEO index.html 与品牌 logo):skills-portal-20260902/
  - 每次自动备份的本地改动:predeploy-<时间戳>/
- nginx 静态替换无需 reload;站点 / 响应带 no-store,浏览器无需强刷

## 已安装脚本
- /home/lvjuntao/update-skills-portal.sh      ← 一键入口(用户级)
- /home/lvjuntao/skills-portal-sync.sh        ← git fetch + ff-only + 本地改动备份 + 变更检测,写状态标记
- /home/lvjuntao/like-service-build.sh        ← mvn 打包后端 jar(用户级)
- /home/lvjuntao/deploy-skills-portal.sh      ← **root:root 755**;静态部署+校验+按标记重启后端(经 NOPASSWD 调用)
- /home/lvjuntao/.skills-deploy-state         ← 状态标记:OLD/NEW/BACKEND_CHANGED(0|1)
- sudoers:/etc/sudoers.d/skills-deploy → `lvjuntao ALL=(root) NOPASSWD: /home/lvjuntao/deploy-skills-portal.sh`

## 标准操作(零交互)
```
bash /home/lvjuntao/update-skills-portal.sh
```
流程:同步(已最新则跳过)→ 若 BACKEND_CHANGED=1 则 mvn 构建 → sudo -n 部署脚本(静态 8 文件哈希校验 + 冒烟 200;若标记=1 则 systemctl restart like-service + 本机 8080 健康检查)。
输出含 UPDATE OK;exit 0 即成功。**无后端变更时不会重启服务。**

## 各脚本行为(排查对照)
1. sync:fetch origin main;本地领先(分叉)则报错退出,**绝不 reset --hard**;仅落后时把已修改文件备份到 backups/predeploy-<ts>/ 后 checkout,再 merge --ff-only;diff OLD..NEW 里含 like-service/ 路径 → BACKEND_CHANGED=1。
2. like-service-build:cd like-service && mvn -q -DskipTests package;校验 target/like-service-1.0.0.jar 生成。
   - 注意:Maven 无源码变更时不重写 jar(时间戳不变属正常);需强制验证可先 rm jar 再构建。
3. deploy(root):8 文件 rm+cp + chown xiaotao + sha256 全一致;curl 8 个 URL 200;标记=1 才 systemctl restart like-service.service,轮询 45×2s 等 active+8080 就绪,失败 exit 1。

## 一次性引导(仅新机器/规则丢失时需要,会弹一次 sudo 密码)
本机已于 2026-09-02 完成,一般无需重跑:
```
sudo bash /home/lvjuntao/install-skills-deploy.sh
```
(把 deploy 脚本 chown root、写 /etc/sudoers.d/skills-deploy(440) 并 visudo -c、用户脚本归 lvjuntao、建 backups)
skill 自带脚本副本在 scripts/,全新主机可先拷贝到 /home/lvjuntao/ 再跑 install。

## 陷阱
- 不要用 `git reset --hard` 同步:会静默销毁本地提交。只用 ff-only;分叉时报错等人工合并。
- deploy 脚本是 root 属主且被 NOPASSWD 规则引用:lvjuntao 不可直接改写(防提权),更新它需 sudo install。
- 后端重启仅由"本次拉取是否触及 like-service/"驱动;标记文件在每次 sync 时重置(含"已是最新"分支),避免陈旧标记导致误重启。
- 历史教训:index.html 曾有仅存于线上的 SEO 增强版(JSON-LD/OG 标签),logo.jpg 曾有 848x1915 品牌竖版图,均不在仓库。2026-09-02 起按"仓库为准"处理,需要找回时去 backups/skills-portal-20260902/。
- 远端新增 docs/ 架构文档只进仓库不上线;如需发布到网站需显式拷贝到 /var/www/html/docs/。
- 交互模式下普通 `sudo` 仍会弹密码(仅部署脚本这条 NOPASSWD),不要在命令里用 `sudo -S` 管道传密码(被安全策略拦截)。
- mvn 构建需网络拉依赖(本机 ~/.m2 已缓存);无 settings.xml 镜像,若依赖下载慢属正常。
