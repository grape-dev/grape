#!/usr/bin/env bash
# skills-portal-sync.sh — 非交互同步本地仓库到远端 main(无任何确认)
# 策略:gitcode main 是唯一事实源;本地未提交改动先备份到 backups/ 再丢弃;
#       若本地有领先提交则拒绝覆盖并报错(绝不 reset --hard 强推)。
# 输出状态标记到 /home/lvjuntao/.skills-deploy-state(供后续构建/部署判断)
set -euo pipefail
REPO=/home/lvjuntao/skillsportal/skills
BKROOT=/home/lvjuntao/backups
STATE=/home/lvjuntao/.skills-deploy-state
cd "$REPO"

git fetch origin main
OLD=$(git rev-parse HEAD)
NEW=$(git rev-parse FETCH_HEAD)

if [ "$OLD" = "$NEW" ]; then
  echo "已是最新: $(git rev-parse --short HEAD) ($(git log -1 --format=%s))"
  printf 'OLD=%s\nNEW=%s\nBACKEND_CHANGED=0\n' "$OLD" "$NEW" > "$STATE"
  exit 0
fi

AHEAD=$(git rev-list --count origin/main..HEAD)
if [ "$AHEAD" -gt 0 ]; then
  echo "ERROR: 本地有 $AHEAD 个提交不在 origin/main 上(已分叉)。拒绝覆盖,请先 push/merge。" >&2
  exit 1
fi

# 备份并丢弃本地未提交修改(仓库为唯一事实源,备份是逃生通道)
if ! git diff --quiet; then
  TS=$(date +%Y%m%d-%H%M%S)
  BKDIR="$BKROOT/predeploy-$TS"
  mkdir -p "$BKDIR"
  git diff --name-only | while IFS= read -r f; do
    mkdir -p "$BKDIR/$(dirname "$f")"
    cp "$f" "$BKDIR/$f"
    echo "  备份本地修改: $f -> $BKDIR/$f"
  done
  git checkout -- .
fi

git merge --ff-only origin/main

# 判断本次更新是否触及后端源码
BC=0
if git diff --name-only "$OLD..$NEW" | grep -q '^like-service/'; then BC=1; fi
printf 'OLD=%s\nNEW=%s\nBACKEND_CHANGED=%s\n' "$OLD" "$NEW" "$BC" > "$STATE"

echo "同步完成: $(git rev-parse --short HEAD) ($(git log -1 --format=%s))"
if [ "$BC" = "1" ]; then echo "检测到 like-service/ 变更 → 将重建并重启后端"; fi
