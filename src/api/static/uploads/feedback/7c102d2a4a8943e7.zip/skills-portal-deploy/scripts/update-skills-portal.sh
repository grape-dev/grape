#!/usr/bin/env bash
# update-skills-portal.sh — 一键更新+部署(零交互)
# 1) 同步本地仓库到远端 main(自动备份并丢弃本地改动,写状态标记)
# 2) 若 like-service/ 有变更 → mvn 构建后端 jar
# 3) NOPASSWD sudo 部署静态门户到 /var/www/html;若后端有变更则重启 like-service 并健康检查
set -euo pipefail
STATE=/home/lvjuntao/.skills-deploy-state

bash /home/lvjuntao/skills-portal-sync.sh

if [ -f "$STATE" ] && grep -q '^BACKEND_CHANGED=1' "$STATE"; then
  bash /home/lvjuntao/like-service-build.sh
fi

sudo -n /home/lvjuntao/deploy-skills-portal.sh
echo "UPDATE OK @ $(date '+%F %T')"
