#!/usr/bin/env bash
# deploy-skills-portal.sh — root 部署脚本(须 root,已配 NOPASSWD sudo;root 属主勿由 lvjuntao 改写)
# 1) 覆盖 8 个门户静态文件到 /var/www/html,chown xiaotao,sha256 校验,curl 冒烟
# 2) 若状态标记 BACKEND_CHANGED=1 → systemctl restart like-service.service + 健康检查
# 纯静态替换无需 reload nginx;后端为 systemd 服务 like-service.service
set -euo pipefail
SRC=/home/lvjuntao/skillsportal/skills/skills-portal
DST=/var/www/html
STATE=/home/lvjuntao/.skills-deploy-state
FILES="index.html detail.html app.js skills-data.js skills-detail-data.js admin.html privacy.html logo.jpg"

echo "==> 部署 $SRC -> $DST"
for f in $FILES; do
  [ -f "$SRC/$f" ] || { echo "缺少 $SRC/$f"; exit 1; }
  rm -f "$DST/$f"
  cp "$SRC/$f" "$DST/$f"
  chown xiaotao:xiaotao "$DST/$f"
  chmod 644 "$DST/$f"
  echo "  deployed: $f ($(stat -c%s "$DST/$f") bytes)"
done

echo "==> 本地哈希校验(webroot vs repo)"
FAIL=0
for f in $FILES; do
  a=$(sha256sum "$DST/$f" | awk '{print $1}')
  b=$(sha256sum "$SRC/$f" | awk '{print $1}')
  if [ "$a" = "$b" ]; then echo "  OK  $f"; else echo "  MISMATCH $f"; FAIL=1; fi
done
[ "$FAIL" = "0" ] || { echo "==> 哈希不一致,部署失败!"; exit 1; }

echo "==> 线上冒烟测试(https://learn.topxtopx.com)"
for p in "" logo.jpg detail.html app.js skills-data.js skills-detail-data.js admin.html privacy.html; do
  code=$(curl -s -o /dev/null -w "%{http_code}" "https://learn.topxtopx.com/$p") || code=000
  [ "$code" = "200" ] && echo "  OK   /$p -> $code" || { echo "  FAIL /$p -> $code"; FAIL=1; }
done
[ "$FAIL" = "0" ] || { echo "==> 冒烟测试未通过!"; exit 1; }

# ---------- 后端:仅当本次同步触及 like-service/ 时重启 ----------
if [ -f "$STATE" ] && grep -q '^BACKEND_CHANGED=1' "$STATE"; then
  echo "==> 后端有变更,重启 like-service.service"
  systemctl restart like-service.service
  OK=0
  for _ in $(seq 1 45); do
    if systemctl is-active --quiet like-service.service && curl -sf -o /dev/null http://127.0.0.1:8080/api/likes/all; then
      OK=1; break
    fi
    sleep 2
  done
  if [ "$OK" = "1" ]; then
    echo "  后端重启成功,健康检查通过 ✅"
  else
    echo "  后端重启失败或未就绪!" >&2
    systemctl status like-service.service --no-pager | tail -8 || true
    exit 1
  fi
else
  echo "==> 后端无变更,跳过重启"
fi

echo "==> 部署完成 ✅"
