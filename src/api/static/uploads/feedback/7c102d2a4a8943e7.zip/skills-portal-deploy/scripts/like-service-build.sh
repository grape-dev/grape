#!/usr/bin/env bash
# like-service-build.sh — 构建 like-service 后端 jar(以 lvjuntao 运行,产物归属正确)
# 仅当上游 like-service/ 有变更时由 update-skills-portal.sh 调用
set -euo pipefail
APP=/home/lvjuntao/skillsportal/skills/like-service
cd "$APP"

echo "==> 构建 like-service(mvn package -DskipTests,Java 17)"
mvn -q -DskipTests package

JAR="$APP/target/like-service-1.0.0.jar"
[ -f "$JAR" ] || { echo "构建失败: 未生成 $JAR" >&2; exit 1; }
echo "构建完成: $JAR ($(stat -c%s "$JAR") bytes, $(date -r "$JAR" '+%F %T'))"
