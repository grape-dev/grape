#!/usr/bin/env bash
# install-skills-deploy.sh — 一次性引导(须以 root 运行,仅此一次需要交互输密码)
# 作用:
#   1) deploy 脚本改为 root 属主 755(防止 lvjuntao 篡改后借 NOPASSWD 提权)
#   2) 写入 /etc/sudoers.d/skills-deploy:NOPASSWD 仅限该部署脚本
#   3) 其余脚本归属 lvjuntao 并加可执行;确保 backups 目录存在
set -euo pipefail
[ "$(id -u)" = "0" ] || { echo "请用 root 运行: sudo bash $0"; exit 1; }

DEPLOY=/home/lvjuntao/deploy-skills-portal.sh
chown root:root "$DEPLOY"
chmod 755 "$DEPLOY"

RULE='lvjuntao ALL=(root) NOPASSWD: /home/lvjuntao/deploy-skills-portal.sh'
echo "$RULE" > /etc/sudoers.d/skills-deploy
chmod 440 /etc/sudoers.d/skills-deploy
visudo -cf /etc/sudoers.d/skills-deploy

chown lvjuntao:lvjuntao \
  /home/lvjuntao/skills-portal-sync.sh \
  /home/lvjuntao/like-service-build.sh \
  /home/lvjuntao/update-skills-portal.sh
chmod 755 \
  /home/lvjuntao/skills-portal-sync.sh \
  /home/lvjuntao/like-service-build.sh \
  /home/lvjuntao/update-skills-portal.sh
mkdir -p /home/lvjuntao/backups

echo "安装完成:"
echo "  - $DEPLOY (root:root 755, NOPASSWD sudo 仅限此路径)"
echo "  - /etc/sudoers.d/skills-deploy (440)"
echo "  - 用户脚本: skills-portal-sync.sh / like-service-build.sh / update-skills-portal.sh"
echo "  - 以后更新部署只需: bash /home/lvjuntao/update-skills-portal.sh"
